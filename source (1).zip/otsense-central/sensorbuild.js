/*
 * OT Sense Central - "Build sensor" helper (zero npm packages).
 *
 * One generic, secret-free BASE IMAGE per platform is built once (see sensor-image/).
 * Everything that is specific to one sensor (site name, token, central address, IP) travels in a
 * tiny SEED made here: a cloud-init "NoCloud" seed ISO (label CIDATA) or the same files in a zip.
 * The base image reads the seed on first boot and configures itself - nobody has to type anything.
 */
'use strict';
const crypto = require('crypto');

/* ---------------- platforms shown in the drop-down ---------------- */
const ISO_NAME = 'otsense-sensor.iso';
const PLATFORMS = {
  vmware:     { label: 'VMware ESXi / vSphere / Workstation (VM)',        image: ISO_NAME, seed: 'stamp' },
  hyperv:     { label: 'Microsoft Hyper-V (VM)',                          image: ISO_NAME, seed: 'stamp' },
  virtualbox: { label: 'VirtualBox / Proxmox / KVM (VM)',                 image: ISO_NAME, seed: 'stamp' },
  windows:    { label: 'Windows PC - app (unzip, double-click OTSense-Sensor.exe, no VM)', image: '', seed: 'winapp' },
  winvm:      { label: 'Windows PC - Linux VM app, ONE zip (Hyper-V/VirtualBox, pick your Wi-Fi; real ARP/MAC scan)', image: ISO_NAME, seed: 'winvm' },
  pc:         { label: 'Laptop / PC / mini-PC (boot from USB stick)',     image: ISO_NAME, seed: 'stamp' },
  rpi:        { label: 'Raspberry Pi 4 / 5 (ARM, separate image)',        image: 'otsense-sensor-rpi.img.xz', seed: 'zip' },
  docker:     { label: 'Any Linux with Docker (laptop, VM, cloud)',       image: '', seed: 'script' },
  android:    { label: 'Android phone / tablet (app: install, open - already connected to this central)',      image: '', seed: 'script' }
};

/* ---------------- validation helpers ---------------- */
const RE_IP = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
function sq(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }      // shell single-quote
function slug(s) { return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'site'; }
function cidrOk(s) { const m = /^(.+)\/(\d{1,2})$/.exec(s || ''); return !!m && RE_IP.test(m[1]) && +m[2] >= 1 && +m[2] <= 32; }

function cleanOptions(b) {
  const o = { platform: String(b.platform || ''), mode: b.mode === 'static' ? 'static' : 'dhcp',
    cidr: String(b.ip_cidr || '').trim(), gw: String(b.gateway || '').trim(), dns: String(b.dns || '').trim(),
    central: String(b.central_url || '').trim().replace(/\/+$/, ''), ca: String(b.ca_pem || '').trim(),
    restrict: !!b.restrict_ui, scan: String(b.scan_mode || '') === 'active' ? 'active' : 'passive',
    survey: Math.max(0, Math.min(240, parseInt(b.survey_min, 10) || 0)) };
  if (!PLATFORMS[o.platform]) throw new Error('choose a platform');
  if (!/^https?:\/\/[^\/\s'"]+$/.test(o.central)) throw new Error('central address must look like https://central.example.com (no path)');
  if (o.ca && !/^-----BEGIN CERTIFICATE-----[\s\S]+-----END CERTIFICATE-----$/.test(o.ca)) throw new Error('CA certificate must be PEM text (-----BEGIN CERTIFICATE-----)');
  if (o.mode === 'static') {
    if (!cidrOk(o.cidr)) throw new Error('sensor IP must look like 192.168.1.50/24');
    if (!RE_IP.test(o.gw)) throw new Error('gateway must be an IPv4 address');
    const d = o.dns.split(/[ ,]+/).filter(Boolean);
    if (!d.length || !d.every(function (x) { return RE_IP.test(x); })) throw new Error('DNS must be one or more IPv4 addresses');
    o.dns = d.join(',');
  } else { o.cidr = o.gw = o.dns = ''; }
  return o;
}

/* ---------------- the config the sensor reads on first boot ---------------- */
function confText(site, token, o) {
  return ['# OT Sense sensor settings (written by central)',
    'SITE=' + sq(site), 'CENTRAL=' + sq(o.central), 'TOKEN=' + sq(token),
    'MGMT_MODE=' + sq(o.mode), 'IP_CIDR=' + sq(o.cidr), 'GATEWAY=' + sq(o.gw), 'DNS=' + sq(o.dns), 'SCAN=' + sq(o.scan),
    ''].join('\n');
}
function indent(t, n) { const p = ' '.repeat(n); return String(t).split('\n').map(function (l) { return l ? p + l : l; }).join('\n'); }

function userData(site, token, o, consolePw) {
  let y = '#cloud-config\n' +
    'hostname: otsense-' + slug(site) + '\nmanage_etc_hosts: true\n' +
    'ssh_pwauth: false\n' +
    'users:\n  - name: otsense\n    gecos: OT Sense service account\n    groups: [sudo, docker]\n    shell: /bin/bash\n    lock_passwd: false\n' +
    'chpasswd:\n  expire: false\n  users:\n    - {name: otsense, password: ' + consolePw + ', type: text}\n' +
    'write_files:\n' +
    '  - path: /etc/otsense/sensor.conf\n    permissions: "0600"\n    content: |\n' + indent(confText(site, token, o), 6) + '\n' +
    '  - path: /etc/cloud/cloud.cfg.d/99-otsense-no-network.cfg\n    content: |\n      network: {config: disabled}\n';
  if (o.ca) y += '  - path: /etc/otsense/ca.crt\n    permissions: "0644"\n    content: |\n' + indent(o.ca, 6) + '\n';
  y += 'runcmd:\n  - [ /opt/otsense/firstboot.sh ]\n';
  return y;
}
function metaData(site) { return 'instance-id: otsense-' + slug(site) + '-' + Date.now().toString(36) + '\nlocal-hostname: otsense-' + slug(site) + '\n'; }

/* ---------------- scripts for platforms without an image ---------------- */
function dockerScript(site, token, o) {
  return '#!/usr/bin/env bash\n' +
    '# OT Sense sensor for site ' + site.replace(/[\r\n]/g, ' ') + '. Run on the Linux machine:   sudo ./install-sensor.sh [folder-with-otsense-docker]\n' +
    '# Needs Docker (installed automatically if missing and internet is available). Contains the site token: keep private.\n' +
    'set -euo pipefail\n[ "$(id -u)" -eq 0 ] || { echo "Please run:  sudo $0"; exit 1; }\n' +
    confText(site, token, o) +
    'SRC="${1:-$(dirname "$(readlink -f "$0")")}"\n' +
    'command -v docker >/dev/null || { curl -fsSL https://get.docker.com | sh; systemctl enable --now docker 2>/dev/null || true; }\n' +
    'if [ -f "$SRC/otsense-image.tar.gz" ]; then docker load -i "$SRC/otsense-image.tar.gz" >/dev/null\n' +
    'elif [ -f "$SRC/Dockerfile" ]; then docker build -q -t otsense:1.3 "$SRC" >/dev/null\n' +
    'else echo "Put this script inside the otsense-docker folder (or pass its path)."; exit 1; fi\n' +
    'P=/opt/otsense-sensor; mkdir -p $P\n' +
    ((o.ca) ? 'cat > $P/ca.crt <<\'EOCA\'\n' + o.ca + '\nEOCA\n' : 'cp /etc/ssl/certs/ca-certificates.crt $P/ca.crt\n') +
    'MGMT="$(ip -o -4 route show default 2>/dev/null | awk \'{print $5; exit}\')"; CAP=""\n' +
    'for n in $(ls /sys/class/net); do case "$n" in lo|docker*|veth*|br-*|virbr*|tun*|tap*|ifb*|bond*|wl*) continue;; esac\n' +
    '  [ -e "/sys/class/net/$n/device" ] || continue; [ "$n" = "$MGMT" ] && continue\n' +
    '  ip -o -4 addr show dev "$n" 2>/dev/null | grep -q . && continue; CAP="$n"; break; done\n' +
    'echo "Management port: ${MGMT:-?}   Capture (SPAN) port: ${CAP:-none found - the sensor will still start and join central}"\n' +
    'docker rm -f otsense-sensor >/dev/null 2>&1 || true\n' +
    'docker run -d --name otsense-sensor --restart unless-stopped --network host --cap-add NET_RAW --cap-add NET_ADMIN \\\n' +
    '  -v otsense-sensor:/data -v $P:/pack:ro -e OTSENSE_SITE="$SITE" -e OTSENSE_CENTRAL="$CENTRAL" -e OTSENSE_TOKEN="$TOKEN" \\\n' +
    '  -e OTSENSE_IFACE="$CAP" -e OTSENSE_MGMT="$MGMT" -e OTSENSE_SCAN="$SCAN" otsense:1.3 sensor >/dev/null\n' +
    'sleep 6; echo; docker logs otsense-sensor 2>&1 | grep -iE "password|error" || true\n' +
    'echo "DONE. The site appears in central within a minute. Sensor page: http://$(hostname -I | awk \'{print $1}\')"\n';
}
function termuxScript(site, token, o) {
  // PHONE: installs python, writes sensor.conf, makes a one-tap shortcut, then opens the OT Sense sensor window (a page in the phone browser).
  // "bash termux-sensor.sh test" keeps the old behaviour: replay the sample capture to prove the link to central.
  return ['#!/data/data/com.termux/files/usr/bin/bash',
    '# OT Sense sensor for an Android phone (Termux). A phone cannot see mirrored (SPAN) traffic and cannot listen to packets without root;',
    '# the device scan is an estimate (TCP probe + ARP table). The link to central, Start/Stop, scan and device list all work without root.',
    'set -e', 'SRC="$(cd "$(dirname "$0")" && pwd)"', 'pkg install -y python openssl >/dev/null',
    '# run from Termux\'s own folder (shared storage such as Downloads does not keep file permissions)', 'mkdir -p "$HOME/otsense"', 'cp -f "$SRC"/otsense.py "$SRC"/sample_ot.pcap "$HOME/otsense/" 2>/dev/null || true', 'cd "$HOME/otsense"',
    "cat > sensor.conf <<'EOCONF'", confText(site, token, o).replace(/\n$/, ''), 'EOCONF',
    '. ./sensor.conf',
    (o.ca ? "cat > ca.crt <<'EOCA'\n" + o.ca + '\nEOCA\nCAOPT="--cafile ca.crt"' : 'CAOPT=""'),
    'if [ "$1" = "test" ]; then',
    '  echo "1) Testing connection to central: $CENTRAL"',
    "  python - \"$CENTRAL\" <<'EOPY' || { echo \"CANNOT REACH CENTRAL - check the address, https, and that central is running\"; exit 1; }",
    'import sys,urllib.request',
    'u=sys.argv[1].rstrip("/")+"/health"',
    'r=urllib.request.urlopen(u,timeout=15);print("   central answered:",r.status)',
    'EOPY',
    '  echo "2) Replaying the sample capture. Open central > Sites to watch. Stop with Ctrl-C."',
    '  OTSENSE_TOKEN="$TOKEN" exec python otsense.py sensor --site "$SITE" --central "$CENTRAL" $CAOPT --pcap sample_ot.pcap --keep-alive --interval 15',
    'fi',
    '# one-tap start: type  otsense  in Termux, or add the Termux:Widget app (F-Droid) and tap "OTSense" on the home screen',
    'LAUNCH=\'#!/data/data/com.termux/files/usr/bin/bash\\ncd "\'"$PWD"\'"\\nexec python otsense.py phone --open\\n\'',
    'mkdir -p "$HOME/.shortcuts"',
    'printf "$LAUNCH" > "$HOME/.shortcuts/OTSense.sh"; chmod +x "$HOME/.shortcuts/OTSense.sh"',
    'printf "$LAUNCH" > "$PREFIX/bin/otsense"; chmod +x "$PREFIX/bin/otsense"',
    'echo "Starting the OT Sense window. Next time just type: otsense"',
    'exec python otsense.py phone --open', ''].join('\n');
}

/* ---------------- tiny CRC32 + ZIP writer (stored, no compression) ---------------- */
const CRC = (function () { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(buf) { let c = 0xFFFFFFFF; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function zip(files) {          // files: [{name, data(Buffer)}]
  const parts = [], cen = []; let off = 0; const d = new Date();
  const dt = ((d.getFullYear() - 1980) << 9 | (d.getMonth() + 1) << 5 | d.getDate()) & 0xFFFF, tm = (d.getHours() << 11 | d.getMinutes() << 5 | (d.getSeconds() >> 1)) & 0xFFFF;
  files.forEach(function (f) {
    const nm = Buffer.from(f.name), c = crc32(f.data), h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(0, 8); h.writeUInt16LE(tm, 10); h.writeUInt16LE(dt, 12);
    h.writeUInt32LE(c, 14); h.writeUInt32LE(f.data.length, 18); h.writeUInt32LE(f.data.length, 22); h.writeUInt16LE(nm.length, 26); h.writeUInt16LE(0, 28);
    parts.push(h, nm, f.data);
    const e = Buffer.alloc(46);
    e.writeUInt32LE(0x02014b50, 0); e.writeUInt16LE(20, 4); e.writeUInt16LE(20, 6); e.writeUInt16LE(0x0800, 8); e.writeUInt16LE(0, 10); e.writeUInt16LE(tm, 12); e.writeUInt16LE(dt, 14);
    e.writeUInt32LE(c, 16); e.writeUInt32LE(f.data.length, 20); e.writeUInt32LE(f.data.length, 24); e.writeUInt16LE(nm.length, 28); e.writeUInt32LE(off, 42);
    cen.push(e, nm); off += 30 + nm.length + f.data.length;
  });
  const cd = Buffer.concat(cen), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat(parts.concat([cd, end]));
}

/* A zip whose LAST file is the big sensor ISO. The ISO is not loaded into memory: the zip is described as head + ISO (read from disk, with this site's 64 KB
   config slot swapped in while sending) + tail, and central streams it. CRC32 is computed once per build over the stamped ISO. */
function crcUpdate(c, buf, from, to) { for (let i = from; i < to; i++) c = CRC[(c ^ buf[i]) & 255] ^ (c >>> 8); return c; }
function crcStampedIso(isoPath, off, slot, size) {
  const fd = fs.openSync(isoPath, 'r'), CH = 4 * 1024 * 1024, buf = Buffer.alloc(CH); let c = 0xFFFFFFFF, pos = 0;
  try {
    while (pos < size) {
      const n = fs.readSync(fd, buf, 0, Math.min(CH, size - pos), pos); if (n <= 0) break;
      const a = Math.max(pos, off), b = Math.min(pos + n, off + SLOT);      // part of this chunk that lies inside the slot: replaced by this site's slot
      if (a < b) slot.copy(buf, a - pos, a - off, b - off);
      c = crcUpdate(c, buf, 0, n); pos += n;
    }
  } finally { fs.closeSync(fd); }
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function zipWithIso(front, isoName, iso, isoSize) {      // front: [{name,data}] small files stored before the ISO
  const d = new Date(), dt = ((d.getFullYear() - 1980) << 9 | (d.getMonth() + 1) << 5 | d.getDate()) & 0xFFFF, tm = (d.getHours() << 11 | d.getMinutes() << 5 | (d.getSeconds() >> 1)) & 0xFFFF;
  const head = [], cen = []; let off = 0;
  const lh = function (nm, c, n) { const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(tm, 10); h.writeUInt16LE(dt, 12);
    h.writeUInt32LE(c, 14); h.writeUInt32LE(n, 18); h.writeUInt32LE(n, 22); h.writeUInt16LE(nm.length, 26); return h; };
  const ce = function (nm, c, n, o) { const e = Buffer.alloc(46); e.writeUInt32LE(0x02014b50, 0); e.writeUInt16LE(20, 4); e.writeUInt16LE(20, 6); e.writeUInt16LE(0x0800, 8); e.writeUInt16LE(tm, 12); e.writeUInt16LE(dt, 14);
    e.writeUInt32LE(c, 16); e.writeUInt32LE(n, 20); e.writeUInt32LE(n, 24); e.writeUInt16LE(nm.length, 28); e.writeUInt32LE(o, 42); cen.push(e, nm); };
  front.forEach(function (f) { const nm = Buffer.from(f.name), c = crc32(f.data); head.push(lh(nm, c, f.data.length), nm, f.data); ce(nm, c, f.data.length, off); off += 30 + nm.length + f.data.length; });
  const nm = Buffer.from(isoName), c = crcStampedIso(iso.path, iso.offset, iso.slot, isoSize);
  head.push(lh(nm, c, isoSize), nm); ce(nm, c, isoSize, off); off += 30 + nm.length + isoSize;
  const cd = Buffer.concat(cen), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(front.length + 1, 8); end.writeUInt16LE(front.length + 1, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  const hb = Buffer.concat(head), tb = Buffer.concat([cd, end]);
  return { head: hb, tail: tb, iso: iso, isoSize: isoSize, size: hb.length + isoSize + tb.length };
}

/* ---------------- minimal ISO9660 + Joliet writer (flat, label CIDATA) ---------------- */
const SEC = 2048;
function both32(n) { const b = Buffer.alloc(8); b.writeUInt32LE(n, 0); b.writeUInt32BE(n, 4); return b; }
function both16(n) { const b = Buffer.alloc(4); b.writeUInt16LE(n, 0); b.writeUInt16BE(n, 2); return b; }
function d7(t) { return Buffer.from([t.getUTCFullYear() - 1900, t.getUTCMonth() + 1, t.getUTCDate(), t.getUTCHours(), t.getUTCMinutes(), t.getUTCSeconds(), 0]); }
function d17(t) { const p = function (n, w) { return String(n).padStart(w, '0'); };
  return Buffer.concat([Buffer.from(p(t.getUTCFullYear(), 4) + p(t.getUTCMonth() + 1, 2) + p(t.getUTCDate(), 2) + p(t.getUTCHours(), 2) + p(t.getUTCMinutes(), 2) + p(t.getUTCSeconds(), 2) + '00'), Buffer.from([0])]); }
function ucs2(s) { const b = Buffer.from(s, 'utf16le'); b.swap16(); return b; }
function dirRec(extent, size, flags, id, t) {
  const pad = id.length % 2 === 0 ? 1 : 0, len = 33 + id.length + pad, b = Buffer.alloc(len);
  b[0] = len; both32(extent).copy(b, 2); both32(size).copy(b, 10); d7(t).copy(b, 18); b[25] = flags; both16(1).copy(b, 28); b[32] = id.length; id.copy(b, 33);
  return b;
}
function padStr(s, n) { return Buffer.from((s + ' '.repeat(n)).slice(0, n), 'latin1'); }
function padU(s, n) { const b = Buffer.alloc(n); for (let i = 0; i < n; i += 2) { b[i] = 0; b[i + 1] = 0x20; } const u = ucs2(s); u.copy(b, 0, 0, Math.min(u.length, n)); return b; }
function sectors(n) { return Math.ceil(n / SEC); }

function isoCidata(files) {     // files: [{name, data}]  -> Buffer
  const t = new Date(), label = 'CIDATA', names = {};
  const fl = files.map(function (f, i) {
    let base = f.name.toUpperCase().replace(/[^A-Z0-9.]/g, '_'), ext = '';
    const dot = base.lastIndexOf('.'); if (dot >= 0) { ext = base.slice(dot + 1, dot + 4); base = base.slice(0, dot); }
    let nm = base.slice(0, 8) + '.' + ext, k = 1; while (names[nm]) nm = base.slice(0, 6) + '_' + (k++) + '.' + ext;
    names[nm] = 1; return { name: f.name, data: f.data, p: nm + ';1' };
  }).sort(function (a, b) { return a.p < b.p ? -1 : 1; });
  // layout (sectors)
  const S_PVD = 16, S_SVD = 17, S_TERM = 18, S_PL = 19, S_PM = 20, S_JL = 21, S_JM = 22, S_PD = 23;
  const dirP = [dirRec(S_PD, SEC, 2, Buffer.from([0]), t), dirRec(S_PD, SEC, 2, Buffer.from([1]), t)];
  const S_JD = S_PD + 1; let next = S_JD + 1;
  fl.forEach(function (f) { f.ext = next; next += Math.max(1, sectors(f.data.length)); });
  const total = next;
  const dirJ = [dirRec(S_JD, SEC, 2, Buffer.from([0]), t), dirRec(S_JD, SEC, 2, Buffer.from([1]), t)];
  fl.forEach(function (f) { dirP.push(dirRec(f.ext, f.data.length, 0, Buffer.from(f.p), t)); dirJ.push(dirRec(f.ext, f.data.length, 0, ucs2(f.name), t)); });
  const dirBuf = function (recs) { const b = Buffer.alloc(SEC); let o = 0; recs.forEach(function (r) { if (o + r.length > SEC) throw new Error('too many files'); r.copy(b, o); o += r.length; }); return b; };
  const pathTable = function (extent, le) { const b = Buffer.alloc(10); b[0] = 1; le ? b.writeUInt32LE(extent, 2) : b.writeUInt32BE(extent, 2); le ? b.writeUInt16LE(1, 6) : b.writeUInt16BE(1, 6); return b; };
  function vd(type, joliet) {
    const b = Buffer.alloc(SEC), S = joliet ? function (s, n) { return padU(s, n); } : function (s, n) { return padStr(s, n); };
    b[0] = type; b.write('CD001', 1, 'latin1'); b[6] = 1;
    S('', 32).copy(b, 8); S(label, 32).copy(b, 40);
    both32(total).copy(b, 80);
    if (joliet) { b[88] = 0x25; b[89] = 0x2F; b[90] = 0x45; }
    both16(1).copy(b, 120); both16(1).copy(b, 124); both16(SEC).copy(b, 128); both32(10).copy(b, 132);
    b.writeUInt32LE(joliet ? S_JL : S_PL, 140); b.writeUInt32BE(joliet ? S_JM : S_PM, 148);
    dirRec(joliet ? S_JD : S_PD, SEC, 2, Buffer.from([0]), t).copy(b, 156);
    S('', 128).copy(b, 190); S('', 128).copy(b, 318); S('OT Sense central', 128).copy(b, 446); S('OT Sense seed', 128).copy(b, 574);
    S('', 37).copy(b, 702); S('', 37).copy(b, 739); S('', 37).copy(b, 776);
    d17(t).copy(b, 813); d17(t).copy(b, 830); Buffer.from('0000000000000000\0', 'latin1').copy(b, 847); d17(t).copy(b, 864); b[881] = 1;
    return b;
  }
  const out = Buffer.alloc(total * SEC), put = function (s, b) { b.copy(out, s * SEC); };
  put(S_PVD, vd(1, false)); put(S_SVD, vd(2, true));
  const term = Buffer.alloc(SEC); term[0] = 255; term.write('CD001', 1, 'latin1'); term[6] = 1; put(S_TERM, term);
  put(S_PL, pathTable(S_PD, true)); put(S_PM, pathTable(S_PD, false)); put(S_JL, pathTable(S_JD, true)); put(S_JM, pathTable(S_JD, false));
  put(S_PD, dirBuf(dirP)); put(S_JD, dirBuf(dirJ));
  fl.forEach(function (f) { f.data.copy(out, f.ext * SEC); });
  return out;
}


/* ---------------- stamping the ONE reusable ISO ---------------- */
const fs = require('fs');
const path = require('path');
const MAGIC = Buffer.from('OTSENSE_SLOT_V1\n', 'latin1');       // 16 bytes, start of the 64 KB placeholder file inside the ISO
const SLOT = 65536, slotCache = {};
function locateSlot(isoPath) {          // find the single placeholder inside the ISO (cached until the file changes)
  const st = fs.statSync(isoPath), c = slotCache[isoPath];
  if (c && c.size === st.size && c.mtime === st.mtimeMs) return c.off;
  const fd = fs.openSync(isoPath, 'r'), CH = 8 * 1024 * 1024, buf = Buffer.alloc(CH + MAGIC.length), hits = [];
  try {
    let pos = 0, carry = 0;
    while (pos < st.size) {
      const n = fs.readSync(fd, buf, carry, CH, pos), len = carry + n; if (n <= 0) break;
      let i = 0; while ((i = buf.indexOf(MAGIC, i)) >= 0 && i < len) { hits.push(pos - carry + i); i += MAGIC.length; }
      carry = Math.min(MAGIC.length - 1, len); buf.copy(buf, 0, len - carry, len); pos += n;
    }
  } finally { fs.closeSync(fd); }
  if (hits.length !== 1) throw new Error('the base ISO is not valid (found ' + hits.length + ' config slots, expected 1) - rebuild it with build-iso.sh');
  slotCache[isoPath] = { size: st.size, mtime: st.mtimeMs, off: hits[0] };
  return hits[0];
}
function slotBuffer(site, token, o, consolePw) {
  const j = Buffer.from(JSON.stringify({ v: 1, site: site, central: o.central, token: token, mode: o.mode, ip_cidr: o.cidr, gateway: o.gw, dns: o.dns,
    ca_pem: o.ca || '', scan: o.scan, console_password: consolePw, created: new Date().toISOString() }));
  if (j.length > SLOT - 20) throw new Error('settings too large for the config slot (CA certificate too long?)');
  const b = Buffer.alloc(SLOT); MAGIC.copy(b, 0); b.writeUInt32BE(j.length, 16); j.copy(b, 20); return b;
}
function windowsScript(site, isoName) {
  const q = function (x) { return String(x).replace(/'/g, "''"); };
  return ["# Creates a Hyper-V VM for the OT Sense sensor of site '" + q(site) + "'. Run in PowerShell as Administrator, ISO in the same folder.",
    "$ErrorActionPreference='Stop'; $Name='OTSense-" + slug(site) + "'; $iso=Join-Path $PSScriptRoot '" + isoName + "'",
    "if(-not (Test-Path $iso)){ throw 'Put ' + $iso + ' next to this script' }",
    "$sw=@(Get-VMSwitch); if($sw.Count -lt 1){ throw 'Create a Hyper-V virtual switch first (Hyper-V Manager > Virtual Switch Manager)' }",
    "$i=0; $sw | ForEach-Object { $i++; \"$i. $($_.Name)\" }",
    "$m=[int](Read-Host 'Number of the switch for the NORMAL network (management)')-1; $c=[int](Read-Host 'Number of the switch that receives the MIRROR/SPAN traffic (capture)')-1",
    "New-VM -Name $Name -Generation 2 -MemoryStartupBytes 4GB -NoVHD -SwitchName $sw[$m].Name | Out-Null",
    "Set-VMProcessor -VMName $Name -Count 2; Set-VMFirmware -VMName $Name -EnableSecureBoot Off",
    "Add-VMNetworkAdapter -VMName $Name -Name Capture -SwitchName $sw[$c].Name; Set-VMNetworkAdapter -VMName $Name -Name Capture -PortMirroring Destination",
    "Add-VMDvdDrive -VMName $Name -Path $iso; Set-VMFirmware -VMName $Name -FirstBootDevice (Get-VMDvdDrive -VMName $Name)",
    "Start-VM -Name $Name; Write-Host \"Started $Name. Its web address appears on the VM console in about a minute; the site turns green in central.\"", ''].join('\r\n');
}

/* ---------------- main entry ---------------- */
function vmReadme(site, o, consolePw) {
  return ['OT Sense sensor for Windows (runs as a Linux VM) - site: ' + site, '',
    'Why: a normal Windows program cannot send real ARP requests or see MAC addresses. This app runs the OT Sense sensor as a small Linux',
    'virtual machine on your PC, connected to the Wi-Fi/Ethernet adapter you choose, so it scans that network properly.', '',
    'HOW TO USE (3 steps)',
    '1. Right-click this zip > Extract All (for example to C:\\OTSense). Do not run the app from inside the zip. Keep the files together.',
    '2. Double-click OTSense-VM.exe. Click YES at the Windows administrator question. If Windows says \"protected your PC\": More info > Run anyway.',
    '3. Choose your Wi-Fi in the list (it is pre-selected when it is connected) and press the big START button.',
    '   After 1-3 minutes this site turns green in central. Press STOP to switch the sensor off.', '',
    'If the app says it needs VM software, press the button it shows:',
    '   - \"Turn on Hyper-V\"   (Windows Pro/Enterprise only; the PC restarts once, then open the app again)',
    '   - \"Install VirtualBox\" (free, any Windows edition; installs automatically, or opens the download page)', '',
    'Scanning: ' + o.scan + ' (central can change Passive/Active per site on the Sites tab).',
    'Sensor IP: ' + (o.mode === 'static' ? o.cidr + ' (gateway ' + o.gw + ')' : 'automatic (DHCP)'),
    'Over Wi-Fi some routers refuse a second device (the sensor) on the same Wi-Fi: if the sensor never turns green, try a network cable (Ethernet).',
    'Closing the window asks whether the sensor keeps running in the background.',
    'Console login for troubleshooting (shown on the VM screen): otsense / ' + consolePw, 'This zip contains the site token - keep it private.', ''].join('\n');
}
function readme(site, p, o, consolePw) {
  if (p.seed === 'winvm') return vmReadme(site, o, consolePw);
  const L = ['OT Sense sensor for site: ' + site, 'Platform: ' + p.label, ''];
  if (p.seed === 'stamp') L.push('1. Use the downloaded file ' + 'otsense-sensor-' + slug(site) + '.iso - it already contains this site\'s settings. Nothing else to download or type.',
    '2. The sensor needs TWO network ports: port 1 = normal network, port 2 = mirror/SPAN port (no IP).',
    p.platform === 'windows' ? '3. Put the .ps1 script next to the ISO, right-click > Run with PowerShell (as Administrator), answer the two questions.' :
    p.platform === 'pc' ? '3. Write the ISO to a USB stick (Rufus: DD mode, or balenaEtcher), boot the PC from it (disable Secure Boot). Keep the stick plugged in.' :
    '3. Create a VM (Linux 64-bit, 2 vCPU, 4 GB RAM, no disk needed), attach the ISO as CD/DVD, add two network adapters, disable Secure Boot, power on. ESXi: capture port group needs Promiscuous = Accept.');
  else if (p.seed === 'iso') L.push('1. Create a new virtual machine from the base image ' + p.image + ' (ask your administrator for this file).',
    '2. Give the VM TWO network adapters: adapter 1 = normal network, adapter 2 = the port group that receives the mirror/SPAN traffic.',
    '3. Attach the seed ISO (otsense-seed-' + slug(site) + '.iso) to the VM as a CD/DVD drive, then power on.');
  else if (p.seed === 'zip') L.push('1. Write ' + p.image + ' to the USB stick / SSD / SD card (Raspberry Pi Imager, balenaEtcher or Rufus).',
    p.platform === 'rpi' ? '2. Open the boot partition of the card and copy the files from this zip (user-data, meta-data) onto it.' :
      '2. Format a second small USB stick as FAT32 with the label CIDATA and copy the files from this zip onto it. Keep it plugged in for the first boot.',
    '3. Plug the first network port into the normal network and the second (USB/second NIC) into the switch mirror/SPAN port, then power on.');
  if (o.platform === 'android') return ['OT Sense sensor for an Android phone - site: ' + site, '',
    'IF YOU GOT OTSense-Sensor-*.apk: copy it to the phone and open it (allow "install unknown apps" once), tap Install, open OT Sense. The server address, site name, site token and scanning (' + o.scan + ') are already inside - it connects and starts by itself. Nothing to type.',
    'If an older OT Sense app is already on the phone, uninstall it first (this app is signed by this central, so it cannot install over an app from another source).',
    'IF YOU GOT A ZIP instead (no app on the server yet), use Termux:', '',
    '1. Install Termux from F-Droid (the Play Store version is outdated). Optional for a home-screen icon: Termux:Widget from F-Droid.',
    '2. Unzip this file on the phone, then in Termux run:   bash /sdcard/Download/otsense-phone/termux-sensor.sh     (adjust the folder; first time: termux-setup-storage)',
    '3. The OT Sense sensor window opens in your phone browser. Press START. Choose Passive or Active, press Scan devices now, and watch Devices found.',
    '4. Next time: type  otsense  in Termux, or tap OTSense in the Termux:Widget.',
    '', 'What works without root: connection to central, Start/Stop, device scan on the Wi-Fi you are on (an ESTIMATE - phones that drop probes are missed).',
    'What does not: listening to packets (Packets stays 0) and mirrored/SPAN traffic. For those use the Windows app or a Raspberry Pi / laptop sensor.',
    'Connection test only (no window):   bash termux-sensor.sh test', '', 'This pack contains the site token - keep it private.'].join('\n') + '\n';
  L.push('', 'First boot takes 2-5 minutes. The sensor then shows up under Sites in central and its web page address appears on the console screen.');
  L.push('Sensor IP: ' + (o.mode === 'static' ? o.cidr + ' (gateway ' + o.gw + ')' : 'automatic (DHCP)'));
  L.push('Console login for troubleshooting: otsense / ' + consolePw, 'This pack contains the site token - keep it private.');
  return L.join('\n') + '\n';
}

/* ---------------- Windows app pack ---------------- */
function winConf(site, token, o) {
  const one = function (v) { return String(v).replace(/[\r\n]+/g, ' ').trim(); };
  return ['# OT Sense sensor settings for Windows (written by central). Contains the site token - keep this folder private.',
    'SITE=' + one(site), 'CENTRAL=' + one(o.central), 'TOKEN=' + one(token),
    '# passive = only listen (default). active = also probe this PC\'s own network. Central can override this per site; the sensor page (below) can change it too.',
    'SCAN=' + (o.survey ? 'active' : o.scan), (o.survey ? 'SURVEY_MIN=' + o.survey : '# SURVEY_MIN=10   (add this line for a one-time survey: listen + scan for 10 minutes, send to central, then stop)'), 'UI_PORT=8099', 'INTERVAL=30', '# The OT Sense window picks the network adapter for you and saves it here as ADAPTER=<its IP address>. You normally never edit this file.', '# MINUTES=0   (window: stop by itself after this many minutes, 0 = until you press Stop)', '# IFACE=   (only for the text mode:  OTSense-Sensor.exe run  )', ''].join('\n');
}
function winReadme(site, o, full) {
  return ['OT Sense sensor for Windows - site: ' + site, '',
    '1. Unzip this folder somewhere permanent (for example C:\\OTSense). Keep all files together.',
    '2. Double-click OTSense-Sensor.exe.',
    '   - Windows may say "Windows protected your PC" (the program is not code-signed): click More info > Run anyway.',
    full ? '   - Nothing else to install for scanning: Python and everything else is inside the exe.' : '   - First run only: it installs what is missing, using winget (built into Windows 10/11, needs internet):',
    full ? '   - Nothing to install. Right-click the exe > Run as administrator so it can listen passively (built-in Windows listening: IP traffic only, no MAC/ARP). Npcap is optional and only adds full detail.' : '       Python 3 (for you only), the "scapy" package, and Npcap (the capture driver; accept the administrator prompt, keep the default options).',
    full ? '' : '   - No internet on this PC? Install Python 3 and Npcap from an installer you carry in, and put the scapy .whl files in a folder called "wheels" next to the exe.',
    o.survey ? '3. ONE-TIME SURVEY: click Yes if Windows asks for permission. The OT Sense window opens with the time already set to ' + o.survey + ' minutes and ACTIVE scanning. Press Start and leave the PC on and connected; it stops and sends by itself. Nothing else to do.' : '3. The OT Sense window opens (nothing opens in your browser). Choose the NETWORK ADAPTER (Ethernet or Wi-Fi), choose PASSIVE (only listen) or ACTIVE (also ask every device on that adapter\'s network) and press START. Press STOP when you are done - nothing runs while it is stopped.',
    '   The window shows every packet, a progress bar, whether the device scan is finished and how many devices it found.',
    '   Server tab: Test connection checks name, network, certificate and site token. If the server cannot be reached, Export inventory saves the results as files (csv/json/html) on this PC.',
    '   Central can also set Passive/Active for the whole site (Sites tab); then the window shows \"set by central\".',
    '4. After Start the site turns green in central within a minute.',
    '', 'Start automatically when you sign in to Windows:  OTSense-Sensor.exe install     (undo:  OTSense-Sensor.exe uninstall)',
    'Text mode (no window, old behaviour):  OTSense-Sensor.exe run        List network cards:  OTSense-Sensor.exe ifaces',
    '', 'Listening to a mirrored (SPAN) port: plug this PC into the mirror port and choose that network adapter in the window.',
    'On a normal port a PC only sees its own traffic plus broadcasts - passive mode then finds few devices; use Active mode or a SPAN port.',
    'Scanning now: ' + o.scan + '.', 'Log file: otsense-sensor.log (when started automatically).', ''].join('\n');
}

function findApk(ctx) {
  const c = [ctx.apk, ctx.isoPath && path.join(path.dirname(ctx.isoPath), 'android', 'OTSense-Sensor.apk'), ctx.isoPath && path.join(path.dirname(ctx.isoPath), 'OTSense-Sensor.apk')];
  for (const f of c) if (f && fs.existsSync(f)) return f;
  return '';
}

function build(site, token, b, ctx) {
  ctx = ctx || {};
  const o = cleanOptions(b), p = Object.assign({ platform: o.platform }, PLATFORMS[o.platform]);
  const pw = ctx.pw || crypto.randomBytes(9).toString('base64url'), s = slug(site), files = [];
  if (p.seed === 'stamp' || p.seed === 'winvm') {
    if (!ctx.isoPath || !fs.existsSync(ctx.isoPath)) throw new Error('the base ISO (' + ISO_NAME + ') is not on the central server yet - open the Sites tab and press "Build base ISO" once (it is then saved and reused for every sensor)');
    const off = locateSlot(ctx.isoPath), nm = 'otsense-sensor-' + s + '.iso', isoSize = fs.statSync(ctx.isoPath).size, iso = { path: ctx.isoPath, offset: off, slot: slotBuffer(site, token, o, pw) };
    if (p.seed === 'winvm') {      // ONE zip: the launcher app + this site's settings + the stamped sensor ISO. Unzip, double-click OTSense-VM.exe.
      if (!ctx.vmExe || !fs.existsSync(ctx.vmExe)) throw new Error('the Windows VM app (OTSense-VM.exe) is not on this server yet: on the Sites tab, Base images box, choose "Windows VM app", paste the GitHub link of OTSense-VM.exe and press Import (central looked here: ' + (ctx.vmDiag || 'nowhere') + ')');
      const conf = ['# OT Sense VM launcher settings (written by central)', 'SITE=' + site.replace(/[\r\n]+/g, ' '), 'ISO=' + nm, 'CENTRAL=' + o.central, 'SCAN=' + o.scan, ''].join('\r\n');
      const z = zipWithIso([{ name: 'OTSense-VM.exe', data: fs.readFileSync(ctx.vmExe) }, { name: 'vm.conf', data: Buffer.from(conf) },
        { name: 'READ-ME.txt', data: Buffer.from(vmReadme(site, o, pw).replace(/\n/g, '\r\n')) }], nm, iso, isoSize);
      files.push({ name: 'OTSense-VM-' + s + '.zip', bundle: z, size: z.size, type: 'application/zip' });
    } else files.push({ name: nm, iso: iso, size: isoSize, type: 'application/x-iso9660-image' });
  } else if (p.seed === 'winapp') {      // Windows: a real .exe launcher + the sensor script + this site's settings, in one zip. No VM, no ISO.
    const full = ctx.winFull && fs.existsSync(ctx.winFull);      // FULL app (built by the GitHub workflow): Python + scapy + sensor all inside one exe
    if (!full) {
      if (!ctx.winExe || !fs.existsSync(ctx.winExe)) throw new Error('no Windows app on this server: put the full OTSense-Sensor.exe (from the GitHub build) into the base-images folder (central looked here: ' + (ctx.winDiag || 'nowhere') + ')');
      if (!ctx.srcDir || !fs.existsSync(path.join(ctx.srcDir, 'otsense.py'))) throw new Error('otsense.py is missing in sensor-src on the server');
    }
    const inc = [{ name: 'OTSense-Sensor.exe', data: fs.readFileSync(full ? ctx.winFull : ctx.winExe) }]
      .concat(full ? [] : [{ name: 'otsense.py', data: fs.readFileSync(path.join(ctx.srcDir, 'otsense.py')) }]).concat([
      { name: 'sensor.conf', data: Buffer.from(winConf(site, token, o).replace(/\n/g, '\r\n')) },
      { name: 'READ-ME.txt', data: Buffer.from(winReadme(site, o, full).replace(/\n/g, '\r\n')) }]);
    if (o.ca) inc.push({ name: 'ca.crt', data: Buffer.from(o.ca + '\n') });
    files.push({ name: 'otsense-sensor-windows-' + s + '.zip', data: zip(inc), type: 'application/zip' });
  } else if (p.seed === 'script') {
    const isDocker = o.platform === 'docker';
    if (isDocker) files.push({ name: 'install-sensor.sh', data: Buffer.from(dockerScript(site, token, o)), type: 'text/x-shellscript' });
    else if (o.platform === 'android' && findApk(ctx)) {      // phone: the real app, stamped with THIS site's settings and signed by central. Install, open, done.
      const apkSign = require('./apksign');
      const preset = { v: 1, id: crypto.randomBytes(8).toString('hex'), site: site, central: o.central, token: token, scan: o.scan, interval: 30, insecure: false, autostart: true, ca_pem: o.ca || '' };
      let apkBuf;
      try { apkBuf = apkSign.stamp(fs.readFileSync(findApk(ctx)), preset, ctx.apkKey || path.join(process.env.DATA_DIR || path.join(__dirname, 'data'), 'apk-signing.json')); }
      catch (e) { throw new Error('could not prepare the Android app: ' + e.message); }
      files.push({ name: 'OTSense-Sensor-' + s + '.apk', data: apkBuf, type: 'application/vnd.android.package-archive' });
    }
    else if (ctx.srcDir && fs.existsSync(path.join(ctx.srcDir, 'otsense.py'))) {      // phone (no app on this server): Termux zip (script + sensor + sample capture)
      const inc = ['otsense.py', 'sample_ot.pcap'].map(function (n) { return { name: n, data: fs.readFileSync(path.join(ctx.srcDir, n)) }; });
      inc.unshift({ name: 'termux-sensor.sh', data: Buffer.from(termuxScript(site, token, o)) });
      files.push({ name: 'otsense-phone-' + s + '.zip', data: zip(inc), type: 'application/zip' });
    } else files.push({ name: 'termux-sensor.sh', data: Buffer.from(termuxScript(site, token, o)), type: 'text/x-shellscript' });
  } else {
    const seed = [{ name: 'user-data', data: Buffer.from(userData(site, token, o, pw)) }, { name: 'meta-data', data: Buffer.from(metaData(site)) }];
    if (p.seed === 'iso') files.push({ name: 'otsense-seed-' + s + '.iso', data: isoCidata(seed), type: 'application/x-iso9660-image' });
    files.push({ name: 'otsense-seed-' + s + '.zip', data: zip(seed), type: 'application/zip' });
  }
  files.push({ name: 'READ-ME-' + s + '.txt', data: Buffer.from(readme(site, p, o, pw)), type: 'text/plain' });
  return { files: files, options: { platform: o.platform, mode: o.mode, ip: o.cidr, central: o.central }, console_password: (p.seed === 'script' || p.seed === 'winapp') ? '' : pw, image: p.image, label: p.label,
    hint: p.seed === 'winvm' ? 'Download the ONE zip (about 300 MB), copy it to the Windows PC, Extract All, then double-click OTSense-VM.exe and press START. Details are in READ-ME inside the zip.' : p.seed === 'winapp' ? 'Copy the zip to the Windows PC, unzip it to a folder (e.g. C:\\OTSense), double-click OTSense-Sensor.exe. Details are inside the zip in READ-ME.txt.' : '' };
}

module.exports = { SLOT, PLATFORMS, locateSlot, build, isoCidata, zip, zipWithIso, crc32 };
