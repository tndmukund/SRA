#!/usr/bin/env python3
"""OTSuraksha remote-access helper.

Run this on YOUR computer while a remote-access session is approved. It opens local addresses and forwards what you connect to
them, through OTSuraksha Central and the site sensor, to the approved device only. Nothing here needs installing (Python 3 only).

  Windows : double-click this file, or:  py ra-helper.py
  Then, for example:  Remote Desktop to 127.0.0.2   |   Studio 5000 / RSLinx: add an EtherNet/IP station 127.0.0.2

It stops by itself when the session ends. Press Ctrl+C to stop sooner.
"""
import http.client, json, socket, ssl, sys, threading, time, urllib.parse

CONFIG = json.loads(r'''__CONFIG__''')


class Link:
    """One keep-alive HTTPS connection to central (one per direction per forwarded connection)."""
    def __init__(self):
        u = urllib.parse.urlparse(CONFIG["url"])
        self.tls = u.scheme == "https"
        self.host, self.port = u.hostname, u.port or (443 if self.tls else 80)
        self.base = u.path.rstrip("/")
        self.c = None

    def req(self, method, path, body=None, timeout=40):
        for attempt in (0, 1):
            try:
                if self.c is None:
                    self.c = (http.client.HTTPSConnection(self.host, self.port, timeout=timeout, context=ssl.create_default_context())
                              if self.tls else http.client.HTTPConnection(self.host, self.port, timeout=timeout))
                self.c.timeout = timeout
                if self.c.sock:
                    self.c.sock.settimeout(timeout)
                self.c.request(method, self.base + path, body=body, headers={
                    "Authorization": "Bearer " + CONFIG["token"], "Content-Type": "application/octet-stream", "Connection": "keep-alive"})
                r = self.c.getresponse()
                data = r.read()
                return r.status, dict((k.lower(), v) for k, v in r.getheaders()), data
            except Exception:
                try:
                    self.c.close()
                except Exception:
                    pass
                self.c = None
                if attempt:
                    raise
        return 0, {}, b""


def log(m):
    print(time.strftime("%H:%M:%S ") + m, flush=True)


def forward(sock, port):
    up, down = Link(), Link()
    try:
        st, _h, d = up.req("POST", "/api/ra/h/open?port=%d" % port, b"")
        if st != 200:
            log("central refused the connection (%s): %s" % (st, d[:200].decode("utf-8", "replace")))
            return
        ch = json.loads(d)["ch"]
    except Exception as e:
        log("cannot reach central: %s" % e)
        return
    done = threading.Event()

    def pump_up():
        try:
            while not done.is_set():
                b = sock.recv(32768)
                if not b:
                    break
                while True:
                    st, _h, _d = up.req("POST", "/api/ra/h/send?ch=" + ch, b)
                    if st == 200:
                        break
                    if st == 429:
                        time.sleep(0.05)
                        continue
                    raise IOError("send failed (%s)" % st)
        except Exception:
            pass
        finally:
            done.set()
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass

    t = threading.Thread(target=pump_up, daemon=True)
    t.start()
    try:
        while not done.is_set():
            st, h, d = down.req("GET", "/api/ra/h/recv?ch=%s&wait=20" % ch, timeout=45)
            if st == 200 and d:
                sock.sendall(d)
            if st >= 400 or h.get("x-closed"):
                if h.get("x-error"):
                    log("the sensor could not reach the device: " + urllib.parse.unquote(h["x-error"]))
                break
    except Exception:
        pass
    finally:
        done.set()
        try:
            up.req("POST", "/api/ra/h/close?ch=" + ch, b"")
        except Exception:
            pass
        try:
            sock.shutdown(socket.SHUT_RDWR)      # wakes the other thread that is waiting in recv()
        except Exception:
            pass
        try:
            sock.close()
        except Exception:
            pass


def listen(bind, port):
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((bind, port))
    except OSError as e:
        log("cannot listen on %s:%d (%s). Is another program using it? Use --bind to pick another local address." % (bind, port, e))
        return False
    s.listen(16)
    log("ready: connect to %s port %d  ->  %s" % (bind, port, CONFIG["ip"]))

    def loop():
        while True:
            c, _a = s.accept()
            c.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            threading.Thread(target=forward, args=(c, port), daemon=True).start()
    threading.Thread(target=loop, daemon=True).start()
    return True


def main():
    bind = CONFIG.get("bind") or "127.0.0.2"
    if "--bind" in sys.argv:
        bind = sys.argv[sys.argv.index("--bind") + 1]
    log("OTSuraksha remote access: %s  (device %s)" % (CONFIG.get("name", ""), CONFIG["ip"]))
    log("this session ends at %s" % time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(CONFIG["expires"])))
    ok = [listen(bind, int(p)) for p in CONFIG["ports"]]
    if not any(ok):
        input("Press Enter to close")
        return
    try:
        while time.time() < CONFIG["expires"]:
            time.sleep(1)
        log("session time is over - closing")
    except KeyboardInterrupt:
        log("stopped")


if __name__ == "__main__":
    main()
