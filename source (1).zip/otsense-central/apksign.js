/*
 * OT Sense Central - APK stamper (zero npm packages).
 *
 * Takes the generic OTSense-Sensor.apk, adds ONE small file (assets/otsense-preset.json = this site's server address, site name,
 * token, scanning mode) and signs the result again with central's own key (APK Signature Scheme v2, RSA-2048 / SHA-256).
 * The app finds the file on first start and connects to central by itself - nothing to type.
 *
 * The signing key is made once, on first use, and kept in DATA_DIR/apk-signing.json (private: it is the identity of your sensors).
 * Every sensor APK from this central carries the same signature, so a newer APK installs over an older one.
 * Command line (for a test):  node apksign.js stamp in.apk out.apk preset.json [key.json]     node apksign.js sign in.apk out.apk [key.json]
 */
'use strict';
const crypto = require('crypto');
const fs = require('fs');

const PRESET_NAME = 'assets/otsense-preset.json';
const V2_ID = 0x7109871a;

/* ---------------- tiny DER writer (for the self-signed certificate) ---------------- */
function derLen(n) { if (n < 128) return Buffer.from([n]); const b = []; while (n > 0) { b.unshift(n & 255); n = Math.floor(n / 256); } return Buffer.from([0x80 | b.length].concat(b)); }
function der(tag, body) { body = Buffer.isBuffer(body) ? body : Buffer.concat(body); return Buffer.concat([Buffer.from([tag]), derLen(body.length), body]); }
function derInt(buf) { let b = Buffer.from(buf); while (b.length > 1 && b[0] === 0 && !(b[1] & 0x80)) b = b.subarray(1); if (b[0] & 0x80) b = Buffer.concat([Buffer.from([0]), b]); return der(0x02, b); }
function derOid(s) { const p = s.split('.').map(Number), out = [p[0] * 40 + p[1]]; for (const v0 of p.slice(2)) { let v = v0; const t = [v & 127]; v = Math.floor(v / 128); while (v > 0) { t.unshift((v & 127) | 128); v = Math.floor(v / 128); } out.push.apply(out, t); } return der(0x06, Buffer.from(out)); }
function derTime(d) { const p = function (n) { return String(n).padStart(2, '0'); }; return der(0x17, Buffer.from(String(d.getUTCFullYear()).slice(2) + p(d.getUTCMonth() + 1) + p(d.getUTCDate()) + p(d.getUTCHours()) + p(d.getUTCMinutes()) + p(d.getUTCSeconds()) + 'Z')); }
function derName(cn) { return der(0x30, [der(0x31, [der(0x30, [derOid('2.5.4.3'), der(0x0c, Buffer.from(cn))])])]); }

function makeCert(priv, pubDer, cn) {
  const algo = der(0x30, [derOid('1.2.840.113549.1.1.11'), Buffer.from([0x05, 0x00])]);        // sha256WithRSAEncryption
  const now = new Date(), end = new Date(Date.UTC(now.getUTCFullYear() + 20, now.getUTCMonth(), now.getUTCDate()));
  const tbs = der(0x30, [der(0xa0, [derInt(Buffer.from([2]))]), derInt(crypto.randomBytes(12)), algo, derName(cn),
    der(0x30, [derTime(new Date(now.getTime() - 86400000)), derTime(end)]), derName(cn), pubDer]);
  const sig = crypto.sign('sha256', tbs, priv);
  return der(0x30, [tbs, algo, der(0x03, Buffer.concat([Buffer.from([0]), sig]))]);
}

function loadKey(file) {
  let j = null;
  try { j = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { j = null; }
  if (!j || !j.key || !j.cert) {
    const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
    const pubDer = kp.publicKey.export({ type: 'spki', format: 'der' });
    j = { key: kp.privateKey.export({ type: 'pkcs8', format: 'pem' }), cert: makeCert(kp.privateKey, pubDer, 'OT Sense Central sensors').toString('base64'), made: new Date().toISOString() };
    fs.writeFileSync(file, JSON.stringify(j, null, 1), { mode: 0o600 });
  }
  const priv = crypto.createPrivateKey(j.key);
  return { priv: priv, pub: crypto.createPublicKey(priv).export({ type: 'spki', format: 'der' }), cert: Buffer.from(j.cert, 'base64') };
}

/* ---------------- zip reading / appending ---------------- */
function findEocd(b) { for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) if (b.readUInt32LE(i) === 0x06054b50) return i; throw new Error('not a zip / APK file'); }
function u32(n) { const b = Buffer.alloc(4); b.writeUInt32LE(n >>> 0); return b; }
function u64(n) { const b = Buffer.alloc(8); b.writeBigUInt64LE(BigInt(n)); return b; }
function lp(buf) { return Buffer.concat([u32(buf.length), buf]); }
const CRC_T = (function () { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc(buf) { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = CRC_T[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }

/* split an APK into: entries (all local records), central directory records, and drop an existing signing block */
function parse(apk) {
  const e = findEocd(apk), n = apk.readUInt16LE(e + 10);
  let cdSize = apk.readUInt32LE(e + 12), cdOff = apk.readUInt32LE(e + 16), start = cdOff;
  if (apk.subarray(cdOff - 16, cdOff).toString('latin1') === 'APK Sig Block 42') start = cdOff - Number(apk.readBigUInt64LE(cdOff - 24)) - 8;
  const recs = []; let p = cdOff;
  for (let i = 0; i < n; i++) {
    if (apk.readUInt32LE(p) !== 0x02014b50) throw new Error('bad central directory');
    const nl = apk.readUInt16LE(p + 28), el = apk.readUInt16LE(p + 30), cl = apk.readUInt16LE(p + 32), len = 46 + nl + el + cl;
    recs.push({ name: apk.subarray(p + 46, p + 46 + nl).toString('utf8'), raw: Buffer.from(apk.subarray(p, p + len)) });
    p += len;
  }
  return { entries: apk.subarray(0, start), recs: recs, count: n };
}

function addEntry(entries, recs, name, data) {
  const nb = Buffer.from(name, 'utf8'), off = entries.length;
  let pad = (4 - ((off + 30 + nb.length) % 4)) % 4;                  // keep the data 4-byte aligned like zipalign does
  const extra = Buffer.alloc(pad), c = crc(data), t = new Date();
  const dt = ((t.getFullYear() - 1980) << 9 | (t.getMonth() + 1) << 5 | t.getDate()) & 0xffff, tm = (t.getHours() << 11 | t.getMinutes() << 5 | (t.getSeconds() >> 1)) & 0xffff;
  const h = Buffer.alloc(30);
  h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(10, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(0, 8); h.writeUInt16LE(tm, 10); h.writeUInt16LE(dt, 12);
  h.writeUInt32LE(c, 14); h.writeUInt32LE(data.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(nb.length, 26); h.writeUInt16LE(extra.length, 28);
  const cd = Buffer.alloc(46);
  cd.writeUInt32LE(0x02014b50, 0); cd.writeUInt16LE(0x031e, 4); cd.writeUInt16LE(10, 6); cd.writeUInt16LE(0x0800, 8); cd.writeUInt16LE(0, 10); cd.writeUInt16LE(tm, 12); cd.writeUInt16LE(dt, 14);
  cd.writeUInt32LE(c, 16); cd.writeUInt32LE(data.length, 20); cd.writeUInt32LE(data.length, 24); cd.writeUInt16LE(nb.length, 28); cd.writeUInt32LE(0x81a40000, 38); cd.writeUInt32LE(off, 42);
  return { entries: Buffer.concat([entries, h, nb, extra, data]), recs: recs.concat([{ name: name, raw: Buffer.concat([cd, nb]) }]) };
}

/* ---------------- APK Signature Scheme v2 ---------------- */
function chunkDigest(parts) {
  const hs = [];
  for (const part of parts) for (let i = 0; i < part.length; i += 1 << 20) {
    const c = part.subarray(i, Math.min(part.length, i + (1 << 20)));
    hs.push(crypto.createHash('sha256').update(Buffer.concat([Buffer.from([0xa5]), u32(c.length), c])).digest());
  }
  return crypto.createHash('sha256').update(Buffer.concat([Buffer.from([0x5a]), u32(hs.length)].concat(hs))).digest();
}

function signParts(entries, cdBuf, key) {
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  const count = (function () { let n = 0, p = 0; while (p < cdBuf.length) { n++; p += 46 + cdBuf.readUInt16LE(p + 28) + cdBuf.readUInt16LE(p + 30) + cdBuf.readUInt16LE(p + 32); } return n; })();
  eocd.writeUInt16LE(count, 8); eocd.writeUInt16LE(count, 10); eocd.writeUInt32LE(cdBuf.length, 12);
  const dEocd = Buffer.from(eocd); dEocd.writeUInt32LE(entries.length, 16);        // for the digest the directory "starts" where the signing block starts
  const dig = chunkDigest([entries, cdBuf, dEocd]);
  const signed = Buffer.concat([lp(lp(Buffer.concat([u32(0x103), lp(dig)]))), lp(lp(key.cert)), lp(Buffer.alloc(0))]);
  const sig = crypto.sign('sha256', signed, key.priv);                               // RSASSA-PKCS1-v1_5 + SHA-256 = algorithm 0x0103
  const signer = Buffer.concat([lp(signed), lp(lp(Buffer.concat([u32(0x103), lp(sig)]))), lp(key.pub)]);
  const value = lp(lp(signer)), pair = Buffer.concat([u64(value.length + 4), u32(V2_ID), value]);
  const size = pair.length + 24, block = Buffer.concat([u64(size), pair, u64(size), Buffer.from('APK Sig Block 42', 'latin1')]);
  eocd.writeUInt32LE(entries.length + block.length, 16);
  return Buffer.concat([entries, block, cdBuf, eocd]);
}

function sign(apk, keyFile) {
  const p = parse(apk);
  if (p.recs.some(function (r) { return /^META-INF\/[^\/]+\.(SF|RSA|DSA|EC)$/i.test(r.name); })) throw new Error('this APK has an old-style (v1) signature; use the APK exactly as built by gradle (v2 signed) or unsigned');
  return signParts(p.entries, Buffer.concat(p.recs.map(function (r) { return r.raw; })), loadKey(keyFile));
}

/* stamp: add/replace assets/otsense-preset.json and sign again */
function stamp(apk, preset, keyFile) {
  const p = parse(apk);
  if (p.recs.some(function (r) { return /^META-INF\/[^\/]+\.(SF|RSA|DSA|EC)$/i.test(r.name); })) throw new Error('this APK has an old-style (v1) signature; use the APK exactly as built by gradle (v2 signed) or unsigned');
  if (p.recs.some(function (r) { return r.name === PRESET_NAME; })) throw new Error('this APK is already stamped for a site; stamp the generic OTSense-Sensor.apk instead');
  const a = addEntry(p.entries, p.recs, PRESET_NAME, Buffer.from(JSON.stringify(preset)));
  return signParts(a.entries, Buffer.concat(a.recs.map(function (r) { return r.raw; })), loadKey(keyFile));
}

module.exports = { stamp, sign, loadKey, PRESET_NAME, parse };

if (require.main === module) {
  const a = process.argv.slice(2);
  try {
    if (a[0] === 'stamp') fs.writeFileSync(a[2], stamp(fs.readFileSync(a[1]), JSON.parse(fs.readFileSync(a[3], 'utf8')), a[4] || 'apk-signing.json'));
    else if (a[0] === 'sign') fs.writeFileSync(a[2], sign(fs.readFileSync(a[1]), a[3] || 'apk-signing.json'));
    else { console.log('usage: node apksign.js stamp in.apk out.apk preset.json [key.json]\n       node apksign.js sign in.apk out.apk [key.json]'); process.exit(1); }
    console.log('written', a[2]);
  } catch (e) { console.error('ERROR: ' + e.message); process.exit(1); }
}
