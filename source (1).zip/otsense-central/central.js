/*
 * OTSuraksha Central (Node.js) - all-site management console.
 * Accepts pushes from the existing OTSense sensors (Raspberry Pi) unchanged:
 *   POST /api/ingest        Bearer <site token>, gzip JSON
 *   POST /api/sensor-auth   Bearer <site token>, checks console logins for the sensor page
 * Zero npm packages: run with  node central.js
 * The console page is public/index.html (keep the public folder next to this file).
 *
 * Optional environment variables:
 *   PORT            listen port (Plesk sets this itself; default 3000)
 *   DATA_DIR        where central.json is kept (default ./data, must be writable)
 *   ADMIN_PASSWORD  sets or resets the admin password at start
 *   RETENTION_DAYS  delete data not updated for this long (default 90)
 *   ACT_RETENTION_DAYS  keep the activity log this long (default 14)
 *   ACT_MAX_PER_SITE    activity rows kept per site, oldest dropped first (default 50000)
 *
 * Multi-tenant: every site belongs to one tenant (a client organisation). Platform staff (role superadmin, no tenant) manage tenants;
 * tenant users (admin / analyst / viewer) only ever see the sites of their own tenant (optionally limited to some of them).
 *
 * Activity log: every packet-level event a sensor sees (Modbus write, S7 stop, DNS query, new connection,
 * ARP, ICMP ...), merged per push window. Kept in data/activities.ndjson, shown on the Activity page.
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const sensorBuild = require('./sensorbuild');
const cp = require('child_process');
const dgram = require('dgram');
const net = require('net');
const tls = require('tls');
const https = require('https');
const os = require('os');
/* Base images (the 284 MB otsense-sensor.iso) live in a folder NEXT TO otsense-central and sensor-image, at the site root:  <root>/base-images/
   so you can zip otsense-central + sensor-image without ever opening them to skip the big file. The old place (otsense-central/images) is still
   read if the new folder has no ISO yet. Set IMAGE_DIR to force any other folder. New builds are always written to <root>/base-images/. */
const IMAGE_DIR_NEW = process.env.IMAGE_DIR || path.join(__dirname, '..', 'base-images');
const IMAGE_DIR_OLD = path.join(__dirname, 'images');
function hasIso(d) { try { return fs.readdirSync(d).some(function (n) { return /\.iso$/i.test(n); }); } catch (e) { return false; } }
function imageDir() { return process.env.IMAGE_DIR || (hasIso(IMAGE_DIR_NEW) ? IMAGE_DIR_NEW : hasIso(IMAGE_DIR_OLD) ? IMAGE_DIR_OLD : IMAGE_DIR_NEW); }

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'central.json');
const RETENTION_S = (parseInt(process.env.RETENTION_DAYS, 10) || 90) * 86400;
const MAX_BODY = 25 * 1024 * 1024;       // compressed
const MAX_JSON = 120 * 1024 * 1024;      // decompressed
const SEV = { info: 0, low: 1, medium: 2, high: 3, critical: 4 };
/* Open-port knowledge: what a port tells us about a device (used for devices found by an active scan). */
const PORT_OT = { 502: 'modbus', 102: 's7comm', 44818: 'enip', 20000: 'dnp3', 4840: 'opcua', 47808: 'bacnet', 2404: 'iec104' };
const PORT_NAME = { 21: 'FTP', 22: 'SSH', 23: 'Telnet', 53: 'DNS', 80: 'HTTP', 102: 'Siemens S7', 135: 'Windows RPC', 139: 'NetBIOS', 443: 'HTTPS', 445: 'SMB', 502: 'Modbus', 554: 'RTSP (camera)',
  631: 'IPP (printer)', 1883: 'MQTT', 2404: 'IEC 60870-5-104', 3389: 'RDP', 4840: 'OPC UA', 9100: 'Printer (raw)', 20000: 'DNP3', 44818: 'EtherNet/IP', 47808: 'BACnet' };
const PORT_RISK = { 23: ['high', 40, 'Telnet is open (clear-text remote login)'], 21: ['medium', 20, 'FTP is open (clear-text file transfer)'], 3389: ['medium', 25, 'Remote Desktop (RDP) is open'],
  445: ['medium', 15, 'SMB file sharing is open'], 135: ['low', 8, 'Windows RPC is open'], 139: ['low', 8, 'NetBIOS is open'], 1883: ['low', 8, 'MQTT without TLS is open'],
  502: ['medium', 20, 'OT port 502 (Modbus) is open - not confirmed as Modbus'], 102: ['medium', 15, 'OT port 102 (Siemens S7) is open - not confirmed'], 44818: ['medium', 15, 'OT port 44818 (EtherNet/IP) is open - not confirmed'], 20000: ['medium', 15, 'OT port 20000 (DNP3 port) is open - not confirmed as DNP3'], 2404: ['medium', 15, 'OT port 2404 (IEC 104) is open - not confirmed'] };
function typeFromPorts(ports) {
  const has = function (p) { return ports.indexOf(p) !== -1; };
  if (has(554)) return 'IP camera / video device (RTSP)';
  if (has(9100) || has(631)) return 'Printer';
  if (has(3389) || has(445) || has(135) || has(139)) return 'Windows computer / server';
  if (has(23)) return 'Network device (Telnet)';
  if (has(22)) return 'Linux / network device (SSH)';
  if (has(80) || has(443)) return 'Web device (router / camera / printer)';
  return '';
}

const ROLES = ['admin', 'analyst', 'viewer'];
const PAGE_SIZE = 40;
const ACT_PAGE = 100;
const ACT_FILE = path.join(DATA_DIR, 'activities.ndjson');
const ACT_RETENTION_S = (parseInt(process.env.ACT_RETENTION_DAYS, 10) || 14) * 86400;
const ACT_MAX = parseInt(process.env.ACT_MAX_PER_SITE, 10) || 50000;
const ACT_CATS = ['stop', 'program', 'control', 'write', 'upload', 'discover', 'session', 'read', 'response', 'info'];

/* ------------------------------------------------------------------ */
/* Storage: in memory, saved to one JSON file (atomic replace)         */
/* ------------------------------------------------------------------ */
let DB = { nextSite: 1, secret: '', tenants: {}, sites: {}, users: {}, audit: [], assets: {}, flows: {}, alerts: {}, snmp: {}, tokens: {}, smtp: {} };
let dirty = false;
/* ---- sensor images: built on this server (inside a Docker container, Docker is installed automatically), then reused for every site ---- */
const SENSOR_SRC = process.env.SENSOR_SRC || path.join(__dirname, 'sensor-src');               // folder with otsense.py (your otsense-docker folder)
const IMG_DIR_SRC = process.env.SENSOR_IMAGE_DIR || path.join(__dirname, '..', 'sensor-image');
const BUILD_SCRIPT = process.env.BUILD_SCRIPT || path.join(IMG_DIR_SRC, 'build-iso.sh');         // used by method "host"
const DOCKER_SCRIPT = path.join(IMG_DIR_SRC, 'docker-build.sh');
const IMG_TARGETS = {
  'iso-amd64': { label: 'x86-64 ISO (VMware, Hyper-V, VirtualBox, Proxmox, PC/laptop USB)', file: 'otsense-sensor.iso' },
  'rpi-arm64': { label: 'Raspberry Pi 4/5 image (ARM64, .img.xz)', file: 'otsense-sensor-rpi.img.xz' }
};
const ISO_FILE = function () { return path.join(imageDir(), IMG_TARGETS['iso-amd64'].file); };
const IMG = { running: false, started: 0, finished: 0, ok: null, log: [], pid: 0, target: '', method: '' };
function imgLog(t) { String(t).split(/\r?\n/).forEach(function (l) { if (l.trim()) { IMG.log.push(l.slice(0, 300)); if (IMG.log.length > 300) IMG.log.shift(); } }); }
function listBases() {
  let names = []; try { names = fs.readdirSync(imageDir()); } catch (e) {}
  return names.filter(function (n) { return /\.iso$/i.test(n); }).sort().map(function (n) {
    let st = null; try { st = fs.statSync(path.join(imageDir(), n)); } catch (e) {}
    return { name: n, size: st ? st.size : 0, built: st ? st.mtimeMs / 1000 : 0 };
  });
}
/* Find the FULL Windows app (built by the GitHub workflow) in any images folder, whatever the letter case; report what was looked at. */
function findWinFull() {
  const dirs = []; [imageDir(), IMAGE_DIR_NEW, IMAGE_DIR_OLD].forEach(function (d) { if (dirs.indexOf(d) < 0) dirs.push(d); });
  const seen = []; let best = null;
  dirs.forEach(function (d) {
    let names = []; try { names = fs.readdirSync(d); } catch (e) { seen.push(d + ' (folder not readable)'); return; }
    const ex = names.filter(function (n) { return /\.exe$/i.test(n); });
    seen.push(d + ' -> ' + (ex.length ? ex.map(function (n) { let sz = 0; try { sz = fs.statSync(path.join(d, n)).size; } catch (e) {} return n + ' ' + (sz / 1048576).toFixed(1) + ' MB'; }).join(', ') : 'no .exe files'));
    ex.forEach(function (n) {
      let sz = 0; try { sz = fs.statSync(path.join(d, n)).size; } catch (e) {}
      if (/^otsense-sensor.*\.exe$/i.test(n) && sz > 5 * 1048576 && (!best || sz > best.size)) best = { path: path.join(d, n), size: sz };
    });
  });
  return { path: best ? best.path : path.join(imageDir(), 'OTSense-Sensor.exe'), diag: seen.join(' | ') };
}
function findVmExe() {          // the Windows VM launcher (built by the GitHub workflow), any letter case, in any images folder
  const dirs = []; [imageDir(), IMAGE_DIR_NEW, IMAGE_DIR_OLD].forEach(function (d) { if (dirs.indexOf(d) < 0) dirs.push(d); });
  let best = null; const seen = [];
  dirs.forEach(function (d) {
    let names = []; try { names = fs.readdirSync(d); } catch (e) { seen.push(d + ' (folder not readable)'); return; }
    const ex = names.filter(function (n) { return /^otsense-vm.*\.exe$/i.test(n); });
    seen.push(d + ' -> ' + (ex.length ? ex.join(', ') : 'no OTSense-VM*.exe'));
    ex.forEach(function (n) { let sz = 0; try { sz = fs.statSync(path.join(d, n)).size; } catch (e) {} if (sz > 1048576 && (!best || sz > best.size)) best = { path: path.join(d, n), size: sz }; });
  });
  return { path: best ? best.path : '', diag: seen.join(' | ') };
}
function imgStatus() {
  const why = process.platform !== 'linux' ? 'Images can only be built on a Linux server (run central there, as root, with internet).'
    : (typeof process.getuid === 'function' && process.getuid() !== 0) ? 'Run central as root (sudo node central.js) so it can install and use Docker.'
    : !fs.existsSync(DOCKER_SCRIPT) ? 'Build script not found: ' + DOCKER_SCRIPT
    : !fs.existsSync(path.join(SENSOR_SRC, 'otsense.py')) ? 'Sensor source not found: put your otsense-docker folder at ' + SENSOR_SRC : '';
  const targets = Object.keys(IMG_TARGETS).map(function (id) {
    let st = null; try { st = fs.statSync(path.join(imageDir(), IMG_TARGETS[id].file)); } catch (e) {}
    return { id: id, label: IMG_TARGETS[id].label, file: IMG_TARGETS[id].file, exists: !!st, size: st ? st.size : 0, built: st ? st.mtimeMs / 1000 : 0 };
  });
  const iso = targets[0];
  let docker = false; try { cp.execFileSync('docker', ['--version'], { stdio: 'ignore' }); docker = true; } catch (e) {}
  return { exists: iso.exists, size: iso.size, built: iso.built, targets: targets, docker: docker, running: IMG.running, started: IMG.started, finished: IMG.finished,
    ok: IMG.ok, job_target: IMG.target, job_method: IMG.method, can_build: !why, why: why, log: IMG.log.slice(-25) };
}
function imgStart(who, target, method) {
  const t = IMG_TARGETS[target]; if (!t) throw new Error('unknown image type');
  method = method === 'host' ? 'host' : 'docker';
  if (method === 'host' && target !== 'iso-amd64') throw new Error('the host method only builds the x86-64 ISO; use Docker');
  const args = method === 'docker' ? [DOCKER_SCRIPT, target, SENSOR_SRC] : [BUILD_SCRIPT, SENSOR_SRC];
  const c = cp.spawn('bash', args, { env: Object.assign({}, process.env, { OUT_DIR: IMAGE_DIR_NEW }), stdio: ['ignore', 'pipe', 'pipe'] });
  IMG.running = true; IMG.started = Date.now() / 1000; IMG.finished = 0; IMG.ok = null; IMG.log = []; IMG.pid = c.pid; IMG.target = target; IMG.method = method;
  imgLog('Building: ' + t.label + ' (method: ' + method + ')');
  c.stdout.on('data', imgLog); c.stderr.on('data', imgLog);
  c.on('error', function (e) { imgLog('cannot start: ' + e.message); });
  c.on('close', function (code) { IMG.running = false; IMG.finished = Date.now() / 1000; IMG.ok = code === 0 && fs.existsSync(path.join(IMAGE_DIR_NEW, t.file)); imgLog(IMG.ok ? 'DONE - ' + t.file + ' is ready.' : 'FAILED (exit ' + code + ') - see lines above.'); audit(who, IMG.ok ? 'image.built' : 'image.failed', target + ' exit ' + code); });
}
function imgFetch(who, target, url0) {
  const t = IMG_TARGETS[target]; if (!t) throw new Error('unknown image type');
  let u0; try { u0 = new URL(url0); } catch (e) { throw new Error('not a valid link'); }
  if (u0.protocol !== 'https:') throw new Error('the link must start with https://');
  if (/^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[)/i.test(u0.hostname)) throw new Error('local addresses are not allowed');
  fs.mkdirSync(IMAGE_DIR_NEW, { recursive: true });
  const dest = path.join(IMAGE_DIR_NEW, t.file), part = dest + '.part', CAP = 3 * 1024 * 1024 * 1024;
  IMG.running = true; IMG.started = Date.now() / 1000; IMG.finished = 0; IMG.ok = null; IMG.log = []; IMG.pid = 0; IMG.target = target; IMG.method = 'link';
  imgLog('Downloading ' + u0.hostname + u0.pathname.slice(0, 80));
  const done = function (ok, msg) { IMG.running = false; IMG.finished = Date.now() / 1000; IMG.ok = ok; imgLog(msg); audit(who, ok ? 'image.imported' : 'image.import.failed', target); if (!ok) try { fs.unlinkSync(part); } catch (e) {} };
  const get = function (url, hops) {
    if (hops > 6) return done(false, 'FAILED: too many redirects');
    const mod = require('https');
    mod.get(url, { headers: { 'User-Agent': 'otsense-central' } }, function (r) {
      if ([301, 302, 303, 307, 308].indexOf(r.statusCode) >= 0 && r.headers.location) { r.resume(); let nu; try { nu = new URL(r.headers.location, url); } catch (e) { return done(false, 'FAILED: bad redirect'); } if (nu.protocol !== 'https:') return done(false, 'FAILED: redirect to non-https'); return get(nu.href, hops + 1); }
      if (r.statusCode !== 200) { r.resume(); return done(false, 'FAILED: server answered HTTP ' + r.statusCode + ' (private repo or wrong link?)'); }
      const total = parseInt(r.headers['content-length'], 10) || 0; let got = 0, last = 0;
      const ws = fs.createWriteStream(part);
      r.on('data', function (c) { got += c.length; if (got > CAP) { r.destroy(new Error('file too large')); } if (Date.now() - last > 5000) { last = Date.now(); imgLog('downloaded ' + (got / 1048576).toFixed(0) + (total ? ' of ' + (total / 1048576).toFixed(0) : '') + ' MB'); } });
      r.on('error', function (e) { ws.destroy(); done(false, 'FAILED: ' + e.message); });
      r.pipe(ws);
      ws.on('finish', function () {
        if (target === 'iso-amd64') {   // the ISO must hold exactly one empty config slot, or stamping would corrupt it
          const M = Buffer.from('OTSENSE_SLOT_V1\n'); let n = 0, tail = Buffer.alloc(0);
          const rs = fs.createReadStream(part, { highWaterMark: 8 << 20 });
          rs.on('data', function (c) { const b = Buffer.concat([tail, c]); let i = 0; while ((i = b.indexOf(M, i)) >= 0) { n++; i += M.length; } tail = b.slice(Math.max(0, b.length - 15)); });
          rs.on('end', function () { if (n !== 1) return done(false, 'FAILED: this file is not an OT Sense sensor ISO (found ' + n + ' config slots, expected 1)'); fs.renameSync(part, dest); done(true, 'DONE - ' + t.file + ' imported (' + (got / 1048576).toFixed(0) + ' MB).'); });
          rs.on('error', function (e) { done(false, 'FAILED: ' + e.message); });
        } else { fs.renameSync(part, dest); done(true, 'DONE - ' + t.file + ' imported (' + (got / 1048576).toFixed(0) + ' MB).'); }
      });
    }).on('error', function (e) { done(false, 'FAILED: ' + e.message); });
  };
  get(u0.href, 0);
}
const BUILDS = new Map();      // one-time download bundles built by /api/sensors/build (kept 15 min, in memory only: they contain the token)
setInterval(function () { BUILDS.forEach(function (v, k) { if (v.exp < Date.now()) BUILDS.delete(k); }); }, 60000).unref();

/* ===================================================================== */
/* Permanent device identity                                              */
/* A device has one id (DEV-000123) for life. The IP address, the MAC and  */
/* the sensor's own key (ip:10.0.0.5) are only ways to RECOGNISE it: a    */
/* device can have several of each, and they can change. Every sensor     */
/* observation is matched to a device, and only that device is updated.   */
/* ===================================================================== */
let DEVV = 1;                  // bump after any bulk change so the lookup tables below are rebuilt
const IDXC = new WeakMap();    // assets object of a site -> { v, ip, mac, key } lookup tables
function normMac(m) {          // aa:bb:cc:dd:ee:ff, or '' when it is not the address of one device
  const h = String(m == null ? '' : m).toLowerCase().replace(/[^0-9a-f]/g, '');
  if (h.length !== 12 || /^0+$/.test(h) || /^f+$/.test(h)) return '';
  if (parseInt(h.slice(0, 2), 16) & 1) return '';          // group address (multicast / broadcast)
  return h.replace(/(..)(?=.)/g, '$1:');
}
function newDevId() { DB.devSeq = (DB.devSeq || 0) + 1; dirty = true; return 'DEV-' + String(DB.devSeq).padStart(6, '0'); }
function uniq(a, cap) { const o = []; (a || []).forEach(function (x) { if (x !== '' && x != null && o.indexOf(x) === -1) o.push(x); }); return cap ? o.slice(0, cap) : o; }
function devIdx(A) {
  let c = IDXC.get(A); if (c && c.v === DEVV) return c;
  c = { v: DEVV, ip: {}, mac: {}, key: {} };
  for (const id in A) { const a = A[id]; (a.keys || []).forEach(function (k) { c.key[k] = a; }); (a.macs || []).forEach(function (m) { c.mac[m] = a; }); (a.ips || []).forEach(function (ip) { if (!c.ip[ip]) c.ip[ip] = a; }); }
  for (const id in A) if (A[id].ip) c.ip[A[id].ip] = A[id];            // the address a device uses now beats one it used before
  IDXC.set(A, c); return c;
}
function devIdxPut(A, a) {
  const c = IDXC.get(A); if (!c || c.v !== DEVV) return;
  (a.keys || []).forEach(function (k) { c.key[k] = a; }); (a.macs || []).forEach(function (m) { c.mac[m] = a; });
  (a.ips || []).forEach(function (ip) { if (!c.ip[ip]) c.ip[ip] = a; }); if (a.ip) c.ip[a.ip] = a;
}
function assetByIp(A, ip) { return A && ip ? (devIdx(A).ip[ip] || null) : null; }
function devGet(sid, id) {      // a device by its id; an id that was merged into another still finds the survivor
  const A = DB.assets[String(sid)] || {}; if (A[id]) return A[id];
  const al = (DB.devalias || {})[String(sid)] || {}; let n = id, g = 0; while (al[n] && g++ < 10) n = al[n];
  if (A[n]) return A[n];
  const ix = devIdx(A); if (ix.key[id]) return ix.key[id];                 // a sensor key such as ip:10.0.0.5
  return id.indexOf('ip:') === 0 ? (ix.ip[id.slice(3)] || null) : null;
}
/* Which device does this observation belong to? Order: a MAC we know, then the sensor's own key, then (no MAC at all) the IP address. null = a new device. */
function devFor(A, key, rec, nowSec) {
  const ix = devIdx(A), macs = [], push = function (m) { m = normMac(m); if (m && macs.indexOf(m) < 0) macs.push(m); };
  push(rec.mac); (Array.isArray(rec.macs) ? rec.macs : []).slice(0, 12).forEach(push);
  let d = null;
  for (let i = 0; i < macs.length && !d; i++) d = ix.mac[macs[i]] || null;
  if (d && (d.block_keys || []).indexOf(key) !== -1) d = null;            // the user split this address away from that device
  if (!d && ix.key[key]) {
    const k = ix.key[key];
    if (!macs.length || !(k.macs || []).length) d = k;                       // nothing contradicts it
    else if (nowSec - (k.updated || 0) < 1800) d = k;                        // the same address answered with another MAC a moment ago: one device with several MACs
  }
  if (!d && !macs.length && rec.ip && ix.ip[rec.ip]) d = ix.ip[rec.ip];     // seen without a MAC (routed, or found by a scan)
  return { dev: d, macs: macs };
}
function maxStr(a, b) { a = a || ''; b = b || ''; return a >= b ? a : b; }
function devIpOrder(seen, prefer) {
  return Object.keys(seen).sort(function (x, y) { return String(seen[y]).localeCompare(String(seen[x])) || (x === prefer ? -1 : y === prefer ? 1 : 0); });
}
function devIdentity(nr, old, key, ip, macs, seenStr) {   // identity fields of a device record after one more observation
  const o = old || {};
  nr.keys = uniq((o.keys || []).concat([key]), 40);
  nr.macs = uniq((o.macs || []).concat(macs), 64);
  nr.mac = macs[0] || nr.macs[0] || '';
  const seen = Object.assign({}, o.ipseen || {}); if (ip) seen[ip] = seenStr || '';
  const order = devIpOrder(seen, ip); order.slice(12).forEach(function (k) { delete seen[k]; });
  nr.ipseen = seen; nr.ips = order.slice(0, 12); nr.ip = nr.ips[0] || ip || '';
  ['merge_log', 'block_keys', 'label'].forEach(function (f) { if (o[f] !== undefined) nr[f] = o[f]; });
  nr.last_seen = maxStr(o.last_seen, nr.last_seen);
  nr.search = (String(nr.search || '') + ' ' + nr.macs.join(' ') + ' ' + nr.ips.join(' ') + ' ' + String(nr.id).toLowerCase()).slice(0, 6500);
}
function devMerge(sid, tid, oids, who, why) {
  const A = DB.assets[sid], t = A && A[tid]; if (!t) return null;
  const al = (DB.devalias = DB.devalias || {}); al[sid] = al[sid] || {};
  const stamp = new Date().toISOString().slice(0, 19).replace('T', ' ');
  oids.forEach(function (oid) {
    const o = A[oid]; if (!o || oid === tid) return;
    t.keys = uniq((t.keys || []).concat(o.keys || []), 40); t.macs = uniq((t.macs || []).concat(o.macs || []), 64);
    const seen = Object.assign({}, o.ipseen || {}); Object.keys(t.ipseen || {}).forEach(function (k) { seen[k] = maxStr(seen[k], t.ipseen[k]); });
    const order = devIpOrder(seen, ''); order.slice(12).forEach(function (k) { delete seen[k]; }); t.ipseen = seen; t.ips = order.slice(0, 12); t.ip = t.ips[0] || t.ip || o.ip || '';
    t.mac = t.mac || o.mac || (t.macs[0] || '');
    ['vendor', 'device_type', 'model', 'firmware', 'os', 'zone'].forEach(function (f) { if (!t[f] && o[f]) t[f] = o[f]; });
    t.hostnames = uniq((t.hostnames || []).concat(o.hostnames || []), 10); t.protocols = uniq((t.protocols || []).concat(o.protocols || []));
    t.ot = (t.ot || o.ot) ? 1 : 0; t.risk = Math.max(t.risk || 0, o.risk || 0);
    t.first_seen = (t.first_seen && o.first_seen) ? (t.first_seen < o.first_seen ? t.first_seen : o.first_seen) : (t.first_seen || o.first_seen || '');
    t.last_seen = maxStr(t.last_seen, o.last_seen); t.gone = !!(t.gone && o.gone); if (!(t.scan_only && o.scan_only)) delete t.scan_only;
    t.seen_by = Object.assign({}, o.seen_by || {}, t.seen_by || {});
    t.search = (String(t.search || '') + ' ' + String(o.search || '')).slice(0, 6500);
    const pre = sid + '|' + oid + '|', npre = sid + '|' + tid + '|';
    ['vstate', 'vfirst'].forEach(function (n) {
      const M = DB[n] || {}; Object.keys(M).forEach(function (k) {
        if (k.indexOf(pre) !== 0) return; const nk = npre + k.slice(pre.length);
        if (M[nk] === undefined) M[nk] = M[k]; else if (n === 'vfirst') M[nk] = Math.min(M[nk], M[k]);
        delete M[k];
      });
    });
    Object.keys(al[sid]).forEach(function (k) { if (al[sid][k] === oid) al[sid][k] = tid; }); al[sid][oid] = tid;
    t.merge_log = (t.merge_log || []).concat([{ at: stamp, by: who, from: oid, why: why || '' }]).slice(-20);
    delete A[oid];
  });
  DEVV++; dirty = true; return t;
}
function devSplit(sid, id, macs, ips, who) {
  const A = DB.assets[sid], d = A && A[id]; if (!d) return { error: 'device not found' };
  const sm = uniq((macs || []).map(normMac).filter(function (m) { return m && (d.macs || []).indexOf(m) !== -1; })), si = uniq((ips || []).filter(function (ip) { return (d.ips || []).indexOf(ip) !== -1; }));
  if (!sm.length && !si.length) return { error: 'choose at least one MAC or IP address that belongs to this device' };
  const remM = (d.macs || []).filter(function (m) { return sm.indexOf(m) === -1; }), remI = (d.ips || []).filter(function (ip) { return si.indexOf(ip) === -1; });
  if (!remM.length && !remI.length) return { error: 'something has to stay with the original device' };
  const moveKeys = (d.keys || []).filter(function (k) { return (k.indexOf('ip:') === 0 && si.indexOf(k.slice(3)) !== -1) || (k.indexOf('mac:') === 0 && sm.indexOf(normMac(k.slice(4))) !== -1); });
  const stamp = new Date().toISOString().slice(0, 19).replace('T', ' '), nid = newDevId(), n = JSON.parse(JSON.stringify(d));
  const pick = function (o, list) { const r = {}; list.forEach(function (k) { if (o && o[k] !== undefined) r[k] = o[k]; }); return r; };
  n.id = nid; n.keys = moveKeys; n.macs = sm; n.ipseen = pick(d.ipseen, si); n.ips = devIpOrder(n.ipseen, ''); n.ip = n.ips[0] || ''; n.mac = sm[0] || '';
  n.label = ''; n.merge_log = [{ at: stamp, by: who, from: id, why: 'split from ' + id }]; n.block_keys = moveKeys.length ? (d.keys || []).filter(function (k) { return moveKeys.indexOf(k) === -1; }) : [];
  n.data = Object.assign({}, d.data || {}, { id: nid, ip: n.ip, mac: n.mac || null }); n.search = (String(d.search || '') + ' ' + sm.join(' ') + ' ' + si.join(' ') + ' ' + nid.toLowerCase()).slice(0, 6500);
  d.keys = (d.keys || []).filter(function (k) { return moveKeys.indexOf(k) === -1; }); d.macs = remM; d.ipseen = pick(d.ipseen, remI); d.ips = devIpOrder(d.ipseen, ''); d.ip = d.ips[0] || '';
  if (sm.indexOf(d.mac) !== -1) d.mac = remM[0] || ''; d.block_keys = uniq((d.block_keys || []).concat(moveKeys));
  d.merge_log = (d.merge_log || []).concat([{ at: stamp, by: who, from: nid, why: 'split off ' + nid }]).slice(-20);
  A[nid] = n; (DB.devno = DB.devno || {}); (DB.devno[sid] = DB.devno[sid] || []).push([id, nid]);
  DEVV++; dirty = true; return { id: nid };
}
/* Merge on strong proof only: an SNMP switch that owns an IP and a set of MACs, or the same serial number. Everything else stays separate (merge by hand). */
function devAutoMerge(sid) {
  const A = DB.assets[sid]; if (!A) return;
  const ix = devIdx(A), no = (DB.devno || {})[sid] || [], parent = {}, why = {};
  const blocked = function (a, b) { return no.some(function (p) { return (p[0] === a && p[1] === b) || (p[0] === b && p[1] === a); }); };
  const find = function (x) { if (parent[x] === undefined || parent[x] === x) return (parent[x] = x); return (parent[x] = find(parent[x])); };
  const join = function (a, b, w) { if (!a || !b || a.id === b.id || blocked(a.id, b.id)) return; const ra = find(a.id), rb = find(b.id); if (ra !== rb) { parent[rb] = ra; why[ra] = why[ra] || w; } };
  const bySer = {};
  for (const id in A) {
    const a = A[id], ser = String((a.data && a.data.serial) || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (ser.length < 6 || /^(.)\1*$/.test(ser) || /^(NONE|UNKNOWN|DEFAULT|NOTAVAILABLE|NULL|NA)/.test(ser)) continue;
    (bySer[ser] = bySer[ser] || []).push(a);
  }
  Object.keys(bySer).forEach(function (k) { const l = bySer[k]; for (let i = 1; i < l.length; i++) { const v1 = String(l[0].vendor || '').toLowerCase(), v2 = String(l[i].vendor || '').toLowerCase(); if (!v1 || !v2 || v1 === v2) join(l[0], l[i], 'same serial number ' + k); } });
  const cur = (DB.snmp || {})[sid]; let enriched = false;
  if (cur) Object.values(cur.results || {}).forEach(function (r) {
    if (!r || !r.good_at) return;
    const macs = [], add = function (m) { m = normMac(m); if (m && macs.indexOf(m) < 0) macs.push(m); };
    add(r.sys && r.sys.bridge_mac); Object.values(r.if || {}).forEach(function (f) { add(f.m); });
    let first = ix.ip[r.host] || null;
    macs.forEach(function (m) { const d = ix.mac[m]; if (!d) return; if (!first) first = d; else join(first, d, 'SNMP: ' + r.host + ' owns MAC ' + m); });
    if (first) macs.forEach(function (m) { if (!ix.mac[m]) { first.macs = uniq((first.macs || []).concat([m]), 64); ix.mac[m] = first; enriched = true; } });
  });
  const groups = {}; Object.keys(parent).forEach(function (id) { (groups[find(id)] = groups[find(id)] || []).push(id); });
  let merged = 0;
  Object.keys(groups).forEach(function (r) {
    const ids = groups[r]; if (ids.length < 2) return;
    ids.sort(function (x, y) { const a = A[x].first_seen || '~', b = A[y].first_seen || '~'; return a < b ? -1 : a > b ? 1 : (x < y ? -1 : 1); });
    devMerge(sid, ids[0], ids.slice(1), 'auto', why[r] || 'strong evidence'); merged += ids.length - 1;
  });
  if (enriched) { DEVV++; dirty = true; }
  return merged;
}
function migrateDevices() {       // one-off: devices that are still keyed by IP (ip:10.0.0.5) get a permanent id; their history follows
  let any = false;
  for (const sid in DB.assets) {
    const A = DB.assets[sid], ids = Object.keys(A);
    if (!ids.some(function (k) { return !/^DEV-\d+$/.test(k) || A[k].id !== k; })) continue;
    any = true;
    const NA = {}, map = {}, al = ((DB.devalias = DB.devalias || {})[sid] = DB.devalias[sid] || {}), macCount = {};
    ids.forEach(function (k) { const m = normMac(A[k].mac || (A[k].data && A[k].data.mac)); if (m) macCount[m] = (macCount[m] || 0) + 1; });
    ids.forEach(function (k) {
      const a = A[k]; if (/^DEV-\d+$/.test(k) && a.id === k) { NA[k] = a; return; }
      const uid = newDevId(), m = normMac(a.mac || (a.data && a.data.mac)), ms = m && macCount[m] < 4 ? [m] : [];   // a MAC on 4+ addresses is a router, not an identity
      map[k] = uid; al[k] = uid; a.keys = [k]; a.macs = ms; a.mac = m || a.mac || '';
      const ip = a.ip || (k.indexOf('ip:') === 0 ? k.slice(3) : ''); a.ipseen = ip ? { [ip]: a.last_seen || '' } : {}; a.ips = ip ? [ip] : []; a.ip = ip;
      a.id = uid; if (a.data) a.data.id = uid; a.search = (String(a.search || '') + ' ' + ms.join(' ') + ' ' + ip + ' ' + uid.toLowerCase()).slice(0, 6500); NA[uid] = a;
    });
    DB.assets[sid] = NA;
    ['vstate', 'vfirst'].forEach(function (n) {
      const M = DB[n] || {}; Object.keys(M).forEach(function (key) {
        const parts = key.split('|'); if (parts[0] !== sid || !map[parts[1]]) return;
        parts[1] = map[parts[1]]; const nk = parts.join('|'); if (M[nk] === undefined) M[nk] = M[key]; delete M[key];
      });
    });
    const L = DB.alerts[sid] || {};
    Object.keys(L).forEach(function (u) { const m = u.match(/^pol:([^:]+):(.+)$/); if (m && map[m[2]]) { const nu = 'pol:' + m[1] + ':' + map[m[2]]; L[nu] = Object.assign(L[u], { uid: nu }); delete L[u]; } });
    DEVV++;
  }
  if (any) { dirty = true; console.log('Devices now have permanent ids (DEV-nnnnnn).'); }
  for (const sid in DB.assets) { try { devAutoMerge(sid); } catch (e) { console.error('device merge check failed: ' + e.message); } }
}
let ACT = {};                 // siteId -> [activity rows], oldest first (kept in data/activities.ndjson, not in central.json)
let actBuf = [];              // {tid, line} waiting to be appended to the organisation's activity file
let actLines = 0;             // lines currently on disk (to decide when to compact)
let sawPlain = false;         // an unencrypted line was read while encryption is on: rewrite everything encrypted

/* Optional encryption at rest: set DATA_KEY (any long secret) and every data file is written as AES-256-GCM.
   Lose the key and the data cannot be read, so keep it somewhere safe. Plain files are read as before and converted at the next save. */
const DATA_KEY = process.env.DATA_KEY ? crypto.createHash('sha256').update('otsense-data|' + process.env.DATA_KEY).digest() : null;
function encStr(str) {
  if (!DATA_KEY) return str;
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', DATA_KEY, iv);
  const ct = Buffer.concat([c.update(str, 'utf8'), c.final()]);
  return 'OTENC1:' + Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}
function decStr(str) {
  if (str.slice(0, 7) !== 'OTENC1:') { if (DATA_KEY) sawPlain = true; return str; }
  if (!DATA_KEY) throw new Error('the data files are encrypted but DATA_KEY is not set');
  const raw = Buffer.from(str.slice(7).trim(), 'base64'), d = crypto.createDecipheriv('aes-256-gcm', DATA_KEY, raw.subarray(0, 12));
  d.setAuthTag(raw.subarray(12, 28));
  try { return Buffer.concat([d.update(raw.subarray(28)), d.final()]).toString('utf8'); } catch (e) { throw new Error('DATA_KEY is wrong for these data files'); }
}
function writeAtomic(file, str) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, str);
  try { fs.renameSync(tmp, file); } catch (e) { fs.copyFileSync(tmp, file); fs.unlinkSync(tmp); }
}
/* every organisation has its own folder: data/tenants/<id>/data.json (devices, flows, alerts) and activities.ndjson */
const TEN_DIR = path.join(DATA_DIR, 'tenants');
function tenantDir(tid) { if (!/^[a-z0-9-]{1,40}$/.test(String(tid))) throw new Error('bad organisation id'); return path.join(TEN_DIR, tid); }
function tenantOfSite(sid) { return (DB.sites[sid] || {}).tenant || null; }

function parseUtc(x) {        // sensor times are "YYYY-MM-DD HH:MM:SS" in UTC
  const t = Date.parse(String(x || '').replace(' ', 'T') + 'Z');
  return isNaN(t) ? 0 : t / 1000;
}
function actPush(r) { const tid = tenantOfSite(String(r.sid)); if (tid) actBuf.push({ tid: tid, line: JSON.stringify(r) }); }
function loadActivities() {
  const cut = Date.now() / 1000 - ACT_RETENTION_S, files = [ACT_FILE];
  try { fs.readdirSync(TEN_DIR).forEach(function (d) { files.push(path.join(TEN_DIR, d, 'activities.ndjson')); }); } catch (e) {}
  actLines = 0;
  files.forEach(function (f) {
    let txt = ''; try { txt = fs.readFileSync(f, 'utf8'); } catch (e) { return; }
    txt.split('\n').forEach(function (ln) {
      if (!ln) return;
      actLines++;
      try {
        const r = JSON.parse(decStr(ln)), sid = String(r.sid);
        if (!DB.sites[sid] || (r.rx || r.t) < cut) return;
        (ACT[sid] || (ACT[sid] = [])).push(r);
      } catch (e) { if (/DATA_KEY/.test(e.message)) { console.error(e.message); process.exit(1); } }
    });
  });
  for (const sid in ACT) { ACT[sid].sort(function (x, y) { return (x.rx || x.t) - (y.rx || y.t); }); if (ACT[sid].length > ACT_MAX) ACT[sid] = ACT[sid].slice(-ACT_MAX); }
  let kept = 0; for (const sid in ACT) kept += ACT[sid].length;
  if (sawPlain || fs.existsSync(ACT_FILE) || actLines > 1.5 * kept + 1000) compactActivities();
}
function flushActivities() {
  if (!actBuf.length) return;
  const by = {}; actBuf.forEach(function (x) { (by[x.tid] || (by[x.tid] = [])).push(encStr(x.line)); });
  actBuf = [];
  for (const tid in by) {
    try { fs.mkdirSync(tenantDir(tid), { recursive: true }); fs.appendFileSync(path.join(tenantDir(tid), 'activities.ndjson'), by[tid].join('\n') + '\n'); actLines += by[tid].length; }
    catch (e) { console.error('Activity save failed: ' + e.message); }
  }
}
function compactActivities() {
  flushActivities();
  const by = {}; let n = 0;
  for (const sid in ACT) { const tid = tenantOfSite(sid); if (!tid) continue; ACT[sid].forEach(function (r) { (by[tid] || (by[tid] = [])).push(encStr(JSON.stringify(r))); n++; }); }
  try {
    for (const tid in DB.tenants) { const f = path.join(tenantDir(tid), 'activities.ndjson'); if (by[tid]) writeAtomic(f, by[tid].join('\n') + '\n'); else { try { fs.unlinkSync(f); } catch (e) {} } }
    if (fs.existsSync(ACT_FILE)) fs.renameSync(ACT_FILE, ACT_FILE + '.migrated');
    actLines = n; sawPlain = false;
  } catch (e) { console.error('Activity compaction failed: ' + e.message); }
}

function loadDb() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  try { DB = Object.assign(DB, JSON.parse(decStr(fs.readFileSync(DB_FILE, 'utf8')))); }
  catch (e) { if (e.code !== 'ENOENT') { console.error('Could not read ' + DB_FILE + ': ' + e.message); process.exit(1); } }
  try {
    fs.readdirSync(TEN_DIR).forEach(function (d) {
      let txt; try { txt = fs.readFileSync(path.join(TEN_DIR, d, 'data.json'), 'utf8'); } catch (e) { return; }
      const part = JSON.parse(decStr(txt));
      ['assets', 'flows', 'alerts', 'snmp'].forEach(function (k) { if (!DB[k]) DB[k] = {}; Object.assign(DB[k], part[k] || {}); });
    });
  } catch (e) { if (e.code !== 'ENOENT') { console.error('Could not read an organisation folder: ' + e.message); process.exit(1); } }
  if (!DB.secret) { DB.secret = crypto.randomBytes(32).toString('hex'); dirty = true; }
  ['vstate', 'vfirst', 'vtrend', 'vrules', 'ccmd', 'pcaps', 'zones', 'fwrules', 'risk'].forEach(function (k) { if (!DB[k] || typeof DB[k] !== 'object' || Array.isArray(DB[k])) DB[k] = {}; });
  migrate();
  migrateDevices();
  ensurePolicies();
  if (DB.layout !== 2 || (DATA_KEY && sawPlain)) { dirty = true; sawPlain = true; }       // old single-file install, or encryption just switched on
}
const lastWritten = {};
function saveDb() {
  if (!dirty) return;
  dirty = false;
  try {
    const core = Object.assign({}, DB, { layout: 2 }); delete core.assets; delete core.flows; delete core.alerts; delete core.snmp;
    const cs = JSON.stringify(core);
    if (cs !== lastWritten.__core) { writeAtomic(DB_FILE, encStr(cs)); lastWritten.__core = cs; }
    const parts = {};
    for (const tid in DB.tenants) parts[tid] = { assets: {}, flows: {}, alerts: {}, snmp: {} };
    ['assets', 'flows', 'alerts', 'snmp'].forEach(function (k) { for (const sid in (DB[k] || {})) { const t = tenantOfSite(sid); if (t && parts[t]) parts[t][k][sid] = DB[k][sid]; } });
    for (const tid in parts) { const ps = JSON.stringify(parts[tid]); if (ps !== lastWritten[tid]) { writeAtomic(path.join(tenantDir(tid), 'data.json'), encStr(ps)); lastWritten[tid] = ps; } }
    if (DB.layout === undefined || DB.layout !== 2) DB.layout = 2;
    if (sawPlain && DATA_KEY) compactActivities();
  } catch (e) { dirty = true; console.error('Save failed: ' + e.message); }
}

/* ------------------------------------------------------------------ */
/* Helpers: crypto, text                                               */
/* ------------------------------------------------------------------ */
const sha = function (x) { return crypto.createHash('sha256').update(String(x)).digest('hex'); };
function hashPw(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return 's1$' + salt + '$' + crypto.scryptSync(pw, salt, 32).toString('hex');
}
function checkPw(pw, stored) {
  const p = String(stored || '').split('$');
  if (p.length !== 3 || p[0] !== 's1') return false;
  const a = Buffer.from(crypto.scryptSync(String(pw), p[1], 32).toString('hex'));
  const b = Buffer.from(p[2]);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function S(x, n) { return x == null ? '' : String(x).slice(0, n || 500); }
function audit(who, action, detail, tid) {
  const u = hasOwn(DB.users, who) ? DB.users[who] : null;
  const t = tid !== undefined ? tid : (u ? (u.tenant || null) : null);
  DB.audit.unshift({ ts: Date.now() / 1000, who: S(who, 60), action: action, detail: S(detail, 300), tenant: t });
  if (DB.audit.length > 5000) DB.audit.length = 5000;
  dirty = true;
}
const hasOwn = function (o, k) { return Object.prototype.hasOwnProperty.call(o, k); };

/* ------------------------------------------------------------------ */
/* Tenants, users, passwords                                           */
/* ------------------------------------------------------------------ */
const COMMON_PW = ['password', 'passw0rd', 'qwerty', 'letmein', 'welcome', 'administrator', 'changeme', 'otsense', 'iloveyou', '123456'];
function pwProblem(pw, name) {
  pw = String(pw == null ? '' : pw);
  if (pw.length < 12) return 'password must be at least 12 characters';
  if (pw.length > 200) return 'password is too long';
  const low = pw.toLowerCase();
  if (name && low.indexOf(String(name).toLowerCase()) !== -1) return 'password must not contain the user name';
  if (/^(.)\1+$/.test(pw) || COMMON_PW.some(function (c) { return low.indexOf(c) !== -1; })) return 'password is too easy to guess';
  if (!/[A-Za-z]/.test(pw) || !/[^A-Za-z]/.test(pw)) return 'use letters plus at least one digit or symbol';
  return '';
}
function tempPassword() { return crypto.randomBytes(12).toString('base64url') + crypto.randomInt(10); }
function userKey(name) {                         // user names are matched without regard to letter case
  name = String(name == null ? '' : name);
  if (hasOwn(DB.users, name)) return name;
  const n = name.toLowerCase();
  for (const k in DB.users) if (k.toLowerCase() === n) return k;
  return '';
}
function slugify(x) { return String(x == null ? '' : x).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40); }
function cleanLimits(l, old) {
  const o = Object.assign({ maxSites: 0, maxAssets: 0, retentionDays: 0 }, old || {});
  if (l && typeof l === 'object') ['maxSites', 'maxAssets', 'retentionDays'].forEach(function (k) {
    if (l[k] !== undefined && l[k] !== '') { const v = parseInt(l[k], 10); o[k] = isNaN(v) || v < 0 ? 0 : Math.min(v, 1e9); }
  });
  return o;
}
/* One-time upgrade of a single-company install: everything existing moves into the tenant "default". */
function migrate() {
  if (!DB.tenants || typeof DB.tenants !== 'object') DB.tenants = {};
  if (!DB.tenants.default) { DB.tenants.default = { id: 'default', name: 'Default', slug: 'default', status: 'active', created: Date.now() / 1000, limits: cleanLimits() }; dirty = true; }
  for (const id in DB.sites) if (!DB.sites[id].tenant) { DB.sites[id].tenant = 'default'; dirty = true; }
  for (const n in DB.users) {
    const u = DB.users[n];
    if (u.tenant === undefined) {
      if (n === 'admin') { u.role = 'superadmin'; u.tenant = null; } else u.tenant = 'default';
      dirty = true;
    }
    if (!Array.isArray(u.sites)) u.sites = [];
  }
  (DB.audit || []).forEach(function (a) { if (a.tenant === undefined) { a.tenant = 'default'; dirty = true; } });
}
/* The sites a user may see: every site of their tenant (all tenants for platform staff, optionally narrowed to one), minus any site restriction. */
function scopeOf(me, only) {
  const out = new Set();
  for (const id in DB.sites) {
    const st = DB.sites[id];
    if (me.tenant && st.tenant !== me.tenant) continue;
    if (!me.tenant && only && st.tenant !== only) continue;
    if (me.sites && me.sites.length && me.sites.indexOf(String(id)) === -1) continue;
    out.add(String(id));
  }
  return out;
}
function tenantName(tid) { return tid ? ((DB.tenants[tid] || {}).name || tid) : 'Platform'; }
function userView(n) {
  const u = DB.users[n];
  return { name: n, role: u.role, tenant: u.tenant || null, tenant_name: tenantName(u.tenant), sites: u.sites || [], disabled: !!u.disabled,
    locked: !!(u.lock_until && u.lock_until > Date.now() / 1000), last_login: u.last_login || 0, must_change: !!u.must_change, created: u.created || 0, totp: !!u.totp_on, sso: !!u.sso, breakglass: !!u.breakglass, email: u.email || '',
    orgs: (u.orgs || []).filter(function (id) { return DB.tenants[id]; }).map(function (id) { return { org: DB.tenants[id].slug, name: DB.tenants[id].name, role: (u.org_roles || {})[id] || 'viewer' }; }) };
}
function adminCount(tid, except) {
  return Object.keys(DB.users).filter(function (n) { const u = DB.users[n]; return n !== except && !u.disabled && (tid === null ? u.role === 'superadmin' : (u.tenant === tid && u.role === 'admin')); }).length;
}
function cleanSites(arr, tid) {
  return (Array.isArray(arr) ? arr : []).map(String).filter(function (id, i, a) { return DB.sites[id] && DB.sites[id].tenant === tid && a.indexOf(id) === i; });
}
function canManageUser(me, n) { const u = DB.users[n]; return !!u && (me.isSuper || (u.tenant === me.tenant && u.role !== 'superadmin')); }
function tenantForNew(me, b) { const t = me.tenant || S(b.tenant, 60) || 'default'; return DB.tenants[t] ? t : ''; }
function siteQuotaFull(tid) { const max = ((DB.tenants[tid] || {}).limits || {}).maxSites || 0; return max > 0 && Object.values(DB.sites).filter(function (x) { return x.tenant === tid; }).length >= max; }
function cookieHeader(req, user, tid) {
  const secure = req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https';
  return 'otc=' + makeCookie(user, tid) + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=43200' + (secure ? '; Secure' : '');
}
function tenantsList() {
  const now = Date.now() / 1000;
  return Object.values(DB.tenants).sort(function (a, b) { return a.name.localeCompare(b.name); }).map(function (t) {
    const sites = Object.values(DB.sites).filter(function (x) { return x.tenant === t.id; });
    let assets = 0, nw = 0;
    sites.forEach(function (x) { const sid = String(x.id); assets += Object.keys(DB.assets[sid] || {}).length; Object.values(DB.alerts[sid] || {}).forEach(function (a) { if (a.status === 'new') nw++; }); });
    return { id: t.id, name: t.name, slug: t.slug, theme: t.theme || '', status: t.status, created: t.created, limits: t.limits, sites: sites.length,
      online: sites.filter(function (x) { return siteStatus(x, now) === 'online'; }).length,
      users: Object.values(DB.users).filter(function (u) { return u.tenant === t.id; }).length, assets: assets, new_alerts: nw };
  });
}
function deleteSiteData(id) {
  const sid = String(id);
  delete DB.sites[sid]; ['assets', 'flows', 'alerts', 'snmp'].forEach(function (k) { if (DB[k]) delete DB[k][sid]; });
  delete ACT[sid]; if (DB.risk) delete DB.risk[sid]; RK_CACHE.delete(sid);
}

/* ------------------------------------------------------------------ */
/* Two-factor (TOTP), API keys, rate limit, single sign-on (OIDC)       */
/* ------------------------------------------------------------------ */
const dns = require('dns');
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32enc(buf) { let bits = 0, v = 0, o = ''; for (const b of buf) { v = (v << 8) | b; bits += 8; while (bits >= 5) { o += B32[(v >>> (bits - 5)) & 31]; bits -= 5; } } if (bits > 0) o += B32[(v << (5 - bits)) & 31]; return o; }
function b32dec(sv) { let bits = 0, v = 0; const out = []; String(sv).toUpperCase().replace(/[^A-Z2-7]/g, '').split('').forEach(function (c) { v = (v << 5) | B32.indexOf(c); bits += 5; if (bits >= 8) { out.push((v >>> (bits - 8)) & 255); bits -= 8; } }); return Buffer.from(out); }
function totpAt(secret, step) { const c = Buffer.alloc(8); c.writeBigUInt64BE(BigInt(step)); const h = crypto.createHmac('sha1', b32dec(secret)).update(c).digest(); const o = h[19] & 15;
  return String((((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3]) % 1000000).padStart(6, '0'); }
function totpVerify(secret, code, us) {            // accepts the previous, current and next 30 s window; a code works once
  code = String(code == null ? '' : code).replace(/\s/g, ''); if (!/^\d{6}$/.test(code)) return false;
  const step = Math.floor(Date.now() / 30000);
  for (let d = -1; d <= 1; d++) { const t = step + d; if (us && t <= (us.totp_last || 0)) continue; if (totpAt(secret, t) === code) { if (us) { us.totp_last = t; dirty = true; } return true; } }
  return false;
}
function userTotpOk(us, code) { const o = us.totp ? pendOpen(us.totp) : null; return !!(o && totpVerify(o.s, code, us)); }

const RATE = new Map();
function rateOk(key, max) {
  const now = Date.now(), r = RATE.get(key);
  if (!r || now - r.t > 60000) { RATE.set(key, { t: now, n: 1 }); return true; }
  return ++r.n <= max;
}
setInterval(function () { const c = Date.now() - 120000; RATE.forEach(function (v, k) { if (v.t < c) RATE.delete(k); }); }, 60000).unref();
const INGEST_PER_MIN = parseInt(process.env.INGEST_PER_MIN || '600', 10);

function findKey(tok) {
  const h = sha(tok);
  for (const tid in DB.tenants) for (const k of (DB.tenants[tid].keys || [])) if (k.hash === h) return { t: DB.tenants[tid], k: k };
  return null;
}
function baseUrl(req) {
  if (process.env.PUBLIC_URL) return process.env.PUBLIC_URL.replace(/\/+$/, '');
  const proto = req.headers['x-forwarded-proto'] || (req.socket.encrypted ? 'https' : 'http');
  return proto.split(',')[0] + '://' + (req.headers['x-forwarded-host'] || req.headers.host);
}
function tenantBySlug(x) { x = String(x || '').toLowerCase(); return Object.values(DB.tenants).find(function (t) { return t.id === x || t.slug === x; }) || null; }

/* ---- branding and hostnames per organisation ---- */
function reqHost(req) { return String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim().toLowerCase().replace(/:\d+$/, ''); }
function hostTenant(req) { const h = reqHost(req); return h ? (Object.values(DB.tenants).find(function (t) { return (t.hosts || []).indexOf(h) !== -1; }) || null) : null; }
function brandOf(t) {
  const b = (t && t.brand) || {};
  return t ? { org: t.slug, title: b.title || '', color: b.color || '', logo: b.logo ? '/brand/logo?o=' + encodeURIComponent(t.slug) + '&v=' + (b.v || 0) : '' } : {};
}
const LOGO_RE = /^data:image\/(png|jpeg|webp|svg\+xml);base64,([A-Za-z0-9+\/=]+)$/;
function ssoView(t) {
  const c = t.sso || {};
  return { enabled: !!c.enabled, issuer: c.issuer || '', client_id: c.client_id || '', has_secret: !!c.secret, enforce: !!c.enforce, default_role: c.default_role || '',
    group_claim: c.group_claim || '', group_map: c.group_map || {}, domains: (c.domains || []).map(function (d) { return { domain: d.domain, verified: !!d.verified, record: '_otsense-challenge.' + d.domain, value: d.token }; }) };
}
function verifiedDomains(t) { return ((t.sso || {}).domains || []).filter(function (d) { return d.verified; }).map(function (d) { return d.domain; }); }
const SSO_ROLES = ['admin', 'analyst', 'viewer'];
async function ssoFetch(url, opt) {          // the issuer is typed in by a tenant admin: refuse internal addresses (set SSO_ALLOW_PRIVATE=1 to allow them)
  const u = new URL(url);
  if (u.protocol !== 'https:' && !(process.env.SSO_ALLOW_HTTP === '1' && u.protocol === 'http:')) throw new Error('identity provider address must be https');
  if (process.env.SSO_ALLOW_PRIVATE !== '1') {
    const addrs = await dns.promises.lookup(u.hostname, { all: true });
    addrs.forEach(function (a) { if (/^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.|::1$|fe80|fc|fd)/i.test(a.address)) throw new Error('identity provider address is not public'); });
  }
  const r = await fetch(url, Object.assign({ signal: AbortSignal.timeout(8000), redirect: 'error' }, opt || {}));
  const txt = await r.text();
  if (txt.length > 1e6) throw new Error('identity provider reply too large');
  let j = null; try { j = JSON.parse(txt); } catch (e) {}
  return { status: r.status, json: j };
}
const OIDC_CACHE = new Map();
async function oidcConfig(issuer) {
  const c = OIDC_CACHE.get(issuer); if (c && c.t > Date.now() - 600000) return c.v;
  const r = await ssoFetch(issuer.replace(/\/+$/, '') + '/.well-known/openid-configuration');
  const v = r.json;
  if (!v || !v.authorization_endpoint || !v.token_endpoint || !v.jwks_uri || String(v.issuer).replace(/\/+$/, '') !== issuer.replace(/\/+$/, '')) throw new Error('identity provider discovery failed');
  OIDC_CACHE.set(issuer, { t: Date.now(), v: v }); return v;
}
async function verifyIdToken(idt, cfg, conf, nonce) {
  const parts = String(idt).split('.'); if (parts.length !== 3) throw new Error('bad id_token');
  const head = JSON.parse(Buffer.from(parts[0], 'base64url').toString()), claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
  if (head.alg !== 'RS256') throw new Error('unsupported token signature (RS256 only)');
  const jw = await ssoFetch(cfg.jwks_uri), key = ((jw.json || {}).keys || []).find(function (k) { return k.kid === head.kid && k.kty === 'RSA'; }) || (((jw.json || {}).keys || []).length === 1 && !head.kid ? jw.json.keys[0] : null);
  if (!key) throw new Error('signing key not found');
  const okSig = crypto.verify('RSA-SHA256', Buffer.from(parts[0] + '.' + parts[1]), crypto.createPublicKey({ key: key, format: 'jwk' }), Buffer.from(parts[2], 'base64url'));
  if (!okSig) throw new Error('token signature invalid');
  const aud = [].concat(claims.aud || []);
  if (String(claims.iss).replace(/\/+$/, '') !== conf.issuer.replace(/\/+$/, '') || aud.indexOf(conf.client_id) === -1 || !(claims.exp > Date.now() / 1000 - 60) || claims.nonce !== nonce) throw new Error('token claims invalid');
  return claims;
}
function ssoRole(conf, claims) {
  const rank = { viewer: 1, analyst: 2, admin: 3 };
  let best = '';
  if (conf.group_claim && conf.group_map && Object.keys(conf.group_map).length) {
    [].concat(claims[conf.group_claim] || []).forEach(function (g) { const r = hasOwn(conf.group_map, String(g)) ? conf.group_map[g] : ''; if (r && (!best || rank[r] > rank[best])) best = r; });
  }
  return best || (SSO_ROLES.indexOf(conf.default_role) !== -1 ? conf.default_role : '');
}
function sigCookie(obj) { const b = Buffer.from(JSON.stringify(obj)).toString('base64url'); return b + '.' + crypto.createHmac('sha256', DB.secret).update('sso|' + b).digest('base64url'); }
function readSigCookie(req, name) {
  const m = new RegExp('(?:^|;\\s*)' + name + '=([^;]+)').exec(req.headers.cookie || ''); if (!m) return null;
  const pr = m[1].split('.'); if (pr.length !== 2) return null;
  const sg = crypto.createHmac('sha256', DB.secret).update('sso|' + pr[0]).digest('base64url');
  if (sg.length !== pr[1].length || !crypto.timingSafeEqual(Buffer.from(sg), Buffer.from(pr[1]))) return null;
  try { const d = JSON.parse(Buffer.from(pr[0], 'base64url').toString()); return d.e > Date.now() ? d : null; } catch (e) { return null; }
}
function ssoPage(res, msg) { return send(res, 400, '<!doctype html><meta charset="utf-8"><title>Sign-in failed</title><style>html{background:#07111f}</style><body style="font-family:Inter,system-ui,sans-serif;max-width:480px;margin:12vh auto;padding:24px;background:#0d1b2b;color:#edf5ff;border:1px solid rgba(151,190,222,.24);border-radius:18px;border-top:3px solid #57d7e8"><h2>OTSuraksha: single sign-on failed</h2><p>' + String(msg).replace(/[<>&]/g, '') + '</p><p><a style="color:#57d7e8" href="/">Back to sign in</a></p>', 'text/html; charset=utf-8'); }
function auditExport(rows) {
  const q = function (x) { x = String(x == null ? '' : x); return /^[=+\-@]/.test(x) ? "'" + x : x; };
  return 'time,user,action,detail,organisation\n' + rows.map(function (a) { return [new Date(a.ts * 1000).toISOString(), q(a.who), q(a.action), q(a.detail), q(a.tenant || '')].map(function (c) { return '"' + c.replace(/"/g, '""') + '"'; }).join(','); }).join('\n') + '\n';
}
function tenantExport(tid) {
  const t = DB.tenants[tid], out = { exported: new Date().toISOString(), organisation: { id: t.id, name: t.name, status: t.status, limits: t.limits }, sites: [], users: [], audit: DB.audit.filter(function (a) { return a.tenant === tid; }) };
  Object.keys(DB.sites).forEach(function (sid) {
    const st = DB.sites[sid]; if (st.tenant !== tid) return;
    out.sites.push({ id: st.id, name: st.name, created: st.created, assets: Object.values(DB.assets[sid] || {}), flows: Object.values(DB.flows[sid] || {}), alerts: Object.values(DB.alerts[sid] || {}), activities: ACT[sid] || [] });
  });
  Object.keys(DB.users).forEach(function (n) { const u = DB.users[n]; if (u.tenant === tid) out.users.push({ name: n, role: u.role, sites: u.sites || [], disabled: !!u.disabled, last_login: u.last_login || 0 }); });
  return out;
}

/* ------------------------------------------------------------------ */
/* Mail (plain SMTP client, no packages) and one-time links             */
/* ------------------------------------------------------------------ */
function smtpConf(tid) {                       // an organisation may have its own mail server; otherwise the platform one is used
  const ot = tid ? DB.tenants[tid] : null;
  if (ot && ot.smtp && ot.smtp.host) {
    const o = ot.smtp;
    return { host: o.host, port: parseInt(o.port || '587', 10), mode: o.mode || 'starttls', user: o.user || '', pass: o.pass ? (pendOpen(o.pass) || {}).s || '' : '', from: o.from || ('otsense@' + o.host), source: 'organisation', own: true };
  }
  const c = DB.smtp || {}, e = process.env, host = c.host || e.SMTP_HOST;
  if (!host) return null;
  return { host: host, port: parseInt(c.port || e.SMTP_PORT || '587', 10), mode: c.mode || e.SMTP_MODE || 'starttls', user: c.user || e.SMTP_USER || '',
    pass: c.pass ? (pendOpen(c.pass) || {}).s || '' : (e.SMTP_PASS || ''), from: c.from || e.SMTP_FROM || ('otsense@' + host), source: c.host ? 'console' : 'environment' };
}
function mime(x) { x = String(x == null ? '' : x).replace(/[\r\n]+/g, ' '); return /^[\x20-\x7e]*$/.test(x) ? x : '=?UTF-8?B?' + Buffer.from(x).toString('base64') + '?='; }
async function smtpSend(conf, to, subject, body) {
  const net = require('net'), tls = require('tls');
  to = String(to).replace(/[\r\n<>]/g, '');
  if (!/^[^@\s]+@[^@\s]+$/.test(to)) throw new Error('invalid recipient address');
  let sock = null, buf = '', waiter = null;
  const pump = function () {
    if (!waiter) return;
    const lines = buf.split('\r\n'); let end = -1;
    for (let i = 0; i < lines.length - 1; i++) if (/^\d{3}( |$)/.test(lines[i])) { end = i; break; }
    if (end < 0) return;
    const rep = lines.slice(0, end + 1); buf = lines.slice(end + 1).join('\r\n');
    const w = waiter; waiter = null; w.ok({ code: parseInt(rep[end].slice(0, 3), 10), text: rep.join('\n') });
  };
  const attach = function (s) { sock = s; s.setEncoding('utf8'); s.on('data', function (d) { buf += d; pump(); }); s.on('error', function (e) { if (waiter) { const w = waiter; waiter = null; w.bad(e); } }); s.on('close', function () { if (waiter) { const w = waiter; waiter = null; w.bad(new Error('mail server closed the connection')); } }); };
  const reply = function (want) {
    return new Promise(function (ok, bad) { waiter = { ok: ok, bad: bad }; pump(); }).then(function (r) { if (want && want.indexOf(r.code) === -1) throw new Error('mail server said: ' + r.text.split('\n').pop().slice(0, 160)); return r; });
  };
  const cmd = function (line, want) { sock.write(line + '\r\n'); return reply(want); };
  const connect = function () {
    return new Promise(function (ok, bad) {
      const s = conf.mode === 'tls' ? tls.connect({ host: conf.ip || conf.host, port: conf.port, servername: conf.host }, function () { ok(s); }) : net.connect({ host: conf.ip || conf.host, port: conf.port }, function () { ok(s); });
      s.once('error', bad); s.setTimeout(20000, function () { s.destroy(); bad(new Error('mail server timed out')); });
    });
  };
  attach(await connect());
  try {
    await reply([220]);
    const me = 'otsense.local';
    let caps = (await cmd('EHLO ' + me, [250])).text;
    if (conf.mode === 'starttls') {
      await cmd('STARTTLS', [220]);
      const old = sock; old.removeAllListeners('data'); old.removeAllListeners('close'); buf = '';
      const t2 = await new Promise(function (ok, bad) { const t = tls.connect({ socket: old, servername: conf.host }, function () { ok(t); }); t.once('error', bad); });
      attach(t2); caps = (await cmd('EHLO ' + me, [250])).text;
    }
    if (conf.user) await cmd('AUTH PLAIN ' + Buffer.from('\0' + conf.user + '\0' + conf.pass).toString('base64'), [235]);
    const from = String(conf.from).replace(/[\r\n<>]/g, ''), addr = (/<([^>]+)>/.exec(conf.from) || [0, from])[1];
    await cmd('MAIL FROM:<' + addr + '>', [250]);
    await cmd('RCPT TO:<' + to + '>', [250, 251]);
    await cmd('DATA', [354]);
    const msg = ['From: ' + mime(conf.from), 'To: <' + to + '>', 'Subject: ' + mime(subject), 'Date: ' + new Date().toUTCString(), 'Message-ID: <' + crypto.randomBytes(12).toString('hex') + '@otsense>',
      'MIME-Version: 1.0', 'Content-Type: text/plain; charset=utf-8', 'Content-Transfer-Encoding: base64', '', Buffer.from(body, 'utf8').toString('base64').replace(/(.{76})/g, '$1\r\n')].join('\r\n');
    await cmd(msg + '\r\n.', [250]);
    try { sock.write('QUIT\r\n'); } catch (e) {}
  } finally { try { sock.destroy(); } catch (e) {} }
}
async function sendMail(to, subject, body, tid) {
  let c = smtpConf(tid); if (!c) throw new Error('mail is not set up yet');
  if (c.own) { const ad = await intResolve(c.host); c = Object.assign({}, c, { ip: ad.address }); }   // an organisation's own server is checked and pinned like the other outgoing connections
  return smtpSend(c, to, subject, body);
}


/* ===================================================================== */
/* SNMP switch discovery. Central keeps, per site, the list of switches  */
/* to read (with their SNMP v2c / v3 credentials, sealed). The sensor at */
/* the site receives it with its orders, reads the switches and sends    */
/* the neighbour / MAC / ARP / VLAN tables back; central then draws the  */
/* physical network diagram.                                             */
/* ===================================================================== */
const SNMP_LVL = ['noAuthNoPriv', 'authNoPriv', 'authPriv'], SNMP_AUTH = ['md5', 'sha', 'sha224', 'sha256', 'sha384', 'sha512'];
function snmpCfg(site) { return site.snmp || (site.snmp = { every: 300, targets: [], now: '' }); }
function snmpOrders(site) {
  const c = site.snmp; if (!c || !c.targets || !c.targets.length) return undefined;
  return { every: c.every || 300, now: c.now || '', targets: c.targets.map(function (t) {
    return { id: t.id, ip: t.ip, port: t.port || 161, ver: t.ver, community: intOpen(t.community), user: t.user || '', level: t.level || 'noAuthNoPriv',
      auth_proto: t.auth_proto || 'sha', auth_pass: intOpen(t.auth_pass), priv_proto: 'aes', priv_pass: intOpen(t.priv_pass) };
  }) };
}
function snmpStore(site, list) {
  const sid = String(site.id), cfg = site.snmp, now = Date.now() / 1000; if (!cfg || !cfg.targets) return;
  const ids = {}; cfg.targets.forEach(function (t) { ids[t.id] = t; });
  DB.snmp = DB.snmp || {};
  const cur = DB.snmp[sid] || (DB.snmp[sid] = { results: {} });
  const clip = function (a, n) { return Array.isArray(a) ? a.slice(0, n) : []; };
  list.slice(0, 50).forEach(function (r) {
    const id = S(r && r.id, 40); if (!r || typeof r !== 'object' || !ids[id]) return;
    const old = cur.results[id];
    if (!r.ok) {                                              // a failed read keeps the last good tables and only records the problem
      cur.results[id] = Object.assign(old || { id: id, host: S(r.host, 64) }, { ok: false, err: S(r.err, 240), at: +r.at || now });
      return;
    }
    const sy = r.sys && typeof r.sys === 'object' ? r.sys : {}, ifs = {};
    Object.keys(r.if && typeof r.if === 'object' ? r.if : {}).slice(0, 600).forEach(function (k) {
      const f = r.if[k] || {}; ifs[S(k, 12)] = { n: S(f.n, 60), d: S(f.d, 80), s: f.s | 0, hs: +f.hs || 0, a: S(f.a, 80), t: f.t | 0, m: S(f.m, 17).toLowerCase() };
    });
    const vl = {}, pv = {};
    Object.keys(r.vlans && typeof r.vlans === 'object' ? r.vlans : {}).slice(0, 512).forEach(function (k) { vl[S(k, 6)] = S(r.vlans[k], 40); });
    Object.keys(r.pvid && typeof r.pvid === 'object' ? r.pvid : {}).slice(0, 1024).forEach(function (k) { pv[S(k, 12)] = r.pvid[k] | 0; });
    cur.results[id] = { id: id, host: S(r.host, 64), ver: S(r.ver, 4), ok: true, err: '', at: +r.at || now, good_at: +r.at || now, ms: r.ms | 0,
      sys: { name: S(sy.name, 120), descr: S(sy.descr, 400), oid: S(sy.oid, 80), uptime: +sy.uptime || 0, location: S(sy.location, 120), bridge_mac: S(sy.bridge_mac, 17).toLowerCase() },
      if: ifs, vlans: vl, pvid: pv,
      lldp: clip(r.lldp, 2000).map(function (x) { return { if: S(x.if, 12), cid: S(x.cid, 60).toLowerCase(), pid: S(x.pid, 80), pdesc: S(x.pdesc, 80), name: S(x.name, 120), descr: S(x.descr, 200) }; }),
      cdp: clip(r.cdp, 1000).map(function (x) { return { if: S(x.if, 12), dev: S(x.dev, 120), port: S(x.port, 80), plat: S(x.plat, 80), ip: S(x.ip, 45) }; }),
      fdb: clip(r.fdb, 5000).map(function (x) { return { mac: S(x.mac, 17).toLowerCase(), if: S(x.if, 12), vlan: x.vlan | 0 }; }),
      arp: clip(r.arp, 4000).map(function (x) { return { ip: S(x.ip, 45), mac: S(x.mac, 17).toLowerCase(), if: S(x.if, 12) }; }) };
  });
  Object.keys(cur.results).forEach(function (k) { if (!ids[k]) delete cur.results[k]; });
  cur.at = now; dirty = true;
}
function snmpView(site) {
  const cfg = snmpCfg(site), cur = (DB.snmp || {})[String(site.id)] || { results: {} };
  return { every: cfg.every || 300, targets: cfg.targets.map(function (t) {
    const r = cur.results[t.id];
    return { id: t.id, name: t.name || '', ip: t.ip, port: t.port || 161, ver: t.ver, user: t.user || '', level: t.level || '', auth_proto: t.auth_proto || '',
      has_community: !!t.community, has_auth: !!t.auth_pass, has_priv: !!t.priv_pass,
      status: r ? { ok: !!r.ok, err: r.err || '', at: r.at || 0, good_at: r.good_at || 0, sys_name: (r.sys && r.sys.name) || '', descr: (r.sys && r.sys.descr) || '',
        ports: r.if ? Object.keys(r.if).length : 0, neighbours: (r.lldp ? r.lldp.length : 0) + (r.cdp ? r.cdp.length : 0), macs: r.fdb ? r.fdb.length : 0 } : null };
  }) };
}
function snmpTopo(sid) {
  const cur = (DB.snmp || {})[sid] || { results: {} }, A = DB.assets[sid] || {}, site = DB.sites[sid] || {};
  const byMac = {}; Object.keys(A).forEach(function (k) { const m = String((A[k].data && A[k].data.mac) || A[k].mac || '').toLowerCase(); if (m) byMac[m] = A[k]; });
  const good = Object.values(cur.results).filter(function (r) { return r.good_at && r.if; });
  const nodes = {}, edges = [], seen = {}, swByMac = {}, swByName = {}, swByHost = {}, arpIp = {}, short = function (n) { return String(n || '').toLowerCase().split('.')[0]; };
  good.forEach(function (r) {
    const id = 'sw:' + r.host;
    nodes[id] = { id: id, kind: 'switch', label: (r.sys.name || r.host), ip: r.host, mac: r.sys.bridge_mac || '', type: 'Network switch', detail: { descr: r.sys.descr, uptime: r.sys.uptime, location: r.sys.location, ver: r.ver } };
    if (r.sys.bridge_mac) swByMac[r.sys.bridge_mac] = id;
    if (r.sys.name) swByName[short(r.sys.name)] = id;
    swByHost[r.host] = id;
    r.arp.forEach(function (x) { if (x.mac && !arpIp[x.mac]) arpIp[x.mac] = x.ip; });
  });
  const portName = function (r, ix) { const f = r.if[ix]; return f ? (f.n || f.d || ('port ' + ix)) : ('port ' + ix); };
  const addEdge = function (a, b, la, lb, kind, vlan, speed) {
    const key = kind === 'trunk' ? [a + '|' + la, b + '|' + lb].sort().join('~') : a + '|' + la + '~' + b;
    if (seen[key]) return; seen[key] = 1; edges.push({ a: a, b: b, la: la, lb: lb, kind: kind, vlan: vlan || 0, speed: speed || 0 });
  };
  const summary = [], trunkMacs = {};
  good.forEach(function (r) {
    const id = 'sw:' + r.host, trunk = {}, nbMac = {};
    const nbs = r.lldp.map(function (x) { return { ix: x.if, cid: x.cid, name: x.name, rport: x.pdesc || x.pid, descr: x.descr, ip: '' }; })
      .concat(r.cdp.map(function (x) { return { ix: x.if, cid: '', name: x.dev, rport: x.port, descr: x.plat, ip: x.ip }; }));
    for (let i = nbs.length - 1; i >= 0; i--) {                                         // a neighbour that speaks both LLDP and CDP is one neighbour
      const n = nbs[i]; if (n.cid) continue;
      const twin = nbs.filter(function (m) { return m !== n && m.ix === n.ix && m.cid && (!n.name || !m.name || short(m.name) === short(n.name)); })[0];
      if (twin) { if (!twin.ip && n.ip) twin.ip = n.ip; nbs.splice(i, 1); }
    }
    nbs.forEach(function (n) {
      trunk[n.ix] = 1; if (n.cid) nbMac[n.cid] = 1;
      let other = (n.cid && swByMac[n.cid]) || (n.name && swByName[short(n.name)]) || (n.ip && swByHost[n.ip]) || '';
      if (other === id) return;
      if (!other) {
        other = 'nb:' + (n.cid || short(n.name) || (n.ip || n.ix));
        if (!nodes[other]) { const a = n.cid && byMac[n.cid]; nodes[other] = { id: other, kind: 'neighbor', label: n.name || (a && a.ip) || n.cid || n.ip, ip: (a && a.ip) || n.ip || '', mac: n.cid, type: (a && a.device_type) || 'Neighbour (LLDP/CDP)', asset: a ? a.id : '', detail: { descr: n.descr } }; }
      }
      addEdge(id, other, portName(r, n.ix), n.rport, 'trunk', 0, (r.if[n.ix] || {}).hs);
    });
    const perPort = {};
    r.fdb.forEach(function (f) { (perPort[f.if] = perPort[f.if] || []).push(f); });
    const portRows = Object.keys(r.if).map(function (ix) {
      const f = r.if[ix], nb = nbs.filter(function (n) { return n.ix === ix; })[0], macs = (perPort[ix] || []).length;
      return { ix: ix, name: f.n || f.d, status: f.s, speed: f.hs, alias: f.a, vlan: r.pvid[ix] || 0, neighbor: nb ? (nb.name || nb.cid) : '', macs: macs, type: f.t };
    });
    summary.push({ id: id, host: r.host, name: r.sys.name, descr: r.sys.descr, uptime: r.sys.uptime, location: r.sys.location, ver: r.ver, at: r.at, ok: r.ok, err: r.err, ports: portRows,
      vlans: Object.keys(r.vlans).map(function (k) { return { id: +k, name: r.vlans[k] }; }) });
    Object.keys(perPort).forEach(function (ix) {
      const list = perPort[ix]; if (trunk[ix] || list.length > 30) return;          // uplinks and busy ports only carry other switches' devices
      list.forEach(function (f) {
        if (swByMac[f.mac] || nbMac[f.mac] || nodes['nb:' + f.mac]) return;
        const a = byMac[f.mac], ip = (a && a.ip) || arpIp[f.mac] || '', nid = a ? a.id : 'mac:' + f.mac;
        if (!nodes[nid] && Object.keys(nodes).length < 600) nodes[nid] = { id: nid, kind: 'device', label: ip || f.mac, ip: ip, mac: f.mac, type: (a && a.device_type) || '', asset: a ? a.id : '', detail: { vendor: a ? a.vendor : '' } };
        if (nodes[nid]) addEdge(id, nid, portName(r, ix), '', 'access', f.vlan || r.pvid[ix] || 0, (r.if[ix] || {}).hs);
      });
    });
  });
  const failed = Object.values(cur.results).filter(function (r) { return !r.ok; }).map(function (r) { return { host: r.host, err: r.err, at: r.at }; });
  return { site: sid, site_name: site.name || '', at: cur.at || 0, nodes: Object.values(nodes), edges: edges, switches: summary, failed: failed, configured: !!(site.snmp && site.snmp.targets && site.snmp.targets.length) };
}

/* ===================================================================== */
/* Integrations: alert feeds to a SIEM (syslog, webhook) and SNMP traps   */
/* One set of settings per organisation, kept in tenant.siem. New alerts  */
/* are pushed once (a record of what was sent is kept in DB.fwd).         */
/* ===================================================================== */
const INT_CH = ['syslog', 'webhook', 'snmp'];
const INT_MIN = ['low', 'medium', 'high', 'critical'];
function intSealed(s) { return s ? pendSeal({ s: s }) : ''; }
function intOpen(b) { return b ? ((pendOpen(b) || {}).s || '') : ''; }
function intBlocked(ip) {                                   // loopback, link-local (cloud metadata) and unspecified addresses are never allowed as targets
  if (process.env.ALLOW_LOCAL_INTEGRATIONS) return false;
  ip = String(ip || '').toLowerCase().replace(/^::ffff:/, '');
  if (net.isIPv4(ip)) return inCidr(ip, '127.0.0.0/8') || inCidr(ip, '169.254.0.0/16') || inCidr(ip, '0.0.0.0/8');
  if (net.isIPv6(ip)) return ip === '::1' || ip === '::' || /^fe[89ab]/.test(ip);
  return false;
}
async function intResolve(host) {                           // returns { address, family } or throws; the address is pinned so a name cannot change between check and use
  host = String(host || '').replace(/^\[|\]$/g, '');
  if (!host || (!process.env.ALLOW_LOCAL_INTEGRATIONS && /^localhost$/i.test(host))) throw new Error('that address is not allowed');
  const list = net.isIP(host) ? [{ address: host, family: net.isIP(host) }] : await dns.promises.lookup(host, { all: true });
  if (!list.length || list.some(function (x) { return intBlocked(x.address); })) throw new Error('that address is not allowed');
  return list[0];
}
function intEvent(a, site) {
  const iso = function (s) { s = String(s || ''); return /^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/.test(s) ? s.replace(' ', 'T') + 'Z' : s; };
  return { time: iso(a.last_seen || a.first_seen), first_seen: iso(a.first_seen), organisation: tenantName(site.tenant), site: site.name || '', severity: a.severity || 'low', title: a.title || '', kind: a.kind || '',
    source: a.src || '', destination: a.dst || '', protocol: a.proto || '', detail: a.detail || '', status: a.status || 'new', mitre: a.mitre || '', policy_id: a.policy_id || '', count: a.count || 1 };
}
function cefEsc(s) { return String(s == null ? '' : s).replace(/\\/g, '\\\\').replace(/\|/g, '\\|').replace(/[\r\n]+/g, ' '); }
function cefExt(s) { return String(s == null ? '' : s).replace(/\\/g, '\\\\').replace(/=/g, '\\=').replace(/[\r\n]+/g, ' '); }
function cefLine(e) {
  const n = { low: 3, medium: 5, high: 8, critical: 10 }[e.severity] || 1;
  const ext = [(ipNum(e.source) !== null ? 'src=' : 'shost=') + cefExt(e.source), (ipNum(e.destination) !== null ? 'dst=' : 'dhost=') + cefExt(e.destination), 'proto=' + cefExt(e.protocol), 'msg=' + cefExt(e.detail),
    'cs1Label=organisation cs1=' + cefExt(e.organisation), 'cs2Label=site cs2=' + cefExt(e.site), 'cs3Label=mitre cs3=' + cefExt(e.mitre), 'cs4Label=status cs4=' + cefExt(e.status), 'cnt=' + (e.count | 0)].join(' ');
  return 'CEF:0|OTSuraksha|Central|1.0|' + cefEsc(e.policy_id ? 'policy-' + e.policy_id : (e.kind || 'alert')) + '|' + cefEsc(e.title) + '|' + n + '|' + ext;
}
function syslogLine(cfg, e) {                               // RFC 5424: <PRI>1 time host app - msgid - message  (facility local4)
  const sevn = { low: 5, medium: 4, high: 3, critical: 2 }[e.severity] || 6, pri = 20 * 8 + sevn;
  return '<' + pri + '>1 ' + new Date().toISOString() + ' ' + (os.hostname() || 'otsuraksha').replace(/\s/g, '-') + ' OTSuraksha - ALERT - ' + (cfg.format === 'json' ? JSON.stringify(e) : cefLine(e));
}
function intTimeout(ms, p) { let t; return Promise.race([p, new Promise(function (_, rej) { t = setTimeout(function () { rej(new Error('timed out')); }, ms); })]).finally(function () { clearTimeout(t); }); }
async function sendSyslog(cfg, evs) {
  const ad = await intResolve(cfg.host), lines = evs.map(function (e) { return syslogLine(cfg, e); });
  if (cfg.proto === 'udp') {
    const sock = dgram.createSocket(ad.family === 6 ? 'udp6' : 'udp4');
    try { for (const l of lines) await intTimeout(5000, new Promise(function (ok, bad) { const m = Buffer.from(l, 'utf8'); sock.send(m, 0, Math.min(m.length, 8000), cfg.port, ad.address, function (er) { er ? bad(er) : ok(); }); })); }
    finally { sock.close(); }
    return;
  }
  await intTimeout(12000, new Promise(function (ok, bad) {
    const opts = { host: ad.address, port: cfg.port }, onErr = function (er) { bad(er); };
    const s = cfg.proto === 'tls' ? tls.connect(Object.assign(opts, { servername: net.isIP(cfg.host) ? undefined : cfg.host }), go) : net.connect(opts, go);
    function go() { s.write(lines.join('\n') + '\n', function () { s.end(); ok(); }); }
    s.on('error', onErr); s.setTimeout(10000, function () { s.destroy(); bad(new Error('timed out')); });
  }));
}
function httpPost(urlStr, headers, body) {
  const u = new URL(urlStr);
  return intResolve(u.hostname).then(function (ad) {
    return intTimeout(15000, new Promise(function (ok, bad) {
      const lib = u.protocol === 'https:' ? https : http;
      const rq = lib.request({ hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80), path: u.pathname + u.search, method: 'POST', headers: Object.assign({ 'Content-Length': Buffer.byteLength(body) }, headers),
        lookup: function (h, o, cb) { if (o && o.all) cb(null, [{ address: ad.address, family: ad.family }]); else cb(null, ad.address, ad.family); } }, function (r) {
        r.resume(); r.on('end', function () { r.statusCode >= 200 && r.statusCode < 300 ? ok() : bad(new Error('the server answered HTTP ' + r.statusCode)); });
      });
      rq.on('error', bad); rq.end(body);
    }));
  });
}
async function sendWebhook(cfg, evs) {
  const hd = { 'Content-Type': 'application/json', 'User-Agent': 'OTSuraksha-Central' }, au = intOpen(cfg.auth); if (au) hd.Authorization = au;
  const body = cfg.format === 'splunk' ? evs.map(function (e) { return JSON.stringify({ time: Date.now() / 1000, source: 'otsuraksha', sourcetype: 'otsuraksha:alert', event: e }); }).join('\n')
    : JSON.stringify({ source: 'OTSuraksha Central', count: evs.length, alerts: evs });
  await httpPost(cfg.url, hd, body);
}
/* SNMP v2c trap, hand-encoded (BER) so no package is needed. Enterprise OID 1.3.6.1.4.1.99999.1 is a placeholder; the values are plain text. */
function berLen(n) { return n < 128 ? Buffer.from([n]) : n < 256 ? Buffer.from([0x81, n]) : Buffer.from([0x82, n >> 8, n & 255]); }
function tlv(tag, b) { return Buffer.concat([Buffer.from([tag]), berLen(b.length), b]); }
function berInt(n) { const a = []; let v = n; do { a.unshift(v & 255); v = Math.floor(v / 256); } while (v > 0); if (a[0] & 128) a.unshift(0); return tlv(0x02, Buffer.from(a)); }
function berOid(s) {
  const p = s.split('.').map(Number), out = [40 * p[0] + p[1]];
  p.slice(2).forEach(function (x) { const t = [x & 127]; x = Math.floor(x / 128); while (x > 0) { t.unshift((x & 127) | 128); x = Math.floor(x / 128); } t.forEach(function (y) { out.push(y); }); });
  return tlv(0x06, Buffer.from(out));
}
function berStr(s) { return tlv(0x04, Buffer.from(String(s == null ? '' : s).slice(0, 250), 'utf8')); }
function snmpTrap(community, e) {
  const E = '1.3.6.1.4.1.99999.1', vb = function (oid, val) { return tlv(0x30, Buffer.concat([berOid(oid), val])); };
  const binds = [vb('1.3.6.1.2.1.1.3.0', tlv(0x43, Buffer.from(berInt(Math.floor(process.uptime() * 100)).subarray(2)))), vb('1.3.6.1.6.3.1.1.4.1.0', berOid(E + '.0.1')),
    vb(E + '.1.1', berStr(e.title)), vb(E + '.1.2', berStr(e.severity)), vb(E + '.1.3', berStr(e.source)), vb(E + '.1.4', berStr(e.destination)), vb(E + '.1.5', berStr(e.detail)), vb(E + '.1.6', berStr(e.organisation + ' / ' + e.site))];
  const pdu = tlv(0xA7, Buffer.concat([berInt(crypto.randomBytes(3).readUIntBE(0, 3)), berInt(0), berInt(0), tlv(0x30, Buffer.concat(binds))]));
  return tlv(0x30, Buffer.concat([berInt(1), berStr(community), pdu]));
}
async function sendSnmp(cfg, evs) {
  const ad = await intResolve(cfg.host), sock = dgram.createSocket(ad.family === 6 ? 'udp6' : 'udp4'), cm = intOpen(cfg.community);
  try { for (const e of evs) await intTimeout(5000, new Promise(function (ok, bad) { const m = snmpTrap(cm, e); sock.send(m, 0, m.length, cfg.port, ad.address, function (er) { er ? bad(er) : ok(); }); })); }
  finally { sock.close(); }
}
const INT_SEND = { syslog: sendSyslog, webhook: sendWebhook, snmp: sendSnmp };
function intActive(cfg) { return !!(cfg && cfg.enabled); }
function intFwd(tid, ch) { DB.fwd = DB.fwd || {}; const t = DB.fwd[tid] = DB.fwd[tid] || {}; return t[ch] = t[ch] || {}; }
function intMarkExisting(tid, ch) {                          // when a feed is switched on, today's alerts are not sent: only alerts raised from now on
  const F = intFwd(tid, ch);
  for (const sid in DB.alerts) { const st = DB.sites[sid]; if (!st || st.tenant !== tid) continue; for (const u in DB.alerts[sid]) F[sid + '|' + u] = 1; }
}
function intNote(cfg, ok, msg, n) { cfg.last = { ok: ok, at: Date.now() / 1000, msg: ok ? '' : String(msg || '').slice(0, 200), sent: ((cfg.last && cfg.last.sent) || 0) + (n || 0) }; dirty = true; }
let intBusy = false;
async function intTick() {
  if (intBusy) return; intBusy = true;
  try {
    for (const tid in DB.tenants) {
      const t = DB.tenants[tid], cfgs = t.siem; if (!cfgs || t.status === 'suspended') continue;
      const chs = INT_CH.filter(function (ch) { return intActive(cfgs[ch]); }); if (!chs.length) continue;
      const fresh = {};
      for (const sid in DB.alerts) { const st = DB.sites[sid]; if (!st || st.tenant !== tid) continue; for (const u in DB.alerts[sid]) fresh[sid + '|' + u] = { a: DB.alerts[sid][u], st: st }; }
      for (const ch of INT_CH) { const F = intFwd(tid, ch); Object.keys(F).forEach(function (k) { if (!fresh[k]) delete F[k]; }); }   // forget alerts that no longer exist
      for (const ch of chs) {
        const cfg = cfgs[ch], F = intFwd(tid, ch), min = SEV[cfg.min] || 1;
        if (cfg.retry_at && cfg.retry_at > Date.now() / 1000) continue;
        const keys = Object.keys(fresh).filter(function (k) { const a = fresh[k].a; return !F[k] && a.status !== 'closed' && (a.sev || 0) >= min; }).slice(0, 100);
        if (!keys.length) continue;
        try { await INT_SEND[ch](cfg, keys.map(function (k) { return intEvent(fresh[k].a, fresh[k].st); })); keys.forEach(function (k) { F[k] = 1; }); cfg.retry_at = 0; intNote(cfg, true, '', keys.length); }
        catch (er) { cfg.retry_at = Date.now() / 1000 + 60; intNote(cfg, false, er.message, 0); }
      }
    }
  } catch (e) { /* a broken feed must never stop the console */ }
  intBusy = false;
}
function intView(t) {
  const s = t.siem || {}, v = {};
  INT_CH.forEach(function (ch) {
    const c = s[ch] || {};
    v[ch] = { enabled: !!c.enabled, host: c.host || '', port: c.port || (ch === 'snmp' ? 162 : 514), proto: c.proto || 'udp', format: c.format || (ch === 'webhook' ? 'json' : 'cef'), min: c.min || 'medium', url: c.url || '',
      has_auth: !!c.auth, has_community: !!c.community, last: c.last || null };
  });
  return v;
}
function mkToken(user, kind, hours) {
  const raw = crypto.randomBytes(32).toString('base64url');
  DB.tokens = DB.tokens || {}; DB.tokens[sha(raw)] = { u: user, kind: kind, exp: Date.now() / 1000 + hours * 3600 }; dirty = true; return raw;
}
function dropTokens(user) { for (const h in (DB.tokens || {})) if (DB.tokens[h].u === user) delete DB.tokens[h]; }
function emailOf(n) { const u = DB.users[n]; return u ? (u.email || (n.indexOf('@') > 0 ? n : '')) : ''; }
function orgLabel(u) { return u.tenant ? tenantName(u.tenant) : 'OTSuraksha platform'; }
async function mailLink(req, n, kind) {          // invite (3 days) or password reset (1 hour); returns '' when sent, else the reason
  const u = DB.users[n], to = emailOf(n);
  if (!to) return 'the user has no email address';
  const link = baseUrl(req) + '/reset?t=' + mkToken(n, kind, kind === 'invite' ? 72 : 1);
  const subj = kind === 'invite' ? 'You have been invited to OTSuraksha (' + orgLabel(u) + ')' : 'Reset your OTSuraksha password';
  const body = kind === 'invite'
    ? 'Hello,\n\nYou have been given access to OTSuraksha for ' + orgLabel(u) + '.\nYour user name is: ' + n + '\n\nChoose your password here (valid for 3 days):\n' + link + '\n'
    : 'Hello,\n\nSomeone asked to reset the password for user ' + n + '.\nIf it was you, choose a new password here (valid for 1 hour):\n' + link + '\n\nIf it was not you, ignore this message; your password has not changed.\n';
  try { await sendMail(to, subj, body, u && u.tenant); return ''; } catch (e) { return e.message; }
}
function resetPage() {
  return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Choose a password</title><style>body{font-family:Inter,system-ui,sans-serif;width:min(400px,calc(100% - 28px));margin:10vh auto;padding:28px 26px;color:#edf5ff;background:linear-gradient(160deg,#11263b,#081625);border:1px solid rgba(151,190,222,.24);border-radius:20px;box-shadow:0 30px 80px rgba(0,0,0,.45);border-top:3px solid #57d7e8}html{background:radial-gradient(ellipse at 10% 0,rgba(34,112,166,.3),transparent 60%),#07111f;min-height:100%}h2{margin:0 0 8px}input,button{width:100%;box-sizing:border-box;padding:11px;margin:6px 0;font-size:15px;border-radius:11px;background:rgba(255,255,255,.05);color:inherit;border:1px solid rgba(154,184,213,.25)}button{cursor:pointer;font-weight:700;background:linear-gradient(135deg,#57d7e8,#8be7db);color:#04131d;border:0}a{color:#57d7e8}#e{color:#ff9aa8;min-height:1.2em}</style></head><body><h2>Choose a password</h2><p>At least 12 characters, with letters and at least one digit or symbol.</p><input id="a" type="password" placeholder="New password" autocomplete="new-password"><input id="b" type="password" placeholder="Repeat password" autocomplete="new-password"><div id="e"></div><button id="go">Save password</button><script>document.getElementById("go").onclick=async function(){var e=document.getElementById("e");e.textContent="";var a=document.getElementById("a").value;if(a!==document.getElementById("b").value){e.textContent="The two passwords are not the same";return}var t=new URLSearchParams(location.search).get("t")||"";var r=await fetch("/api/reset/complete",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:t,password:a})});var d={};try{d=await r.json()}catch(x){}if(r.ok){document.body.innerHTML="<h2>Password saved</h2><p><a href=\\"/\\">Go to sign in</a></p>"}else e.textContent=d.error||"Failed"}</script></body></html>';
}
function newToken() { return 'otsc_' + crypto.randomBytes(32).toString('base64url'); }
/* A sensor that has not connected yet keeps its build settings (token, console password, options) sealed with AES-256-GCM, so the
   ISO / Windows app can be downloaded again or edited until the first data arrives. They are wiped on the first push, on a new token, or when the site is deleted. */
function pendKey() { return crypto.createHash('sha256').update('otsense-pending|' + DB.secret).digest(); }
function pendSeal(obj) {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', pendKey(), iv);
  const ct = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}
function pendOpen(blob) {
  try {
    const raw = Buffer.from(String(blob), 'base64'), d = crypto.createDecipheriv('aes-256-gcm', pendKey(), raw.subarray(0, 12));
    d.setAuthTag(raw.subarray(12, 28));
    return JSON.parse(Buffer.concat([d.update(raw.subarray(28)), d.final()]).toString('utf8'));
  } catch (e) { return null; }
}
const PEND_KEYS = ['platform', 'base', 'central_url', 'scan_mode', 'survey_min', 'mode', 'ip_cidr', 'gateway', 'dns', 'ca_pem', 'restrict_ui'];
function buildCtx(baseName) {
  const winInfo = findWinFull();
  const okBase = listBases().some(function (x) { return x.name === baseName; });
  if (!okBase && baseName) throw new Error('base image not found in the images folder: ' + baseName);
  const vm = findVmExe();
  return { isoPath: path.join(imageDir(), okBase ? baseName : 'otsense-sensor.iso'), srcDir: SENSOR_SRC, winFull: winInfo.path, winDiag: winInfo.diag, vmExe: vm.path, vmDiag: vm.diag,
    winExe: process.env.WINDOWS_EXE || path.join(IMG_DIR_SRC, 'windows', 'OTSense-Sensor.exe') };
}
async function sendBuildFile(res, f) {
  const name = f.name.replace(/[^A-Za-z0-9._-]/g, '_');
  if (f.iso) {            // the big reusable ISO: stream it unchanged, swapping only the 64 KB config slot
    res.writeHead(200, { 'Content-Type': f.type, 'Content-Length': f.size, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
      'Content-Disposition': 'attachment; filename="' + name + '"' });
    const part = function (start, end) { return new Promise(function (ok, bad) { if (end < start) return ok(); const rs = fs.createReadStream(f.iso.path, { start: start, end: end });
      rs.on('error', bad); rs.on('end', ok); rs.pipe(res, { end: false }); }); };
    try { await part(0, f.iso.offset - 1); res.write(f.iso.slot); await part(f.iso.offset + sensorBuild.SLOT, f.size - 1); } catch (e) { res.destroy(); return; }
    return res.end();
  }
  return send(res, 200, f.data, f.type || 'application/octet-stream', { 'Content-Disposition': 'attachment; filename="' + name + '"', 'Cache-Control': 'no-store' });
}
function siteByToken(tok) {
  if (!tok) return null;
  const h = sha(tok);
  for (const id in DB.sites) if (DB.sites[id].token_hash === h || (DB.sites[id].sensors2 || []).some(function (x) { return x.token_hash === h; })) return DB.sites[id];
  return null;
}
/* A site can have more than one sensor: the first one built for it, plus extra sensors with their own tokens (site.sensors2).
   Both kinds send data to the same site, so zones, VLANs and the Risk tab cover all of them. */
function extraSensor(site, tok) { const h = sha(tok); return (site.sensors2 || []).find(function (x) { return x.token_hash === h; }) || null; }
function ingestVia(site, body, tok) {
  const ex = extraSensor(site, tok), keep = ex ? site.pending : null;
  const r = ingest(site, body);
  if (ex) { ex.last_seen = Date.now() / 1000; ex.meta = (body.sensor && typeof body.sensor === 'object') ? { hostname: S(body.sensor.hostname, 60), version: S(body.sensor.version, 20), pps: body.sensor.pps } : {}; if (ex.pending) delete ex.pending; if (keep) site.pending = keep; }
  return r;
}
function bearer(req) {
  const a = req.headers['authorization'] || '';
  return a.toLowerCase().startsWith('bearer ') ? a.slice(7).trim() : '';
}

/* sessions: signed cookie, 12 h */
function userOrgs(u) {                          // every organisation this user may sign in to: the home one first, then any extra ones a platform admin granted
  const out = []; if (u && u.tenant) out.push(u.tenant);
  ((u && u.orgs) || []).forEach(function (id) { if (out.indexOf(id) === -1) out.push(id); });
  return out;
}
function makeCookie(user, tid) {
  const pl = { u: user, p: (DB.users[user] || {}).pv || 0, e: Date.now() + 12 * 3600e3 };
  if (tid && tid !== (DB.users[user] || {}).tenant) pl.t = tid;      // signed in to one of the extra organisations
  const body = Buffer.from(JSON.stringify(pl)).toString('base64url');
  return body + '.' + crypto.createHmac('sha256', DB.secret).update(body).digest('base64url');
}
function readCookie(req) {
  const m = /(?:^|;\s*)otc=([^;]+)/.exec(req.headers.cookie || '');
  if (!m) return null;
  const parts = m[1].split('.');
  if (parts.length !== 2) return null;
  const sig = crypto.createHmac('sha256', DB.secret).update(parts[0]).digest('base64url');
  if (sig.length !== parts[1].length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(parts[1]))) return null;
  try {
    const d = JSON.parse(Buffer.from(parts[0], 'base64url').toString());
    const u = hasOwn(DB.users, d.u) ? DB.users[d.u] : null;
    if (!u || d.e < Date.now() || (d.p || 0) !== (u.pv || 0) || u.disabled) return null;   // a password change or reset (pv) ends every older session
    let tid = u.tenant || null, role = u.role, sites = (u.sites || []).map(String);
    if (u.tenant && d.t && d.t !== u.tenant) {              // signed in to an extra organisation: it must still be granted, and it has its own role and sites
      if ((u.orgs || []).indexOf(d.t) === -1) return null;
      tid = d.t; role = (u.org_roles || {})[d.t] || 'viewer'; sites = ((u.org_sites || {})[d.t] || []).map(String);
    }
    if (tid) { const t = DB.tenants[tid]; if (!t || t.status === 'suspended') return null; }
    // role, tenant and site restriction always come from the live user record
    return { name: d.u, role: role, tenant: tid, sites: sites, must_change: !!u.must_change, theme: u.theme || '' };
  } catch (e) { return null; }
}

const fails = new Map();   // ip -> {n, t}
function clientIp(req) {
  const x = (req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return x || req.socket.remoteAddress || '';
}
function tooManyFails(ip) {
  const f = fails.get(ip);
  if (!f) return false;
  if (Date.now() - f.t > 300000) { fails.delete(ip); return false; }
  return f.n >= 15;
}
function noteFail(ip) {
  const f = fails.get(ip) || { n: 0, t: Date.now() };
  f.n++; fails.set(ip, f);
}

/* ------------------------------------------------------------------ */
/* Ingest                                                              */
/* ------------------------------------------------------------------ */
const minStr = function (a, b) { return !a ? b : (!b ? a : (a < b ? a : b)); };

/* ===== Policies (Armis-style): conditions on devices / connections / activity create alerts; policies can be enabled, disabled, edited; whitelists suppress them ===== */
const POL_SEV = ['low', 'medium', 'high', 'critical'];
const POL_FIELDS = {
  device: [['ip', 'IP address'], ['mac', 'MAC address'], ['vendor', 'Vendor'], ['type', 'Device type'], ['model', 'Model'], ['os', 'Operating system'], ['firmware', 'Firmware'], ['zone', 'Network / zone'], ['hostname', 'Host name'], ['protocol', 'Protocol'], ['port', 'Open port'], ['ot', 'OT or IT'], ['risk', 'Risk score'], ['site', 'Site']],
  connection: [['client', 'Client IP'], ['server', 'Server IP'], ['port', 'Port'], ['protocol', 'Protocol'], ['transport', 'Transport (tcp/udp)'], ['ot', 'OT or IT'], ['client_external', 'Client is external (yes/no)'], ['server_external', 'Server is external (yes/no)']],
  activity: [['function', 'Function / command'], ['protocol', 'Protocol'], ['client', 'Client IP'], ['server', 'Server IP'], ['ot', 'OT or IT']]
};
const POL_OPS = [['is', 'is'], ['is_not', 'is not'], ['contains', 'contains'], ['not_contains', 'does not contain'], ['in', 'is one of (comma list)'], ['not_in', 'is none of (comma list)'], ['gt', 'greater than'], ['gte', 'at least'], ['lt', 'less than'], ['lte', 'at most'], ['cidr', 'is in network (CIDR list)']];
const POL_KINDS = ['ip', 'cidr', 'device', 'mac', 'domain', 'hostname'];
const POL_SEED = [
  { title: 'High-risk device (risk score 70 or more)', type: 'device', conds: [{ f: 'risk', op: 'gte', v: '70' }], severity: 'high', labels: ['IT', 'Security'], mitre: '' },
  { title: 'Clear-text remote access open (Telnet / FTP / RDP)', type: 'device', conds: [{ f: 'port', op: 'in', v: '21,23,3389' }], severity: 'medium', labels: ['Security', 'Exposure'], mitre: 'T0883 Internet Accessible Device' },
  { title: 'OT asset communicates with an external address', type: 'connection', conds: [{ f: 'ot', op: 'is', v: 'OT' }, { f: 'server_external', op: 'is', v: 'yes' }], severity: 'high', labels: ['OT', 'Security'], mitre: 'T0883 Internet Accessible Device' },
  { title: 'Controller stop / restart command', type: 'activity', conds: [{ f: 'function', op: 'in', v: 'Stop,PLC Stop,Cold Restart,Warm Restart,Hot Restart' }], severity: 'critical', labels: ['OT', 'Threat'], mitre: 'T0816 Device Restart/Shutdown' },
  { title: 'Unclassified device on the network', type: 'device', conds: [{ f: 'type', op: 'in', v: 'Unclassified,Unknown' }], severity: 'low', labels: ['Asset management'], mitre: '' }];
function ensurePolicies() {
  if (!Array.isArray(DB.policies)) {
    DB.pol_seq = 1001;
    DB.policies = POL_SEED.map(function (s) { return Object.assign({ id: String(DB.pol_seq++), tenant: '', description: '', enabled: false, match: 'all', sites: [], builtin: true, updated: Date.now() / 1000, by: 'system' }, s); });
    dirty = true;
  }
  if (!DB.pol_seq) { DB.pol_seq = 2000; dirty = true; }
  if (!Array.isArray(DB.wlists)) {                    // whitelists are named lists that policies use; the old flat list is moved into named lists once
    DB.wlists = []; const keep = {};
    (Array.isArray(DB.whitelist) ? DB.whitelist : []).forEach(function (e) {
      const k = (e.tenant || '') + '|' + (e.policy || '*');
      if (!keep[k]) {
        const pol = e.policy ? DB.policies.filter(function (x) { return x.id === e.policy; })[0] : null;
        keep[k] = { id: 'L' + (DB.pol_seq++), tenant: e.tenant || '', name: e.policy ? ((pol ? pol.title : 'Policy ' + e.policy) + ' whitelist').slice(0, 80) : 'General whitelist',
          description: 'Moved from the earlier whitelist', all: !e.policy, policies: e.policy ? [e.policy] : [], entries: [], by: 'system', at: Date.now() / 1000 };
        DB.wlists.push(keep[k]);
      }
      keep[k].entries.push({ id: e.id, kind: e.kind, value: e.value, note: e.note || '', by: e.by || '', at: e.at || 0 });
    });
    delete DB.whitelist; dirty = true;
  }
}
function ipNum(s) { const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(String(s || '').trim()); if (!m || +m[1] > 255 || +m[2] > 255 || +m[3] > 255 || +m[4] > 255) return null; return (+m[1]) * 16777216 + (+m[2]) * 65536 + (+m[3]) * 256 + (+m[4]); }
function inCidr(ip, c) { const pr = String(c).trim().split('/'), x = ipNum(ip), y = ipNum(pr[0]), n = pr.length > 1 ? parseInt(pr[1], 10) : 32; if (x === null || y === null || !(n >= 0 && n <= 32)) return false; const d = Math.pow(2, 32 - n); return Math.floor(x / d) === Math.floor(y / d); }
function isExtIp(ip) { const x = ipNum(ip); if (x === null) return false; return !['10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '127.0.0.0/8', '169.254.0.0/16', '100.64.0.0/10', '224.0.0.0/3', '0.0.0.0/8'].some(function (c) { return inCidr(ip, c); }); }
function polTest(vals, op, want) {
  const lv = vals.map(function (v) { return String(v == null ? '' : v).toLowerCase(); }), w = String(want == null ? '' : want).trim().toLowerCase();
  const list = w.split(',').map(function (s) { return s.trim(); }).filter(Boolean), wn = parseFloat(w), nums = lv.map(parseFloat).filter(function (x) { return !isNaN(x); });
  switch (op) {
    case 'is': return lv.indexOf(w) !== -1;
    case 'is_not': return lv.indexOf(w) === -1;
    case 'contains': return lv.some(function (x) { return x.indexOf(w) !== -1; });
    case 'not_contains': return !lv.some(function (x) { return x.indexOf(w) !== -1; });
    case 'in': return lv.some(function (x) { return list.indexOf(x) !== -1; });
    case 'not_in': return !lv.some(function (x) { return list.indexOf(x) !== -1; });
    case 'gt': return nums.some(function (x) { return x > wn; });
    case 'gte': return nums.some(function (x) { return x >= wn; });
    case 'lt': return nums.some(function (x) { return x < wn; });
    case 'lte': return nums.some(function (x) { return x <= wn; });
    case 'cidr': return lv.some(function (x) { return list.some(function (c) { return inCidr(x, c); }); });
  }
  return false;
}
function polWhitelisted(lists, polId, t) {
  return lists.some(function (l) {
    if (!l.all && (l.policies || []).indexOf(polId) === -1) return false;     // this list is not attached to this policy
    return (l.entries || []).some(function (e) { return wlEntryMatch(e, t); });
  });
}
function wlEntryMatch(e, t) {
  {
    const v = String(e.value).toLowerCase();
    if (e.kind === 'ip' || e.kind === 'device') return t.ips.indexOf(v) !== -1 || t.ids.indexOf(v) !== -1;
    if (e.kind === 'mac') return t.macs.indexOf(v) !== -1;
    if (e.kind === 'cidr') return t.ips.some(function (ip) { return inCidr(ip, v); });
    const h = v.replace(/^[a-z]+:\/\//, '').split('/')[0].replace(/^\*\./, '');
    return t.names.some(function (n) { return n === h || n.endsWith('.' + h); });
  }
}
function evalPolicies(site) {
  const sid = String(site.id), A = DB.assets[sid] || {}, F = DB.flows[sid] || {}, L = DB.alerts[sid] || (DB.alerts[sid] = {});
  const tn = site.tenant || '', now = Date.now() / 1000, stamp = new Date().toISOString().slice(0, 19).replace('T', ' '), keep = {};
  const pols = (DB.policies || []).filter(function (p) { return p.enabled && (p.tenant === '' || p.tenant === tn) && (!p.sites || !p.sites.length || p.sites.indexOf(sid) !== -1); });
  const wl = (DB.wlists || []).filter(function (w) { return w.tenant === '' || w.tenant === tn; });
  const lc = function (a) { return (a || []).map(function (x) { return String(x).toLowerCase(); }); };
  function raise(p, key, t, text) {
    const uid = 'pol:' + p.id + ':' + key, old = L[uid];
    if (polWhitelisted(wl, p.id, t)) return;
    keep[uid] = 1;
    const cond = p.conds.map(function (c) { return c.f + ' ' + c.op.replace('_', ' ') + ' ' + c.v; }).join(p.match === 'any' ? ' OR ' : ' AND ');
    L[uid] = { uid: uid, severity: p.severity, sev: SEV[p.severity], kind: 'policy', title: p.title + ' - ' + t.label, src: t.src, dst: t.dst || '', proto: t.proto || '',
      detail: (p.description ? p.description + ' ' : '') + 'Policy #' + p.id + ' matched (' + cond + ').', count: 1, first_seen: (old && old.first_seen) || stamp, last_seen: stamp,
      mitre: p.mitre || '', status: old ? old.status : 'new', note: old ? old.note : '', handled_by: old ? old.handled_by : '', handled_at: old ? old.handled_at : 0, updated: now,
      policy_id: p.id, policy_title: p.title, wl_kind: t.wl[0], wl_value: t.wl[1], search: ('policy ' + p.title + ' ' + t.label + ' ' + p.severity + ' ' + (p.labels || []).join(' ')).toLowerCase().slice(0, 600) };
  }
  pols.forEach(function (p) {
    const test = function (view) { const f = function (c) { return polTest(view[c.f] || [], c.op, c.v); }; return p.match === 'any' ? p.conds.some(f) : p.conds.every(f); };
    if (p.type === 'device') {
      for (const id in A) {
        const a = A[id], d = a.data || {}, hn = d.hostnames || a.hostnames || [], ip = a.ip || d.ip || '', mac = d.mac || a.mac || '';
        const v = { ip: [ip], mac: [mac], vendor: [d.vendor || d.mac_vendor || a.vendor || ''], type: [d.device_type || a.device_type || ''], model: [d.model || a.model || ''], os: [d.os_guess || a.os || ''], firmware: [d.firmware || a.firmware || ''],
          zone: [d.zone || a.zone || ''], hostname: hn, protocol: a.protocols || d.ot_protocols || [], port: (d.listening_ports || []).map(function (x) { return String(x).split('/')[0]; }), ot: [(a.ot || d.is_ot) ? 'OT' : 'IT'],
          risk: [a.risk != null ? a.risk : (d.risk || 0)], site: [site.name || ''] };
        if (!test(v)) continue;
        raise(p, id, { label: ip || id, src: ip, ips: lc(a.ips && a.ips.length ? a.ips : [ip]), ids: lc([id, ip].concat(a.keys || [])), macs: lc(a.macs && a.macs.length ? a.macs : [mac]), names: lc(hn), wl: ['ip', ip] });
      }
    } else {
      for (const fid in F) {
        const f = F[fid], fn = Object.keys(f.funcs || {}), cl = f.client || '', sv = f.server || '';
        const v = { client: [cl], server: [sv], port: [String(f.port || '')], protocol: [f.proto || ''], transport: [f.l4 || ''], ot: [f.ot ? 'OT' : 'IT'], client_external: [isExtIp(cl) ? 'yes' : 'no'], server_external: [isExtIp(sv) ? 'yes' : 'no'], function: fn };
        if (!test(v)) continue;
        raise(p, fid, { label: cl + ' to ' + sv + (f.port ? ':' + f.port : ''), src: cl, dst: sv, proto: f.proto || '', ips: lc([cl, sv]), ids: lc([cl, sv]), macs: [], names: lc([cl, sv]), wl: [isExtIp(sv) || !isExtIp(cl) ? 'ip' : 'ip', isExtIp(sv) ? sv : (isExtIp(cl) ? cl : sv)] });
      }
    }
  });
  for (const uid in L) if (L[uid].kind === 'policy' && !keep[uid]) delete L[uid];
}
function evalAllPolicies() { for (const id in DB.sites) { const s = DB.sites[id]; try { evalPolicies(Object.assign({}, s, { id: s.id !== undefined ? s.id : id })); } catch (e) { console.error('policy evaluation failed for site ' + id + ': ' + e.message); } } dirty = true; }

function ingest(site, body) {
  const now = Date.now() / 1000, sid = String(site.id);
  const A = DB.assets[sid] || (DB.assets[sid] = {});
  const F = DB.flows[sid] || (DB.flows[sid] = {});
  const L = DB.alerts[sid] || (DB.alerts[sid] = {});
  const n = { assets: 0, flows: 0, alerts: 0, rejected: 0 };
  const tn = DB.tenants[site.tenant] || {}, maxA = (tn.limits && tn.limits.maxAssets) || 0;
  let tcount = 0;
  if (maxA) for (const id in DB.sites) if (DB.sites[id].tenant === site.tenant) tcount += Object.keys(DB.assets[id] || {}).length;

  /* Where did this data come from? Every asset remembers which sensor saw it, on which interface, and how (packets or an active scan). */
  const m0 = (body.sensor && typeof body.sensor === 'object') ? body.sensor : {};
  const sName = S(m0.hostname, 60) || 'sensor', sIface = S(m0.iface, 80), sVer = S(m0.version, 20);
  const actInfo = (m0.active && typeof m0.active === 'object') ? m0.active : {};
  const stampNow = new Date().toISOString().slice(0, 19).replace('T', ' ');
  function seenBy(old, hasPkt, hasScan, ports) {
    const sb = Object.assign({}, (old && old.seen_by) || {});
    const via = hasPkt ? (hasScan ? 'passive capture + active scan' : 'passive capture') : (hasScan ? 'active scan' : 'passive capture');
    const pl = (hasPkt && Array.isArray(ports) ? ports : []).slice(0, 8).map(function (x) { return { iface: S(x && x.iface, 60), packets: parseInt(x && x.packets, 10) || 0 }; }).filter(function (x) { return x.iface; });
    const iface = pl.length ? pl.map(function (x) { return x.iface; }).join(', ') : (hasPkt ? sIface : S(actInfo.iface || sIface, 80));
    sb[sName] = { sensor: sName, version: sVer, iface: iface, ports: pl, via: via, method: hasScan ? S(actInfo.method, 80) : '', subnet: hasScan ? S(actInfo.subnet, 40) : '', last: stampNow };
    const ks = Object.keys(sb);
    if (ks.length > 10) ks.sort(function (x, y) { return String(sb[x].last).localeCompare(String(sb[y].last)); }).slice(0, ks.length - 10).forEach(function (k) { delete sb[k]; });
    return { seen_by: sb, sensor: sName, iface: iface, via: via };
  }

  (Array.isArray(body.assets) ? body.assets : []).forEach(function (a) {
    try {
      if (!a || !a.id) throw new Error('no id');
      const key = S(a.id, 200), rs = devFor(A, key, a, now), old = rs.dev;
      if (!old) { if (maxA && tcount >= maxA) { n.rejected++; n.quota = 'asset limit of this organisation reached'; return; } tcount++; }
      const id = old ? old.id : newDevId();
      a.key = key; a.id = id;
      const otp = a.ot_protocols || [];
      const protos = Array.from(new Set([].concat(otp, Object.keys(a.serves || {}), Object.keys(a.uses || {})))).sort();
      const hn = a.hostnames || [], props = a.properties || {}, tags = a.tags || {};
      const search = [a.ip, a.mac, a.vendor, a.mac_vendor, a.device_type, a.subtype, a.model, a.firmware, a.serial,
        a.os_guess, a.zone, a.purdue_guess, protos.join(' '), hn.join(' '), (a.listening_ports || []).join(' '),
        (a.flags || []).join(' '), Object.keys(props).map(function (k) { return props[k]; }).join(' '),
        Object.keys(tags).map(function (k) { return [].concat(tags[k]).join(' '); }).join(' ')]
        .filter(Boolean).join(' ').toLowerCase().slice(0, 6000);
      A[id] = { id: id, ip: S(a.ip, 64), mac: S(a.mac, 32), vendor: S(a.vendor, 120), device_type: S(a.device_type, 80),
        model: S(a.model, 200), firmware: S(a.firmware, 80), os: S(a.os_guess, 120), zone: S(a.zone, 80),
        hostnames: hn.slice(0, 10), ot: a.is_ot ? 1 : 0, risk: parseInt(a.risk, 10) || 0, protocols: protos,
        first_seen: minStr(old && old.first_seen, S(a.first_seen, 24)), last_seen: S(a.last_seen, 24),
        updated: now, search: search, data: a };
      devIdentity(A[id], old, key, S(a.ip, 64), rs.macs, S(a.last_seen, 24)); devIdxPut(A, A[id]);
      const flg = Array.isArray(a.flags) ? a.flags : [];
      Object.assign(A[id], seenBy(old, (parseInt(a.tx_packets, 10) || 0) + (parseInt(a.rx_packets, 10) || 0) > 0 && (parseInt(m0.packets, 10) || 0) > 0, flg.indexOf('active-scan') !== -1, a.ifaces));
      n.assets++;
    } catch (e) { n.rejected++; }
  });

  /* Devices found by an ACTIVE scan also arrive in the sensor status ("active" list). Sensors that see no packets (a phone, a PC without
     a capture driver) never turned them into assets, so central does it here: every scanned device that is not already an asset (matched by IP) is added. */
  const act = body.sensor && typeof body.sensor === 'object' ? body.sensor.active : null;
  if (act && act.enabled !== false && Array.isArray(act.list)) {
    const SAL = ACT[sid] || (ACT[sid] = []);
    const scanAct = function (ip, text, ot, detail) {   // a line on the Activity tab for what an active scan found or lost
      const r = { sid: site.id, sensor: sName, rx: Math.floor(now), t: now, first: stamp, last: stamp, src: ip, dst: '', src_mac: '', dst_mac: '', vlan: 0, proto: 'Scan', l4: '', port: 0,
        func: text, cat: 'info', ot: ot ? 1 : 0, pkts: 1, bytes: 0, detail: detail || '' };
      SAL.push(r); actPush(r);
    };
    const haveIp = new Set(Object.keys(A).map(function (k) { return A[k].ip; }));
    const stamp = new Date().toISOString().slice(0, 19).replace('T', ' ');
    act.list.slice(0, 300).forEach(function (d) {
      try {
        const ip = S(d && d.ip, 64);
        if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) return;
        const key = 'ip:' + ip, mac = S(d.mac, 32).toLowerCase(), vendor = S(d.vendor, 120), name = S(d.name, 120);
        const rs = devFor(A, key, { ip: ip, mac: mac }, now), old = rs.dev;
        if (!old && assetByIp(A, ip)) return;                     // the sensor already sent this device as a real asset
        if (old && !old.scan_only) return;
        if (!old) { if (maxA && tcount >= maxA) { n.rejected++; return; } tcount++; }   // organisation asset limit
        const id = old ? old.id : newDevId();
        const hn = name ? [name] : [];
        const dtype = S(d.type, 80), model = S(d.model, 200), osn = S(d.os, 120), fw = S(d.firmware, 80), ser = S(d.serial, 80);
        const ots = Array.isArray(d.ot) ? d.ot.slice(0, 6).map(function (x) { return S(x, 40); }) : [];
        const pnum = Array.isArray(d.ports) ? d.ports.slice(0, 40).map(function (x) { return parseInt(x, 10) || 0; }).filter(Boolean) : [];
        const lp = pnum.slice(0, 20).map(function (x) { return x + '/tcp'; });
        let prisk = 0;
        pnum.forEach(function (p) {
          const r = PORT_RISK[p]; if (!r) return;
          prisk += r[1];
          const uid = 'port:' + ip + ':' + p, oa = L[uid];
          L[uid] = { uid: uid, severity: r[0], sev: SEV[r[0]], kind: 'open-port', title: r[2] + ' on ' + ip, src: ip, dst: ip, proto: 'tcp/' + p, detail: 'Found by the active scan: port ' + p + ' (' + (PORT_NAME[p] || 'unknown') + ') answers on ' + ip + '.',
            count: 1, first_seen: (oa && oa.first_seen) || stamp, last_seen: stamp, mitre: '', status: oa ? oa.status : 'new', note: oa ? oa.note : '', handled_by: oa ? oa.handled_by : '', handled_at: oa ? oa.handled_at : 0,
            updated: now, search: ('open-port ' + r[2] + ' ' + ip + ' tcp/' + p + ' ' + r[0]).toLowerCase() };
          n.alerts++;
        });
        prisk = Math.min(100, prisk);
        const data = { id: id, ip: ip, mac: mac || null, vendor: vendor, mac_vendor: vendor, device_type: dtype || typeFromPorts(pnum), model: model, firmware: fw, serial: ser,
          os_guess: osn, hostnames: hn, flags: ['active-scan'], is_ot: ots.length > 0, risk: prisk,
          ot_protocols: ots, listening_ports: lp, tags: {}, properties: d.asked ? { asked: S(d.asked, 200) } : {}, first_seen: (old && old.first_seen) || stamp, last_seen: stamp };
        const oldLp = (old && old.data && old.data.listening_ports) || [];
        if (!old) scanAct(ip, 'New device found on the network' + (lp.length ? ' - open ports ' + lp.join(', ') : ''), pnum.some(function (p) { return PORT_OT[p]; }));
        else {
          if (old.gone) scanAct(ip, 'Device is back on the network', 0);
          lp.forEach(function (x) { if (oldLp.indexOf(x) === -1) { const pn = parseInt(x, 10); scanAct(ip, 'Port ' + pn + (PORT_NAME[pn] ? ' (' + PORT_NAME[pn] + ')' : '') + ' opened', PORT_OT[pn], 'Found by the active scan'); } });
        }
        A[id] = { id: id, ip: ip, mac: mac, vendor: vendor, device_type: data.device_type, model: model, firmware: fw, os: osn, zone: '', hostnames: hn, ot: ots.length ? 1 : 0, risk: prisk, protocols: ots,
          first_seen: data.first_seen, last_seen: stamp, updated: now, scan_only: true, search: [ip, mac, vendor, name, dtype, data.device_type, model, osn, fw, ser, ots.join(' '), lp.join(' '), 'active-scan'].filter(Boolean).join(' ').toLowerCase(), data: data };
        devIdentity(A[id], old, key, ip, rs.macs, stamp); devIdxPut(A, A[id]);
        Object.assign(A[id], seenBy(old, false, true));
        A[id].gone = false;
        n.assets++;
      } catch (e) { n.rejected++; }
    });
    const nowIps = new Set(act.list.map(function (d) { return S(d && d.ip, 45); }));
    if (act.list.length) Object.keys(A).forEach(function (k) {
      const a = A[k];
      if (a.scan_only && !a.gone && a.ip && !nowIps.has(a.ip)) { a.gone = true; scanAct(a.ip, 'Device left the network (no longer answers the scan)', 0); }
    });
    const sig = act.list.map(function (d) { return S(d && d.ip, 45) + ':' + (Array.isArray(d && d.ports) ? d.ports.join('.') : ''); }).sort().join(',');
    if (site.scan_sig !== sig || !site.scan_sum_at || now - site.scan_sum_at > 600) {      // a summary line when the scan result changed, and at least every 10 minutes
      site.scan_sig = sig; site.scan_sum_at = now;
      const withPorts = act.list.filter(function (d) { return Array.isArray(d && d.ports) && d.ports.length; }).length;
      scanAct(S(actInfo.subnet, 40) || 'network', 'Scan result: ' + act.list.length + ' devices answered, ' + withPorts + ' with open ports', 0, 'Active scan by ' + sName);
    }
  }

  try { devAutoMerge(sid); } catch (e) { console.error('device merge check failed: ' + e.message); }
  (Array.isArray(body.flows) ? body.flows : []).forEach(function (f) {
    try {
      if (!f || !f.fid) throw new Error('no fid');
      const fid = S(f.fid, 300), old = F[fid], funcs = f.functions || {};
      F[fid] = { fid: fid, client: S(f.client, 80), server: S(f.server, 80), proto: S(f.proto, 60), l4: S(f.l4, 8),
        port: parseInt(f.port, 10) || 0, ot: f.ot ? 1 : 0, packets: parseInt(f.packets, 10) || 0, bytes: parseInt(f.bytes, 10) || 0,
        first_seen: minStr(old && old.first_seen, S(f.first, 24)), last_seen: S(f.last, 24), funcs: funcs, updated: now,
        search: [f.client, f.server, f.proto, f.l4, f.port, Object.keys(funcs).join(' ')].join(' ').toLowerCase().slice(0, 1500) };
      n.flows++;
    } catch (e) { n.rejected++; }
  });

  (Array.isArray(body.alerts) ? body.alerts : []).forEach(function (a) {
    try {
      if (!a || !a.uid) throw new Error('no uid');
      const uid = S(a.uid, 64), old = L[uid];
      const sev = SEV.hasOwnProperty(a.severity) ? a.severity : 'info';
      const count = parseInt(a.count, 10) || 1;
      let status = old ? old.status : 'new';
      if (old && old.status === 'closed' && count > old.count) status = 'new';   // closed alerts reopen if they recur
      L[uid] = { uid: uid, severity: sev, sev: SEV[sev], kind: S(a.kind, 40), title: S(a.title, 300), src: S(a.src, 120),
        dst: S(a.dst, 120), proto: S(a.proto, 60), detail: S(a.detail, 300), count: count,
        first_seen: minStr(old && old.first_seen, S(a.first, 24)), last_seen: S(a.last, 24), mitre: S(a.mitre, 20),
        status: status, note: old ? old.note : '', handled_by: old ? old.handled_by : '', handled_at: old ? old.handled_at : 0,
        updated: now, search: [a.kind, a.title, a.src, a.dst, a.proto, a.detail, a.mitre, sev].join(' ').toLowerCase().slice(0, 1500) };
      n.alerts++;
    } catch (e) { n.rejected++; }
  });

  n.activities = 0;
  const sensorName = S(body.sensor && body.sensor.hostname, 60);
  const seen = site.act_seen || (site.act_seen = {});
  const AL = ACT[sid] || (ACT[sid] = []);
  (Array.isArray(body.activities) ? body.activities : []).forEach(function (a) {
    try {
      if (!a || !a.src || !a.proto) throw new Error('bad activity');
      const boot = S(a.boot, 24), seq = parseInt(a.seq, 10) || 0;
      if (boot && seq) {                              // a retried push must not duplicate rows
        if (seen[boot] && seq <= seen[boot]) return;
        seen[boot] = seq;
      }
      const cat = ACT_CATS.indexOf(a.cat) !== -1 ? a.cat : 'info';
      const first = S(a.first, 24), last = S(a.last, 24);
      const r = { sid: site.id, sensor: sensorName, rx: Math.floor(now), t: parseUtc(last) || now, first: first, last: last,
        src: S(a.src, 80), dst: S(a.dst, 80), src_mac: S(a.src_mac, 20), dst_mac: S(a.dst_mac, 20), vlan: parseInt(a.vlan, 10) || 0,
        proto: S(a.proto, 60), l4: S(a.l4, 8), port: parseInt(a.port, 10) || 0, func: S(a.func, 120), cat: cat,
        ot: a.ot ? 1 : 0, pkts: parseInt(a.pkts, 10) || 1, bytes: parseInt(a.bytes, 10) || 0, detail: S(a.detail, 200) };
      AL.push(r);
      actPush(r);
      n.activities++;
    } catch (e) { n.rejected++; }
  });
  const bootKeys = Object.keys(seen);
  if (bootKeys.length > 20) bootKeys.slice(0, bootKeys.length - 20).forEach(function (k) { delete seen[k]; });
  if (AL.length > ACT_MAX) AL.splice(0, AL.length - ACT_MAX);

  const meta = (body.sensor && typeof body.sensor === 'object') ? body.sensor : {};
  site.last_seen = now;
  if (site.pending) { delete site.pending; audit('system', 'sensor.files.removed', site.name + ' (sensor connected)', site.tenant); }   // first data arrived: the stored ISO/app settings are no longer needed
  site.interval = Math.max(5, Math.min(Number.isInteger(meta.interval) ? meta.interval : 30, 3600));
  site.meta = meta;
  dirty = true;
  try { evalPolicies(site); } catch (e) { console.error('policy evaluation failed: ' + e.message); }
  return n;
}

function purge() {
  for (const h in (DB.tokens || {})) if (DB.tokens[h].exp < Date.now() / 1000) { delete DB.tokens[h]; dirty = true; }
  const acut = Date.now() / 1000 - ACT_RETENTION_S;
  for (const sid in ACT) ACT[sid] = ACT[sid].filter(function (r) { return (r.rx || r.t) >= acut; });
  compactActivities();
  const now = Date.now() / 1000;
  try { vulnPrune(); } catch (e) { console.error('Vulnerability clean-up failed: ' + e.message); }
  try { pcapPrune(); } catch (e) { console.error('Capture clean-up failed: ' + e.message); }
  ['assets', 'flows', 'alerts'].forEach(function (k) {
    for (const sid in DB[k]) {
      const tn = DB.tenants[tenantOfSite(sid)], days = tn && tn.limits && tn.limits.retentionDays;
      const cut = now - (days ? days * 86400 : RETENTION_S);
      for (const id in DB[k][sid]) if (DB[k][sid][id].updated < cut) { delete DB[k][sid][id]; dirty = true; if (k === 'assets') DEVV++; }
    }
  });
}

/* ------------------------------------------------------------------ */
/* Queries                                                             */
/* ------------------------------------------------------------------ */
function parseQ(q) {
  /* grammar:  [-]key:value  [-]key:"two words"  [-]key:=exact value  bare words; "in:assets" (the section) is ignored here */
  const out = [], re = /(-?)(?:([a-z]+):(=?))?(?:"([^"]*)"|(\S+))/gi;
  let m;
  while ((m = re.exec(q || ''))) {
    const val = (m[4] != null ? m[4] : m[5]).toLowerCase();
    const key = m[2] ? m[2].toLowerCase() : '';
    if (key === 'in') continue;
    if (val) out.push({ neg: m[1] === '-', key: key, val: val, exact: m[3] === '=' });
  }
  return out;
}
const FIELDS = {
  assets: { category: 'category', vendor: 'vendor', type: 'device_type', proto: 'protocols', ip: 'ips', mac: 'macs', os: 'os', model: 'model', zone: 'zone', vlan: 'vlan', segment: 'seg_zone', id: 'id', device: 'id' },
  alerts: { kind: 'kind', sev: 'severity', mitre: 'mitre', status: 'status', src: 'src', dst: 'dst', proto: 'proto' },
  flows: { proto: 'proto', port: 'port', client: 'client', server: 'server', func: 'funcs' },
  activities: { proto: 'proto', port: 'port', src: 'src', dst: 'dst', ip: 'ips', func: 'func', cat: 'cat', sensor: 'sensor', l4: 'l4', mac: 'macs', detail: 'detail' }
};
function fieldText(r, f) {
  const v = r[f];
  if (Array.isArray(v)) return v.join(' ').toLowerCase();
  if (v && typeof v === 'object') return Object.keys(v).join(' ').toLowerCase();
  return String(v == null ? '' : v).toLowerCase();
}
/* ---- segmentation zones: which zone (and VLAN) a device belongs to ---- */
const ZCACHE = {};
function zIpOk(t) { return /^\d+\.\d+\.\d+\.\d+$/.test(t) && t.split('.').every(function (x) { return +x <= 255; }); }
function zIpN(t) { return t.split('.').reduce(function (a, b) { return a * 256 + (+b); }, 0); }
function zParseSpec(t) {       // 192.168.1.0/24, 192.168.1.10-192.168.1.24, 192.168.1.10-24 or one IP
  t = String(t || '').trim(); let m;
  if ((m = t.match(/^(\d+\.\d+\.\d+\.\d+)\s*\/\s*(\d+)$/))) { const bits = +m[2]; if (!zIpOk(m[1]) || bits > 32) return null; const size = Math.pow(2, 32 - bits), lo = Math.floor(zIpN(m[1]) / size) * size; return { lo: lo, hi: lo + size - 1 }; }
  if ((m = t.match(/^(\d+\.\d+\.\d+\.\d+)\s*-\s*(\d+\.\d+\.\d+\.\d+|\d+)$/))) { const e = m[2].indexOf('.') < 0 ? m[1].split('.').slice(0, 3).join('.') + '.' + m[2] : m[2]; if (!zIpOk(m[1]) || !zIpOk(e)) return null; const a = zIpN(m[1]), b = zIpN(e); return b < a ? null : { lo: a, hi: b }; }
  if (zIpOk(t)) { const n = zIpN(t); return { lo: n, hi: n }; }
  return null;
}
function zParseVlans(t) {      // "10, 20, 100-110"
  const out = [];
  String(t || '').split(/[;,\s]+/).filter(Boolean).forEach(function (x) {
    const m = x.match(/^(?:vlan)?(\d{1,4})(?:-(\d{1,4}))?$/i); if (!m) return;
    const a = +m[1], b = m[2] ? +m[2] : a; if (a >= 0 && b <= 4095 && b >= a) out.push({ lo: a, hi: b });
  });
  return out;
}
function zonesOfSite(sid) {
  const list = (DB.zones || {})[String(sid)]; if (!list || !list.length) return null;
  const key = JSON.stringify(list); if (ZCACHE[sid] && ZCACHE[sid].k === key) return ZCACHE[sid].z;
  const z = [];
  list.forEach(function (e) {
    const rg = String(e.spec || '').split(/[;,]/).map(zParseSpec).filter(Boolean), vl = zParseVlans(e.vlans);
    if (e.name && (rg.length || vl.length)) z.push({ name: e.name, level: e.level, fw: String(e.fw || '').trim(), ranges: rg, vlans: vl, vlansTxt: String(e.vlans || '').trim() });
  });
  ZCACHE[sid] = { k: key, z: z }; return z;
}
/* a device tagged with a VLAN that a zone lists goes to that zone (the tag is what the switch really did);
   otherwise the zone with the narrowest IP range that holds its address */
function zoneFor(sid, ip, vlans) {
  const zs = zonesOfSite(sid); if (!zs) return null;
  for (let i = 0; i < zs.length; i++) for (let k = 0; k < (vlans || []).length; k++) if (zs[i].vlans.some(function (r) { return vlans[k] >= r.lo && vlans[k] <= r.hi; })) return zs[i];
  if (!zIpOk(String(ip || ''))) return null;
  const n = zIpN(ip); let best = null, bs = 0;
  zs.forEach(function (z) { z.ranges.forEach(function (r) { if (n >= r.lo && n <= r.hi && (!best || r.hi - r.lo < bs)) { best = z; bs = r.hi - r.lo; } }); });
  return best;
}
function assetSeg(sid, r) {
  const vl = ((r.data && r.data.vlans) || []).map(function (x) { return parseInt(x, 10); }).filter(function (x) { return x >= 0; });
  const z = zoneFor(sid, r.ip, vl);
  /* no 802.1Q tag seen (Wi-Fi, an access port, an active scan): use the VLAN typed into the zone this device's IP falls in */
  const fromZone = !vl.length && z && z.ranges.length && z.vlansTxt;
  return { vlan: vl.length ? vl.join(', ') : (fromZone ? z.vlansTxt : ''), vlan_src: vl.length ? 'tag' : (fromZone ? 'zone' : ''), seg_zone: z ? z.name : '', seg_level: z ? z.level : '', seg_fw: z ? z.fw : '' };
}
function segOfIp(sid, ip) { const a = assetByIp(DB.assets[sid], ip); return assetSeg(sid, a || { ip: ip, data: {} }); }
function flowSeg(sid, f) { const c = segOfIp(sid, f.client), t = segOfIp(sid, f.server); return Object.assign({}, f, { c_vlan: c.vlan, s_vlan: t.vlan, c_zone: c.seg_zone, s_zone: t.seg_zone }); }
/* ---- search helpers: IP / CIDR / range, MAC and exact-match aware ---- */
const IP_KEYS = { ip: 1, src: 1, dst: 1, client: 1, server: 1, ips: 1 }, MAC_KEYS = { mac: 1, macs: 1 };
function qVals(r, f) {                    // the values of one field as a list of lower-case strings
  const v = r[f];
  if (Array.isArray(v)) return v.map(function (x) { return String(x).toLowerCase(); });
  if (v && typeof v === 'object') return Object.keys(v).map(function (x) { return x.toLowerCase(); });
  const s = String(v == null ? '' : v).toLowerCase();
  return f === 'vlan' ? s.split(/,\s*/).filter(Boolean) : [s];
}
function macNorm(x) { return String(x || '').toLowerCase().replace(/[^0-9a-f]/g, ''); }
function qHit(t, f, r) {
  const vals = qVals(r, f);
  if (IP_KEYS[t.key]) {
    const spec = zParseSpec(t.val);
    if (spec) return vals.some(function (v) { return v.split(/[\s,]+/).some(function (ip) { return zIpOk(ip) && zIpN(ip) >= spec.lo && zIpN(ip) <= spec.hi; }); });
  }
  if (MAC_KEYS[t.key]) {
    const n = macNorm(t.val);
    if (n.length >= 2) return vals.some(function (v) { return v.split(/[\s,]+/).some(function (m) { const mn = macNorm(m); return t.exact || n.length === 12 ? mn === n : mn.indexOf(n) !== -1; }); });
  }
  if (t.exact) return vals.some(function (v) { return v === t.val; });
  return vals.some(function (v) { return v.indexOf(t.val) !== -1; });
}
function assetCategory(r) {
  const t = String(r.device_type || '').toLowerCase();
  if (!t || /unclassified|unknown/.test(t)) return r.ot ? 'Industrial control' : 'Unclassified';
  if (/plc|rtu|controller|hmi|scada|drive|ied|relay|dcs|historian|engineering|i\/o|sensor|meter|robot|inverter/.test(t) || r.ot) return 'Industrial control';
  if (/router|switch|gateway|firewall|access point|wireless|wi-?fi|modem|network|bridge/.test(t)) return 'Network equipment';
  if (/camera|nvr|dvr|video|badge|door|alarm/.test(t)) return 'Security and cameras';
  if (/printer|scanner|mfp/.test(t)) return 'Printers';
  if (/phone|mobile|tablet|android|ios/.test(t)) return 'Mobile devices';
  if (/server|workstation|computer|pc\b|laptop|windows|linux|mac|nas|storage|virtual/.test(t)) return 'Computers and servers';
  if (/web device/.test(t)) return 'Network equipment';
  return 'Other';
}
/* ---- linked device: device:"vendor:siemens ip:10.0.0.0/24" keeps the rows that belong to a device matching that asset query ---- */
const DEV_IPF = { alerts: ['src', 'dst'], flows: ['client', 'server'], activities: ['src', 'dst'], assets: ['ip'], vulns: ['ip'] };
function assetRR(sid, r) {
  const rr = Object.assign({}, r, assetSeg(sid, r), { category: assetCategory(r), ips: r.ips && r.ips.length ? r.ips : [r.ip], macs: r.macs && r.macs.length ? r.macs : (r.mac ? [r.mac] : []) });
  rr.search = (r.search || '') + ' ' + (rr.vlan ? 'vlan ' + rr.vlan.replace(/, /g, ' vlan ') : '').toLowerCase() + ' ' + rr.seg_zone.toLowerCase();
  return rr;
}
function deviceSet(t, sid) {                // the devices of one site that match the asset query inside this term (cached on the term for this request)
  t._c = t._c || {};
  if (t._c[sid]) return t._c[sid];
  const inner = parseQ(String(t.val).replace(/'/g, '"')).filter(function (x) { return x.key !== 'device'; });
  const site = DB.sites[sid], nm = site ? site.name + ' ' + tenantName(site.tenant) : '', ids = new Set(), ips = new Set(), A = DB.assets[sid] || {};
  for (const id in A) { const a = A[id]; if (a.gone) continue; if (matches('assets', assetRR(sid, a), inner, nm, sid)) { ids.add(a.id); if (a.ip) ips.add(a.ip); (a.ips || []).forEach(function (x) { ips.add(x); }); } }
  return (t._c[sid] = { ids: ids, ips: ips });
}
function devHit(kind, r, t, sid) {
  const set = deviceSet(t, String(sid));
  if (kind === 'assets') return set.ids.has(r.id);
  if (kind === 'vulns') return set.ids.has(r.asset) || set.ips.has(r.ip);
  return (DEV_IPF[kind] || []).some(function (f) { return set.ips.has(r[f]); });
}
function matches(kind, r, terms, siteName, sid) {
  for (const t of terms) {
    let hit;
    if (t.key === 'device') hit = devHit(kind, r, t, sid);
    else if (t.key === 'site' || t.key === 'org') hit = t.exact ? (' ' + siteName.toLowerCase() + ' ').indexOf(' ' + t.val + ' ') !== -1 : siteName.toLowerCase().indexOf(t.val) !== -1;
    else if (t.key === 'risk' && kind === 'assets') hit = r.risk >= (parseInt(t.val, 10) || 0);
    else if (t.key === 'ot' && (kind === 'assets' || kind === 'activities')) hit = String(r.ot) === (t.val === 'true' || t.val === '1' || t.val === 'yes' ? '1' : '0');
    else if (t.key && FIELDS[kind][t.key]) hit = qHit(t, FIELDS[kind][t.key], r);
    else hit = r.search.indexOf((t.key ? t.key + ':' : '') + t.val) !== -1 || r.search.indexOf(t.val) !== -1 || (!t.key && siteName.toLowerCase().indexOf(t.val) !== -1);
    if (t.neg ? hit : !hit) return false;
  }
  return true;
}
function listRows(kind, p, limit, scope) {
  const terms = parseQ(p.q), out = [];
  const only = p.site ? String(p.site) : '';
  for (const sid in DB[kind]) {
    if (only && sid !== only) continue;
    if (scope && !scope.has(sid)) continue;
    const site = DB.sites[sid];
    if (!site) continue;
    const rows = DB[kind][sid];
    for (const id in rows) {
      const r = rows[id];
      if (kind === 'alerts' && p.status && r.status !== p.status) continue;
      const rr = kind === 'assets' ? Object.assign({}, r, assetSeg(sid, r), { category: assetCategory(r), ips: r.ips && r.ips.length ? r.ips : [r.ip], macs: r.macs && r.macs.length ? r.macs : (r.mac ? [r.mac] : []) }) : r;
      if (kind === 'assets') rr.search = (r.search || '') + ' ' + (rr.vlan ? 'vlan ' + rr.vlan.replace(/, /g, ' vlan ') : '').toLowerCase() + ' ' + rr.seg_zone.toLowerCase();
      if (matches(kind, rr, terms, site.name + ' ' + tenantName(site.tenant), sid)) out.push(Object.assign({}, rr, { site: site.id, site_name: site.name, org_name: tenantName(site.tenant) }));
    }
  }
  const sorter = {
    assets: function (a, b) { return b.risk - a.risk || (b.last_seen > a.last_seen ? 1 : -1); },
    alerts: function (a, b) { return b.sev - a.sev || (b.last_seen > a.last_seen ? 1 : -1); },
    flows: function (a, b) { return b.ot - a.ot || b.packets - a.packets; }
  }[kind];
  out.sort(sorter);
  const total = out.length;
  if (limit) return { total: total, rows: out.slice(0, limit), page: 1 };
  const page = Math.max(1, parseInt(p.page, 10) || 1);
  return { total: total, page: page, size: PAGE_SIZE, rows: out.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE).map(slim(kind)) };
}
function slim(kind) {                      // do not ship the raw asset blob in lists
  return function (r) { if (kind !== 'assets') return r; const c = Object.assign({}, r); delete c.data; delete c.search; delete c.ipseen; delete c.merge_log; delete c.block_keys; delete c.keys; return c; };
}
/* ---- plain-English description of one activity row ---- */
const CAT_LABEL = { stop: 'Stop command', program: 'Program change', control: 'Control command', write: 'Changed a value',
  upload: 'Program copied out', discover: 'Looking for devices', session: 'Connection', read: 'Read data', response: 'Reply', info: 'Other' };
const KEY_WORDS = { dns_queries: 'name asked', tls_sni: 'website', http_hosts: 'web address', http_server: 'web server', user_agents: 'software',
  hostname: 'device name', ssh_banner: 'SSH software', modbus_units: 'Modbus unit', dnp3_address: 'DNP3 address', iec104_asdu: 'IEC-104 station' };
function nice(r, assets) {                       // "Siemens PLC (192.168.10.11)" when central knows the device
  const ip = r;
  const a = assets && assetByIp(assets, ip);
  if (!a) return /^broadcast$|^multicast$/.test(ip) ? 'everyone on the network' : ip;
  const w = [a.vendor, a.device_type].filter(Boolean).join(' ');
  const hn = (a.hostnames || [])[0];
  return (hn || w || 'device') + ' (' + ip + ')';
}
function prettyDetail(d) {
  return String(d || '').split('; ').filter(Boolean).map(function (x) {
    const i = x.indexOf('='); if (i < 0) return x;
    const k = x.slice(0, i), v = x.slice(i + 1);
    return (KEY_WORDS[k] || k.replace(/_/g, ' ')) + ': ' + v;
  }).join(', ');
}
function plainText(r, assets) {
  const src = nice(r.src, assets), dst = nice(r.dst, assets), cap = src.charAt(0).toUpperCase() + src.slice(1);
  const proto = r.proto, f = r.func || '', fl = f.toLowerCase();
  const port = r.port ? ' (port ' + r.port + ')' : '';
  const toAll = /^(broadcast|multicast)$/.test(r.dst);
  let t;
  if (proto === 'ARP') {
    t = fl.indexOf('request') !== -1 ? cap + ' asked the network "who has this address?" (' + (r.detail || '') + ').'
      : cap + ' announced its own hardware address (' + (r.detail || '') + ').';
  } else if (proto === 'ICMP') {
    t = fl.indexOf('echo request') !== -1 ? cap + ' pinged ' + dst + ' to check if it is alive.'
      : fl.indexOf('echo reply') !== -1 ? cap + ' answered a ping from ' + dst + '.'
      : cap + ' sent a network control message ("' + f + '") to ' + dst + '.';
  } else if (/^Connection attempt/.test(f)) {
    t = cap + ' tried to connect to ' + dst + ' on port ' + r.port + ' (' + proto + '). It only knocked; no data was sent yet.';
  } else if (f === 'new connection') {
    t = cap + ' opened a connection to ' + dst + port + ' for ' + proto + '.';
  } else if (f === 'data') {
    t = cap + ' sent ' + proto + ' data to ' + dst + port + '.';
  } else if (proto === 'DNS' || proto === 'mDNS') {
    t = fl === 'query' ? cap + ' asked ' + (proto === 'DNS' ? 'the name server' : 'the local network') + ' to look up a name.' : cap + ' replied to a name lookup from ' + dst + '.';
  } else if (r.cat === 'stop') t = cap + ' sent a STOP command ("' + f + '") to ' + dst + ' using ' + proto + '. This can halt the machine or process it controls.';
  else if (r.cat === 'program') t = cap + ' started a program or firmware download ("' + f + '") to ' + dst + ' using ' + proto + '. This changes what the controller does.';
  else if (r.cat === 'control') t = cap + ' sent a control command ("' + f + '", such as a restart) to ' + dst + ' using ' + proto + '.';
  else if (r.cat === 'write') t = cap + ' changed a value on ' + dst + ' using ' + proto + ' ("' + f + '").';
  else if (r.cat === 'upload') t = cap + ' copied the program out of ' + dst + ' using ' + proto + ' ("' + f + '").';
  else if (r.cat === 'discover') t = cap + ' is looking for devices' + (toAll ? ' on the network' : ' (asking ' + dst + ' who it is)') + ' using ' + proto + ' ("' + f + '").';
  else if (r.cat === 'read') t = cap + ' read data from ' + dst + ' using ' + proto + ' ("' + f + '").';
  else if (r.cat === 'response') t = cap + ' replied to ' + dst + ' (' + proto + (f ? ', ' + f : '') + ').';
  else t = cap + ' sent ' + proto + (f ? ' "' + f + '"' : ' traffic') + ' to ' + dst + port + '.';
  const dt = prettyDetail(r.detail);
  if (dt && proto !== 'ARP') t += ' Details: ' + dt + '.';
  if (r.pkts > 1) t += ' This happened ' + r.pkts.toLocaleString() + ' times' + (r.first && r.first !== r.last ? ' between ' + r.first.slice(11) + ' and ' + r.last.slice(11) + ' UTC' : '') + '.';
  return t;
}

function listActivities(p, limit, scope) {
  const terms = parseQ(p.q), only = p.site ? String(p.site) : '';
  const since = parseInt(p.since, 10) > 0 ? Date.now() / 1000 - parseInt(p.since, 10) : 0;
  const base = [];
  for (const sid in ACT) {
    if (only && sid !== only) continue;
    if (scope && !scope.has(sid)) continue;
    const site = DB.sites[sid];
    if (!site) continue;
    ACT[sid].forEach(function (r) {
      if (since && (r.rx || r.t) < since) return;
      if (p.ot === '1' && !r.ot) return;
      const v = Object.assign({}, r, { site: site.id, site_name: site.name, org_name: tenantName(site.tenant), ips: r.src + ' ' + r.dst, macs: r.src_mac + ' ' + r.dst_mac });
      v.search = [r.src, r.dst, r.src_mac, r.dst_mac, r.proto, r.l4, r.port, r.func, r.cat, r.detail, r.sensor, site.name].join(' ').toLowerCase();
      if (matches('activities', v, terms, site.name, sid)) base.push(v);
    });
  }
  const facet = function (f) { return countBy(base, f).slice(0, 12); };
  const facets = { cat: facet(function (r) { return r.cat; }).map(function (x) { return { k: x.k, label: CAT_LABEL[x.k] || x.k, n: x.n }; }), proto: facet(function (r) { return r.proto; }) };
  const rows = p.cat ? base.filter(function (r) { return r.cat === p.cat; }) : base;
  rows.sort(function (a, b) { return b.t - a.t || (b.pkts - a.pkts); });
  const clean = function (r) { const c = Object.assign({}, r); c.text = plainText(r, DB.assets[String(r.site)]); c.cat_label = CAT_LABEL[r.cat] || r.cat; delete c.search; delete c.ips; delete c.macs; delete c.sid; delete c.rx; return c; };
  if (limit) return { total: rows.length, rows: rows.slice(0, limit).map(clean) };
  const page = Math.max(1, parseInt(p.page, 10) || 1);
  return { total: rows.length, page: page, size: ACT_PAGE, facets: facets, rows: rows.slice((page - 1) * ACT_PAGE, page * ACT_PAGE).map(clean) };
}
/* ---- values for the guided search builder: the distinct values of one field, with counts, inside the caller's scope ---- */
const SV_ASSET = { vendor: 'vendor', type: 'device_type', proto: 'protocols', os: 'os', model: 'model', zone: 'zone', segment: 'seg_zone', vlan: 'vlan', category: 'category', ip: 'ip', mac: 'macs' };
const SV_ALERT = { kind: 'kind', sev: 'severity', status: 'status', mitre: 'mitre', proto: 'proto', src: 'src', dst: 'dst' };
const SV_FLOW = { proto: 'proto', port: 'port', func: 'funcs', client: 'client', server: 'server' };
const SV_ACT = { src: 'src', dst: 'dst', proto: 'proto', port: 'port', func: 'func', cat: 'cat', sensor: 'sensor', l4: 'l4', ip: 'ips', mac: 'macs' };
function searchValues(kind, field, p, scope) {
  const only = p.site ? String(p.site) : '', cnt = {}, lab = {};
  const add = function (v) { if (v == null) return; v = String(v).trim(); if (v) cnt[v] = (cnt[v] || 0) + 1; };
  const addAll = function (v) { if (Array.isArray(v)) v.forEach(add); else if (v && typeof v === 'object') Object.keys(v).forEach(add); else add(v); };
  if (kind === 'vulns') {
    vulnAll(scope, only).forEach(function (f) {
      if (field === 'sev') add(f.severity); else if (field === 'status') add(f.status); else if (field === 'cat') { add(f.cat); lab[f.cat] = f.cat_label; }
      else if (field === 'conf') add(f.confidence); else if (field === 'owner') add(f.owner); else if (field === 'vendor') add(f.vendor); else if (field === 'type') add(f.device_type);
      else if (field === 'os') add(f.os); else if (field === 'site') add(f.site_name); else if (field === 'ip') add(f.ip); else if (field === 'cve') (f.cve || []).forEach(add);
    });
  } else {
    const map = { assets: SV_ASSET, alerts: SV_ALERT, flows: SV_FLOW, activities: SV_ACT }[kind] || {};
    for (const sid in (kind === 'activities' ? ACT : DB[kind] || {})) {
      if (only && sid !== only) continue;
      if (scope && !scope.has(sid)) continue;
      const site = DB.sites[sid]; if (!site) continue;
      if (field === 'site') { add(site.name); continue; }
      const f = map[field]; if (!f) continue;
      if (kind === 'activities') { ACT[sid].forEach(function (r) { if (f === 'ips') { add(r.src); add(r.dst); } else if (f === 'macs') { add(r.src_mac); add(r.dst_mac); } else add(r[f]); }); continue; }
      const rows = DB[kind][sid];
      for (const id in rows) {
        const r = rows[id];
        if (kind === 'assets') { if (r.gone) continue; const x = Object.assign({}, r, assetSeg(sid, r), { category: assetCategory(r) }); if (f === 'vlan') String(x.vlan || '').split(/,\s*/).forEach(add); else if (f === 'macs') addAll(r.macs && r.macs.length ? r.macs : r.mac); else addAll(x[f]); }
        else addAll(r[f]);
      }
    }
  }
  if (field === 'cat' && kind === 'activities') Object.keys(cnt).forEach(function (k) { lab[k] = CAT_LABEL[k] || k; });
  const num = field === 'port' || field === 'vlan';
  const list = Object.keys(cnt).sort(function (a, b) { return num ? (+a - +b) : (cnt[b] - cnt[a] || a.localeCompare(b)); }).slice(0, 400)
    .map(function (v) { return { v: v, l: lab[v] || v, n: cnt[v] }; });
  return { kind: kind, field: field, values: list, more: Object.keys(cnt).length > list.length };
}
/* ---- "what is linked to this device": counts of everything that belongs to the devices matching an asset query ---- */
function searchRelated(p, scope) {
  const dq = 'device:"' + String(p.q || '').replace(/"/g, "'") + '"', base = { q: dq, site: p.site || '' };
  const tally = function (rows, f) { const o = {}; rows.forEach(function (r) { const k = r[f] || 'other'; o[k] = (o[k] || 0) + 1; }); return o; };
  const al = listRows('alerts', base, 100000, scope).rows, vu = vulnList(scope, { q: dq, site: p.site || '', status: 'active', limit: 100000 }).rows;
  return {
    assets: listRows('assets', base, 1, scope).total,
    vulns: { total: vu.length, by: tally(vu, 'severity') },
    alerts: { total: al.length, by: tally(al, 'severity') },
    activities: listActivities({ q: dq, site: p.site || '', since: '' }, 1, scope).total,
    flows: listRows('flows', base, 1, scope).total
  };
}
function siteStatus(s, now) {
  if (!s.last_seen) return 'never';
  return now - s.last_seen <= Math.max(3 * (s.interval || 30), 90) ? 'online' : 'offline';
}
function sitesList(scope) {
  const now = Date.now() / 1000;
  return Object.keys(DB.sites).filter(function (id) { return !scope || scope.has(String(id)); }).map(function (id) { return DB.sites[id]; })
    .sort(function (a, b) { return a.name.localeCompare(b.name); })
    .map(function (s) {
      const sid = String(s.id), A = Object.values(DB.assets[sid] || {}), L = Object.values(DB.alerts[sid] || {});
      const nw = L.filter(function (x) { return x.status === 'new'; });
      return { id: s.id, name: s.name, tenant: s.tenant || null, tenant_name: tenantName(s.tenant), created: s.created, last_seen: s.last_seen || null, interval: s.interval, meta: s.meta || {}, build: s.build || null, sensors2: (s.sensors2 || []).map(function (x) { return { id: x.id, label: x.label, last_seen: x.last_seen || 0, build: x.build || null, host: (x.meta || {}).hostname || '', pending: x.pending ? { files: x.pending.files } : null }; }), pending: s.pending ? { files: s.pending.files, at: s.pending.at } : null, scan_mode: s.scan_mode || '',
        status: siteStatus(s, now), age: s.last_seen ? Math.floor(now - s.last_seen) : null,
        assets: A.length, ot_assets: A.filter(function (x) { return x.ot; }).length,
        flows: Object.keys(DB.flows[sid] || {}).length, activities: (ACT[sid] || []).length,
        last_activity: (ACT[sid] || []).length ? ACT[sid][ACT[sid].length - 1].t : null, new_alerts: nw.length,
        critical: nw.filter(function (x) { return x.sev === 4; }).length, high: nw.filter(function (x) { return x.sev === 3; }).length };
    });
}
function countBy(arr, f) {
  const m = {};
  arr.forEach(function (x) { const k = f(x) || 'Unknown'; m[k] = (m[k] || 0) + 1; });
  return Object.keys(m).map(function (k) { return { k: k, n: m[k] }; }).sort(function (a, b) { return b.n - a.n; });
}
function overview(p, scope) {
  const sites = sitesList(scope), only = p.site ? String(p.site) : '';
  const sel = sites.filter(function (s) { return !only || String(s.id) === only; });
  const assets = [], alerts = [];
  sel.forEach(function (s) {
    Object.values(DB.assets[String(s.id)] || {}).forEach(function (a) { assets.push(a); });
    Object.values(DB.alerts[String(s.id)] || {}).forEach(function (a) { if (a.status === 'new') alerts.push(a); });
  });
  const sum = function (k) { return sel.reduce(function (t, s) { return t + s[k]; }, 0); };
  const protoCount = {};
  assets.forEach(function (a) { a.protocols.forEach(function (x) { protoCount[x] = (protoCount[x] || 0) + 1; }); });
  const sevs = {};
  alerts.forEach(function (a) { sevs[a.severity] = (sevs[a.severity] || 0) + 1; });
  return { sites: sites,
    totals: { sites: sel.length, online: sel.filter(function (s) { return s.status === 'online'; }).length, assets: sum('assets'),
      ot_assets: sum('ot_assets'), flows: sum('flows'), activities: sum('activities'), new_alerts: sum('new_alerts'), critical: sum('critical'), high: sum('high') },
    device_types: countBy(assets, function (a) { return a.device_type; }).slice(0, 10),
    protocols: Object.keys(protoCount).map(function (k) { return { k: k, n: protoCount[k] }; }).sort(function (a, b) { return b.n - a.n; }).slice(0, 12),
    alert_severity: sevs,
    recent_alerts: listRows('alerts', { site: only, status: 'new' }, 8, scope).rows,
    recent_activity: listActivities({ site: only, ot: '1' }, 8, scope).rows,
    risky_assets: listRows('assets', { site: only, q: 'risk:1' }, 8, scope).rows.map(slim('assets')),
    vulns: vulnTotals(scope, only) };
}
function assetDetail(site, id, nAct, scope) {
  const sid = String(site), a = devGet(sid, id);
  if (!a || (scope && !scope.has(sid))) return null;
  const keys = uniq([a.id, a.ip].concat(a.ips || [], a.keys || [])).filter(Boolean);
  const peers = Object.values(DB.flows[sid] || {}).filter(function (f) { return keys.indexOf(f.client) !== -1 || keys.indexOf(f.server) !== -1; })
    .sort(function (x, y) { return y.packets - x.packets; }).slice(0, 60).map(function (f) { return flowSeg(sid, f); });
  const alerts = Object.values(DB.alerts[sid] || {}).filter(function (x) { return keys.indexOf(x.src) !== -1 || keys.indexOf(x.dst) !== -1; })
    .sort(function (x, y) { return y.sev - x.sev; }).slice(0, 40);
  const same = [];
  const myMacs = (a.macs && a.macs.length ? a.macs : (a.mac ? [normMac(a.mac)] : [])).filter(Boolean);
  if (myMacs.length) for (const o in DB.assets) if (o !== sid && (!scope || scope.has(o))) for (const k in DB.assets[o]) {
    const b = DB.assets[o][k], bm = (b.macs && b.macs.length ? b.macs : (b.mac ? [normMac(b.mac)] : []));
    if (bm.some(function (m) { return myMacs.indexOf(m) !== -1; }) && DB.sites[o]) same.push({ site: DB.sites[o].name, ip: b.ip });
  }
  const acts = (ACT[sid] || []).filter(function (r) { return keys.indexOf(r.src) !== -1 || keys.indexOf(r.dst) !== -1; }).slice(-50).reverse()
    .map(function (r) { const c = Object.assign({}, r); c.text = plainText(r, DB.assets[sid]); delete c.sid; delete c.rx; return c; });
  const st = DB.sites[sid] || {}, mt = st.meta || {};
  const siteInfo = { id: st.id, name: st.name || '', last_seen: st.last_seen || 0, sensor: S(mt.hostname, 60), version: S(mt.version, 20), iface: S(mt.iface, 80), scan_mode: S(mt.scan_mode, 12),
    source: S(mt.source, 80), sensors: Object.keys(Object.values(DB.assets[sid] || {}).reduce(function (o, x) { Object.keys(x.seen_by || {}).forEach(function (k) { o[k] = 1; }); return o; }, {})) };
  return { asset: a.data, summary: Object.assign(slim("assets")(a), assetSeg(sid, a)), site: siteInfo, seen_by: Object.values(a.seen_by || {}), peers: peers, alerts: alerts, activities: acts, same_mac: same.slice(0, 20), vulns: vulnOfOneAsset(sid, id),
    identity: { id: a.id, label: a.label || '', keys: a.keys || [], macs: a.macs || [], ips: a.ips && a.ips.length ? a.ips : [a.ip].filter(Boolean), ipseen: a.ipseen || {}, merge_log: a.merge_log || [] } };
}
/* Purdue level of a device: a best guess from what the scan knows (it cannot see cables or switch ports).
   4 enterprise / IT, 3.5 gateway + DMZ, 3 site operations, 2 supervisory (HMI / SCADA), 1 control (PLC / RTU), 0 field / IoT, U not classified yet. */
function purdue(a, hasOt) {
  const t = String(a.device_type || '').toLowerCase(), hn = String(a.hn || '').toLowerCase();
  if (a.ot || (a.protocols && a.protocols.length) || /plc|rtu|controller/.test(t)) return '1';
  if (/hmi|scada|historian|engineering/.test(t)) return '2';
  if (/camera|video|iot|sensor/.test(t) || /^(esp|tuya|lwip)/.test(hn)) return '0';
  if (/windows|server/.test(t)) return hasOt ? '3' : '4';
  if (/router|gateway|firewall|printer|chromecast|cast|computer|phone|web device|linux|network device|tv/.test(t)) return '4';
  return 'U';
}
function topo(site) {
  const sid = String(site);
  const assets = Object.values(DB.assets[sid] || {}).sort(function (a, b) { return b.risk - a.risk; }).slice(0, 400)
    .map(function (a) { return { id: a.id, ip: a.ip, device_type: a.device_type, ot: a.ot, risk: a.risk, hn: (a.hostnames || [])[0] || '', ports: (a.data && a.data.listening_ports) || [], vlans: ((a.data && a.data.vlans) || []).map(function (x) { return parseInt(x, 10); }).filter(function (x) { return x >= 0; }), vlan: assetSeg(sid, a).vlan, vlan_src: assetSeg(sid, a).vlan_src, seg_zone: assetSeg(sid, a).seg_zone, protocols: a.protocols || [], gone: !!a.gone,
      mac: (a.data && a.data.mac) || a.mac || '', vendor: (a.data && (a.data.vendor || a.data.mac_vendor)) || a.vendor || '', model: (a.data && a.data.model) || a.model || '', os: (a.data && a.data.os_guess) || a.os || '' }; });
  const hasOt = assets.some(function (a) { return a.ot; });
  let hub = '';
  assets.forEach(function (a) { if (!hub && /\.1$/.test(a.ip || '')) hub = a.id; });
  assets.forEach(function (a) { if (!hub && /router|gateway|firewall/i.test(a.device_type || '')) hub = a.id; });
  assets.forEach(function (a) { a.level = a.id === hub ? '3.5' : purdue(a, hasOt); });
  const flows = Object.values(DB.flows[sid] || {}).sort(function (a, b) { return b.ot - a.ot || b.packets - a.packets; }).slice(0, 1500)
    .map(function (f) { const sg = flowSeg(sid, f); return { c_vlan: sg.c_vlan, s_vlan: sg.s_vlan, c_zone: sg.c_zone, s_zone: sg.s_zone, client: f.client, server: f.server, ot: f.ot, packets: f.packets, bytes: f.bytes || 0, proto: f.proto || '', l4: f.l4 || '', port: f.port || '',
      first_seen: f.first_seen || '', last_seen: f.last_seen || '', funcs: Object.keys(f.funcs || {}).slice(0, 12) }; });
  const sens = {}, st0 = DB.sites[sid] || {};
  if (st0.meta && st0.meta.hostname) sens[S(st0.meta.hostname, 60)] = 1;
  Object.values(DB.assets[sid] || {}).forEach(function (x) { Object.values(x.seen_by || {}).forEach(function (v) { if (v && v.sensor) sens[S(v.sensor, 60)] = 1; }); });
  return { assets: assets, flows: flows, hub: hub, sensors: Object.keys(sens) };
}
function csvEscape(v) { v = String(v == null ? '' : v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
/* ------------------------------------------------------------------ */
/* Vulnerabilities: every device, its findings, a standard resolution  */
/* ------------------------------------------------------------------ */
/* Central builds the findings from what the sensors already report for each device (open ports, protocols served, OS, firmware,
   service banners, vendor / model).  Nothing is scanned from here and nothing extra is stored per finding except the status a
   person sets (open / in progress / accepted / resolved / false positive).  Every finding says HOW SURE central is:
     confirmed = seen directly (an open port, a banner with a version)
     likely    = follows from what was seen (old OS + open service)
     possible  = the product is known to be affected in some versions; check the version on the device                      */
const VSTATUS = ['open', 'in_progress', 'accepted', 'resolved', 'false_positive'];
const VSTATUS_LABEL = { open: 'Open', in_progress: 'In progress', accepted: 'Risk accepted', resolved: 'Resolved', false_positive: 'False positive' };
const VCAT_LABEL = { exposure: 'Exposed service', eol: 'Unsupported / end of life', software: 'Vulnerable software', ot: 'OT / ICS security', config: 'Weak configuration', hygiene: 'Inventory gaps' };
const VWEIGHT = { critical: 10, high: 5, medium: 2, low: 1, info: 0 };
const VSEV_NAME = ['info', 'low', 'medium', 'high', 'critical'];
const VOPEN = function (s) { return s === 'open' || s === 'in_progress'; };
const VRULES = [];
function vr(id, sev, cvss, cat, title, desc, fix, test, o) {
  /* kev: in CISA's Known Exploited Vulnerabilities catalog as of this build (a static snapshot, not a live feed - see VKEV_ASOF below).
     maturity: 'weaponized' (a ready-to-run public exploit / Metasploit module exists), 'poc' (a proof of concept exists but needs work), 'none'. */
  VRULES.push(Object.assign({ id: id, severity: sev, cvss: cvss, cat: cat, title: title, desc: desc, fix: fix, test: test, cve: [], conf: 'confirmed', kev: false, maturity: 'none' }, o || {}));
}
const VKEV_ASOF = '2026-10';     // when this file's kev:true flags were last checked against CISA's catalog
const VMAT_LABEL = { weaponized: 'Exploit code is publicly available', poc: 'A proof of concept exists', none: 'No public exploit known' };
function vver(s) { return String(s || '').split(/[^0-9]+/).filter(Boolean).map(function (x) { return parseInt(x, 10); }); }
function vlt(a, b) { for (let i = 0; i < Math.max(a.length, b.length); i++) { const x = a[i] || 0, y = b[i] || 0; if (x !== y) return x < y; } return false; }
function vhasPort(c, list) { const hit = list.filter(function (p) { return c.ports.has(p); }); return hit.length ? hit : null; }
function vserves(c, rx) { return c.serves.some(function (x) { return rx.test(x); }) || c.protos.some(function (x) { return rx.test(x); }); }

/* ---- exposed services ---- */
vr('VULN-TELNET', 'high', 8.1, 'exposure', 'Telnet is enabled (clear-text remote login)',
  'Telnet sends the user name, password and every command in clear text. Anyone on the same network path can read or change them, and many devices ship with a default Telnet password.',
  ['Disable the Telnet service on the device (or block TCP/23 on the switch or firewall in front of it).', 'Use SSH, or the HTTPS console, for remote administration instead.', 'Change every password that was ever used over Telnet on this device.', 'If the device cannot work without Telnet, restrict TCP/23 to one management host and log all sessions.'],
  function (c) { return vhasPort(c, [23]) ? 'TCP/23 is open' + (c.telnet ? ' (banner: ' + c.telnet.slice(0, 60) + ')' : '') : (c.telnet ? 'Telnet banner seen: ' + c.telnet.slice(0, 60) : null); });
vr('VULN-RSH', 'high', 8.8, 'exposure', 'Remote shell services (rsh / rlogin / rexec) are enabled',
  'The r-services trust the client address instead of a password and send everything in clear text. They are trivial to abuse.',
  ['Stop and disable rshd, rlogind and rexecd (TCP 512, 513, 514).', 'Remove /etc/hosts.equiv and every .rhosts file.', 'Use SSH with keys instead.'],
  function (c) { const h = vhasPort(c, [512, 513]); return h ? 'TCP/' + h.join(', ') + ' open' : null; });
vr('VULN-FTP', 'medium', 5.9, 'exposure', 'FTP is enabled (clear-text file transfer)',
  'FTP sends the login and the files in clear text and is often left with anonymous or default accounts.',
  ['Turn FTP off if it is not needed, or block TCP/21 at the firewall.', 'Use SFTP (over SSH) or FTPS instead.', 'If FTP must stay, disable anonymous login and use a unique password.'],
  function (c) { return vhasPort(c, [21]) ? 'TCP/21 is open' + (c.ftp ? ' (banner: ' + c.ftp.slice(0, 60) + ')' : '') : null; });
vr('VULN-SMB', 'medium', 5.3, 'exposure', 'SMB file sharing is reachable',
  'SMB is the service used by most Windows worms. It should only be reachable from the machines that really need it.',
  ['Block TCP/445 between user networks and between sites.', 'Make sure SMBv1 is disabled (Windows: Turn Windows features on or off > SMB 1.0).', 'Keep the system fully patched and require SMB signing.'],
  function (c) { return vhasPort(c, [445]) ? 'TCP/445 is open' : null; });
vr('VULN-MS17-010', 'critical', 8.1, 'software', 'Old Windows with SMB open: EternalBlue family (MS17-010)',
  'Unpatched Windows 7 / 2008 / XP / 2003 systems with SMB reachable can be taken over remotely without a password (WannaCry and NotPetya used this).',
  ['Install the MS17-010 update, or better replace the unsupported Windows version.', 'Disable SMBv1.', 'Until fixed, block TCP/445 to and from this device.'],
  function (c) { return vhasPort(c, [445]) && /windows (xp|2000|2003|vista|7\b|server 2008|2008)/.test(c.os) ? 'OS reported as "' + c.osRaw + '" and TCP/445 is open' : null; },
  { cve: ['CVE-2017-0143', 'CVE-2017-0144', 'CVE-2017-0145', 'CVE-2017-0148'], conf: 'likely', kev: true, maturity: 'weaponized' });
vr('VULN-RDP', 'medium', 6.5, 'exposure', 'Remote Desktop (RDP) is reachable',
  'RDP is a favourite way in for ransomware. It should not be reachable from user networks or the internet.',
  ['Allow RDP only from a jump host or VPN (block TCP/3389 elsewhere).', 'Turn on Network Level Authentication and account lockout, and use multi-factor sign-in.', 'Keep Windows patched.'],
  function (c) { return vhasPort(c, [3389]) ? 'TCP/3389 is open' : null; });
vr('VULN-BLUEKEEP', 'critical', 9.8, 'software', 'Old Windows with RDP open: BlueKeep (CVE-2019-0708)',
  'Windows 7 / 2008 / XP / 2003 with RDP reachable can be taken over remotely without logging in.',
  ['Install the May 2019 security update (or replace the unsupported Windows version).', 'Enable Network Level Authentication.', 'Block TCP/3389 to this device until it is fixed.'],
  function (c) { return vhasPort(c, [3389]) && /windows (xp|2003|vista|7\b|server 2008|2008)/.test(c.os) ? 'OS reported as "' + c.osRaw + '" and TCP/3389 is open' : null; },
  { cve: ['CVE-2019-0708'], conf: 'likely', kev: true, maturity: 'weaponized' });
vr('VULN-VNC', 'high', 8.8, 'exposure', 'VNC remote control is reachable',
  'VNC is frequently installed with a weak or empty password and little protection against guessing.',
  ['Block TCP/5900-5903 except from one management host.', 'Set a long password, or replace VNC with a remote tool that has multi-factor sign-in.', 'Tunnel VNC through SSH or a VPN.'],
  function (c) { const h = vhasPort(c, [5900, 5901, 5902, 5903]); return h ? 'TCP/' + h.join(', ') + ' open' : null; });
vr('VULN-SNMP', 'medium', 5.3, 'config', 'SNMP v1/v2c in use (community-string security)',
  'The device answers SNMP. Versions 1 and 2c use a shared "community" word as password, often left as public / private, and send it in clear text.',
  ['Move to SNMPv3 with authentication and encryption.', 'If v2c must stay, change the community strings and allow only the monitoring server.', 'Set the community to read-only wherever possible.'],
  function (c) { return c.snmp ? 'SNMP answered: ' + c.snmp.slice(0, 80) : null; }, { conf: 'possible' });
vr('VULN-MQTT', 'low', 4.3, 'config', 'MQTT broker without TLS is reachable',
  'MQTT on TCP/1883 carries messages (and often passwords) in clear text and many brokers allow anonymous clients.',
  ['Use MQTT over TLS (TCP/8883) and require a user name and password or client certificates.', 'Turn anonymous access off.'],
  function (c) { return vhasPort(c, [1883]) ? 'TCP/1883 is open' : null; });
vr('VULN-DB-OPEN', 'high', 7.5, 'exposure', 'Database or cache service reachable on the network',
  'Redis, MongoDB, Elasticsearch, Memcached and CouchDB are often installed with no password and have been mass-exploited for data theft and ransom.',
  ['Bind the service to 127.0.0.1 or to the application server only.', 'Require authentication and, where available, TLS.', 'Block the port on the firewall for everyone else.'],
  function (c) { const h = vhasPort(c, [6379, 27017, 9200, 11211, 5984]); return h ? 'TCP/' + h.join(', ') + ' open' : null; });
vr('VULN-DOCKER', 'critical', 9.8, 'exposure', 'Docker API is open without TLS',
  'TCP/2375 is the unauthenticated Docker control port. Anyone who can reach it controls the host.',
  ['Stop listening on TCP/2375 (remove the -H tcp:// option) or protect the API with TLS client certificates (TCP/2376).', 'Block the port on the firewall.'],
  function (c) { return vhasPort(c, [2375]) ? 'TCP/2375 is open' : null; });
vr('VULN-SMARTINSTALL', 'critical', 9.8, 'exposure', 'Cisco Smart Install is enabled (CVE-2018-0171)',
  'Cisco Smart Install on TCP/4786 lets an attacker run commands or replace the configuration of a switch without a password on unpatched IOS.',
  ['Disable it: "no vstack" in the global configuration.', 'Update IOS to a fixed release.', 'Block TCP/4786 from everything except the installation server.'],
  function (c) { return vhasPort(c, [4786]) ? 'TCP/4786 is open' : null; }, { cve: ['CVE-2018-0171'], conf: 'likely', kev: true, maturity: 'weaponized' });
vr('VULN-WINBOX', 'high', 9.1, 'software', 'MikroTik Winbox is reachable (old RouterOS: CVE-2018-14847)',
  'RouterOS before 6.42 lets an attacker read the user database through the Winbox port without logging in.',
  ['Upgrade RouterOS to the current long-term version.', 'Allow Winbox (TCP/8291) only from the management network.', 'Change all router passwords after upgrading.'],
  function (c) { return vhasPort(c, [8291]) && /mikrotik|routerboard/.test(c.vendor + ' ' + c.model) ? 'Winbox TCP/8291 is open on a MikroTik device' : null; }, { cve: ['CVE-2018-14847'], conf: 'possible', kev: true, maturity: 'weaponized' });
vr('VULN-IPMI', 'high', 7.5, 'exposure', 'IPMI management interface is reachable',
  'IPMI 2.0 (port 623) hands out password hashes to anyone who asks (CVE-2013-4786), and its controller firmware is rarely patched.',
  ['Place the BMC / iLO / iDRAC on an isolated management network.', 'Disable IPMI-over-LAN if it is not used, set long passwords, and update the BMC firmware.'],
  function (c) { return vhasPort(c, [623]) ? 'Port 623 is open' : null; }, { cve: ['CVE-2013-4786'], conf: 'likely', maturity: 'weaponized' });
vr('VULN-NFS', 'medium', 5.3, 'exposure', 'NFS / RPC portmapper is reachable',
  'NFS shares are often exported to everyone and rpcbind can be used to map and attack other services.',
  ['Restrict exports to named hosts and use root_squash.', 'Block TCP/111 and TCP/2049 from untrusted networks.'],
  function (c) { const h = vhasPort(c, [111, 2049]); return h ? 'TCP/' + h.join(', ') + ' open' : null; });
vr('VULN-UPNP', 'low', 4.3, 'config', 'UPnP / SSDP is active',
  'UPnP lets software on the network open ports and change settings without a password.',
  ['Disable UPnP on routers and devices that do not need it.', 'Block UDP/1900 between networks.'],
  function (c) { return c.ssdp ? 'SSDP answered: ' + c.ssdp.slice(0, 80) : null; });
vr('VULN-HTTP-CLEAR', 'low', 3.7, 'config', 'Web interface offered without HTTPS',
  'The device has a web page on port 80 and no HTTPS. Passwords and settings travel in clear text.',
  ['Turn on HTTPS in the device settings (install a certificate if the device allows) and redirect HTTP to it.', 'If HTTPS is not available, reach the device only through a management VLAN or VPN.'],
  function (c) { return vhasPort(c, [80, 8080]) && !vhasPort(c, [443, 8443]) ? 'HTTP is open and there is no HTTPS port' : null; });
vr('VULN-RTSP', 'low', 4.3, 'config', 'Camera video stream (RTSP) reachable',
  'RTSP streams are frequently left without a password, so anyone on the network can watch the camera.',
  ['Require a user name and password for the RTSP stream.', 'Put cameras in their own VLAN and allow only the recorder to reach them.'],
  function (c) { return vhasPort(c, [554]) ? 'TCP/554 is open' : null; }, { conf: 'possible' });

/* ---- software versions seen in banners ---- */
vr('VULN-OPENSSH-REGRESSHION', 'high', 8.1, 'software', 'OpenSSH regreSSHion (CVE-2024-6387)',
  'OpenSSH 8.5 to 9.7 on Linux (glibc) can be attacked by an unauthenticated remote attacker. Linux vendors often back-port the fix without changing the version number.',
  ['Update OpenSSH to 9.8 or later, or install your Linux vendor\'s security update for CVE-2024-6387.', 'Workaround: set LoginGraceTime 0 in sshd_config and restart sshd.', 'Limit SSH to the management network.'],
  function (c) { const m = /openssh[_-](\d+)\.(\d+)/i.exec(c.ssh); if (!m) return null; const v = [+m[1], +m[2]]; return !vlt(v, [8, 5]) && vlt(v, [9, 8]) ? 'SSH banner: ' + c.ssh.slice(0, 70) : null; },
  { cve: ['CVE-2024-6387'], conf: 'likely', maturity: 'poc' });
vr('VULN-OPENSSH-OLD', 'medium', 5.9, 'software', 'Outdated OpenSSH (older than 8.0)',
  'These versions contain several known flaws (user-name guessing CVE-2018-15473, scp file overwrite CVE-2019-6111) and no longer receive fixes.',
  ['Update the device or the operating system to a release with OpenSSH 9.8 or later.', 'If it is an appliance, install the newest vendor firmware.'],
  function (c) { const m = /openssh[_-](\d+)\.(\d+)/i.exec(c.ssh); return m && vlt([+m[1], +m[2]], [8, 0]) ? 'SSH banner: ' + c.ssh.slice(0, 70) : null; },
  { cve: ['CVE-2018-15473', 'CVE-2019-6111'] });
vr('VULN-APACHE-PATH', 'critical', 9.8, 'software', 'Apache httpd 2.4.49 / 2.4.50 path traversal and code execution',
  'These two exact versions let a remote attacker read files, and run commands if CGI is on, without logging in.',
  ['Upgrade Apache httpd to 2.4.51 or later (current stable is best).', 'Make sure "require all denied" is set for directories outside the web root.'],
  function (c) { const m = /apache\/2\.4\.(\d+)/i.exec(c.http); return m && (m[1] === '49' || m[1] === '50') ? 'Web server banner: ' + c.http.slice(0, 70) : null; },
  { cve: ['CVE-2021-41773', 'CVE-2021-42013'], kev: true, maturity: 'weaponized' });
vr('VULN-APACHE-EOL', 'high', 7.5, 'eol', 'Apache httpd 2.2 or older (unsupported)',
  'Apache 2.2 stopped receiving fixes in 2018, so new flaws are never patched.',
  ['Upgrade to Apache httpd 2.4 (current release).', 'If it is an appliance, ask the vendor for newer firmware or replace it.'],
  function (c) { return /apache\/(1\.|2\.[0-2]\.)/i.test(c.http) ? 'Web server banner: ' + c.http.slice(0, 70) : null; });
vr('VULN-IIS6', 'critical', 9.8, 'software', 'Microsoft IIS 6.0 (CVE-2017-7269 and others)',
  'IIS 6.0 belongs to Windows Server 2003, unsupported since 2015, and has a remote code-execution flaw that is used in the wild.',
  ['Migrate the site to a supported Windows Server and IIS version.', 'Until then take the server off the network or put it behind a reverse proxy / firewall.'],
  function (c) { return /microsoft-iis\/6\./i.test(c.http) ? 'Web server banner: ' + c.http.slice(0, 70) : null; }, { cve: ['CVE-2017-7269'], kev: true, maturity: 'weaponized' });
vr('VULN-IIS-EOL', 'high', 7.5, 'eol', 'Microsoft IIS from an unsupported Windows Server',
  'IIS 7.x and 8.x run on Windows Server 2008 to 2012 R2, which no longer receive free security updates.',
  ['Move the application to a supported Windows Server (2019 or later).', 'If migration takes time, isolate the server and buy extended security updates.'],
  function (c) { const m = /microsoft-iis\/(\d+)\./i.exec(c.http); return m && +m[1] >= 7 && +m[1] <= 8 ? 'Web server banner: ' + c.http.slice(0, 70) : null; });
vr('VULN-GOAHEAD', 'high', 8.1, 'software', 'GoAhead web server older than 3.6.5 (CVE-2017-17562)',
  'GoAhead is built into many routers, cameras and PLC web pages. Versions before 3.6.5 allow remote code execution through CGI.',
  ['Install the vendor firmware that includes GoAhead 3.6.5 or later.', 'Do not expose the web interface outside the management network.'],
  function (c) { const m = /goahead[- ]?web[s]?[\/ ]*(\d+\.\d+\.\d+)/i.exec(c.http); return m && vlt(vver(m[1]), [3, 6, 5]) ? 'Web server banner: ' + c.http.slice(0, 70) : null; }, { cve: ['CVE-2017-17562'], kev: true, maturity: 'poc' });
vr('VULN-BOA', 'high', 7.5, 'eol', 'Boa web server (abandoned since 2005)',
  'Boa was never updated after 2005 and has known flaws (for example CVE-2017-9833). It is still found in cheap cameras, routers and gateways.',
  ['Check for newer firmware from the device maker, or replace the device.', 'Keep the device off the internet and in an isolated VLAN.'],
  function (c) { return /\bboa\/\d/i.test(c.http) ? 'Web server banner: ' + c.http.slice(0, 70) : null; }, { cve: ['CVE-2017-9833'] });
vr('VULN-VSFTPD-234', 'critical', 9.8, 'software', 'vsftpd 2.3.4 backdoor (CVE-2011-2523)',
  'This exact vsftpd release was distributed with a hidden backdoor that gives a remote root shell.',
  ['Remove vsftpd 2.3.4 and install a current vsftpd from your operating system vendor.', 'Treat the host as compromised: review it and change its passwords.'],
  function (c) { return /vsftpd 2\.3\.4/i.test(c.ftp) ? 'FTP banner: ' + c.ftp.slice(0, 70) : null; }, { cve: ['CVE-2011-2523'], maturity: 'weaponized' });
vr('VULN-PROFTPD', 'critical', 9.8, 'software', 'ProFTPD 1.3.5 or older (mod_copy file copy, CVE-2015-3306)',
  'Unauthenticated users can copy files on the server (and so plant code) when mod_copy is loaded.',
  ['Upgrade ProFTPD to 1.3.6c or later.', 'Disable the mod_copy module if it is not needed.'],
  function (c) { const m = /proftpd[ \/]?(\d+\.\d+\.\d+[a-z]?)/i.exec(c.ftp); return m && vlt(vver(m[1]), [1, 3, 6]) ? 'FTP banner: ' + c.ftp.slice(0, 70) : null; }, { cve: ['CVE-2015-3306', 'CVE-2019-12815'], conf: 'likely', maturity: 'weaponized' });
vr('VULN-HEARTBLEED', 'critical', 7.5, 'software', 'OpenSSL Heartbleed (CVE-2014-0160)',
  'OpenSSL 1.0.1 to 1.0.1f leaks server memory (keys and passwords) to anyone who asks.',
  ['Upgrade OpenSSL to a supported version and restart every service that uses it.', 'Replace the TLS certificates and change passwords that were used on this device.'],
  function (c) { const m = /openssl\/1\.0\.1([a-z]?)/i.exec(c.http); return m && (m[1] === '' || m[1].toLowerCase() <= 'f') ? 'Web server banner: ' + c.http.slice(0, 70) : null; }, { cve: ['CVE-2014-0160'], maturity: 'weaponized' });
vr('VULN-OPENSSL-EOL', 'high', 7.5, 'eol', 'OpenSSL older than 1.1.1 (unsupported)',
  'OpenSSL 0.9.8, 1.0.x no longer receive security fixes.',
  ['Update the operating system / firmware to one that ships OpenSSL 3.x.', 'If the device cannot be updated, isolate it and plan its replacement.'],
  function (c) { return /openssl\/(0\.9|1\.0)/i.test(c.http) ? 'Web server banner: ' + c.http.slice(0, 70) : null; });
vr('VULN-PHP-EOL', 'high', 7.5, 'eol', 'PHP version no longer supported',
  'PHP versions before 8.2 no longer receive security fixes.',
  ['Upgrade PHP to a supported release (8.3 or later) and test the application.', 'If it is a vendor product, request an updated version.'],
  function (c) { const m = /php\/(\d+\.\d+)/i.exec(c.http); return m && vlt(vver(m[1]), [8, 2]) ? 'Web server banner: ' + c.http.slice(0, 70) : null; });

/* ---- operating systems that no longer get patches ---- */
vr('VULN-OS-WIN-OLD', 'critical', 9.8, 'eol', 'Windows XP / 2000 / 2003 / Vista (no security updates for years)',
  'Microsoft stopped fixing these systems between 2010 and 2017. Known remote exploits work against them.',
  ['Replace or upgrade the computer to a supported Windows version.', 'Until then: disconnect from the network or isolate it in its own VLAN with only the traffic it needs.', 'Apply application whitelisting and remove internet access.'],
  function (c) { return /windows (xp|2000|2003|vista|server 2003)/.test(c.os) ? 'OS reported as "' + c.osRaw + '"' : null; });
vr('VULN-OS-WIN-7', 'high', 8.8, 'eol', 'Windows 7 / 8 / 8.1 / Server 2008 / 2012 (end of support)',
  'These Windows versions no longer receive regular security updates (Windows 7 / Server 2008 since 2020, 8.1 since 2023, Server 2012 since October 2023).',
  ['Upgrade to a supported Windows (Windows 11, Server 2022 or later).', 'If it must stay (e.g. certified control software), isolate it, restrict USB and file shares and consider paid Extended Security Updates where offered.'],
  function (c) { return /windows (7\b|8\b|8\.1|server 2008|server 2012|2008|2012)/.test(c.os) ? 'OS reported as "' + c.osRaw + '"' : null; });
vr('VULN-OS-WIN-10', 'medium', 6.5, 'eol', 'Windows 10 reached end of support (14 October 2025)',
  'Windows 10 only receives fixes through the paid Extended Security Updates programme.',
  ['Upgrade to Windows 11, or enrol the device in Extended Security Updates.', 'Check that the device is on the latest Windows 10 22H2 build until upgraded.'],
  function (c) { return /windows 10/.test(c.os) && !/11/.test(c.os) ? 'OS reported as "' + c.osRaw + '"' : null; });
vr('VULN-OS-LINUX-OLD', 'high', 7.5, 'eol', 'Very old Linux kernel (2.x / 3.x)',
  'Linux 2.6 and 3.x kernels stopped receiving fixes years ago and contain many public privilege-escalation flaws. This is typical of old routers, cameras and embedded gear.',
  ['Install the newest firmware from the vendor.', 'If none exists, replace the device or isolate it.'],
  function (c) { return /linux[^0-9]{0,6}(2\.[0-6]|3\.\d)/.test(c.os) ? 'OS reported as "' + c.osRaw + '"' : null; });
vr('VULN-OS-ANDROID-OLD', 'medium', 6.5, 'eol', 'Android 9 or older (no security updates)',
  'Google and the phone makers no longer patch these Android versions.',
  ['Upgrade the phone or tablet to a supported Android version, or replace it.', 'Keep it off the production network (guest Wi-Fi only).'],
  function (c) { const m = /android[ \/]?(\d+)/.exec(c.os); return m && +m[1] <= 9 ? 'OS reported as "' + c.osRaw + '"' : null; });
vr('VULN-VXWORKS', 'high', 9.8, 'software', 'VxWorks network stack flaws (URGENT/11)',
  'Several VxWorks 6.x / 7 releases from before 2019 have 11 remote code-execution flaws in the TCP/IP stack. VxWorks runs inside many PLCs, switches, printers and medical devices.',
  ['Ask the device vendor which firmware contains the URGENT/11 fixes and install it.', 'Segment the device and block unsolicited inbound TCP/IP traffic to it.'],
  function (c) { return /vxworks/.test(c.blob) ? 'VxWorks reported by the device or scan' : null; }, { cve: ['CVE-2019-12255', 'CVE-2019-12256', 'CVE-2019-12257'], conf: 'possible', maturity: 'poc' });

/* ---- OT / ICS ---- */
const OT_PROTO = [
  ['MODBUS', 'Modbus/TCP', /modbus/, [502], 'medium', 6.5, 'Modbus/TCP has no login and no encryption: any host that can reach port 502 can read and write registers and coils.'],
  ['S7', 'Siemens S7comm', /s7/, [102], 'high', 7.5, 'Classic S7comm has no strong authentication: any host that can reach port 102 can read, stop or reprogram the PLC unless "protection level" and access control are set.'],
  ['ENIP', 'EtherNet/IP (CIP)', /enip|ethernet\/ip|\bcip\b/, [44818], 'medium', 6.5, 'EtherNet/IP is unauthenticated by design; any host that can reach port 44818 can read or change controller data and, on many models, change the mode.'],
  ['DNP3', 'DNP3', /dnp3/, [20000], 'medium', 6.5, 'DNP3 without Secure Authentication accepts commands from any host that can reach it.'],
  ['IEC104', 'IEC 60870-5-104', /iec[- ]?104|\b104\b/, [2404], 'medium', 6.5, 'IEC-104 has no authentication or encryption, so any host that can reach port 2404 can send control commands.'],
  ['BACNET', 'BACnet/IP', /bacnet/, [47808], 'medium', 5.3, 'BACnet/IP has no authentication by default; anyone on the network can read or write building-control points.'],
  ['FINS', 'Omron FINS', /fins/, [9600], 'high', 7.5, 'Omron FINS accepts read, write and stop commands from any host without authentication.'],
  ['MELSEC', 'Mitsubishi MELSEC', /melsec|\bmc protocol/, [5007, 5006], 'high', 7.5, 'MELSEC (MC protocol) has no authentication on many controllers, so any host can read, write or stop the CPU.'],
  ['OPCUA', 'OPC UA', /opc ?ua|opcua/, [4840], 'low', 3.7, 'OPC UA supports secure channels, but "None" security mode and anonymous login are common defaults.']
];
OT_PROTO.forEach(function (p) {
  const secure = p[0] === 'OPCUA';
  vr('VULN-OT-' + p[0], p[4], p[5], 'ot', p[1] + (secure ? ' server allows unsecured access' : ' is exposed without authentication'),
    p[6] + ' This is a weakness of the protocol, not a bug in one product, so it is fixed by network design rather than a patch.',
    secure ? ['Set the endpoint security policy to Sign or SignAndEncrypt and turn off anonymous login.', 'Use application certificates and restrict which clients are trusted.']
      : ['Allow ' + p[1] + ' only from the engineering workstation, SCADA / HMI and historian that really talk to this device (firewall or switch ACL).', 'Block it between the office (IT) network and the control network; use a DMZ / jump host for remote access.', 'Where the device offers it, enable the vendor\'s access protection (password, keyswitch in RUN, protection level).', 'Alert on any new client talking this protocol (OT Sense already raises these as alerts).'],
    function (c) {
      const h = vhasPort(c, p[3]), sv = c.serves.some(function (x) { return p[2].test(x); });
      if (sv) return p[1] + ' served by this device' + (h ? ' on port ' + h.join(', ') : '');
      if (h) return 'TCP/' + h.join(', ') + ' is open (' + p[1] + ', protocol not yet confirmed)';
      return null;
    },
    { conf: secure ? 'possible' : 'confirmed' });
});
vr('VULN-ROCKWELL-LOGIX', 'critical', 10, 'software', 'Rockwell Logix controller key-switch bypass (CVE-2021-22681)',
  'Studio 5000 Logix Designer and Logix 5000 controllers (CompactLogix, ControlLogix, GuardLogix) before the fixed firmware can be reprogrammed even when the key switch is in RUN.',
  ['Install the firmware listed in Rockwell advisory SD1153 / ICSA-21-056-03 for your controller family.', 'Keep the key switch in RUN and allow EtherNet/IP only from the engineering station.', 'Monitor for download / program-change commands (OT Sense Activity tab).'],
  function (c) { return /rockwell|allen[- ]?bradley/.test(c.vendor) && vhasPort(c, [44818]) ? 'Rockwell device serving EtherNet/IP on 44818' + (c.fw ? ' (firmware ' + c.fw + ')' : ' (firmware unknown)') : null; },
  { cve: ['CVE-2021-22681'], conf: 'possible', maturity: 'poc' });
vr('VULN-OT-FW-UNKNOWN', 'info', 0, 'hygiene', 'OT device firmware version not identified',
  'Central cannot tell whether this controller is patched because no firmware version was captured, so vendor advisories cannot be matched.',
  ['Record the firmware version from the vendor tool (or turn on Active scanning for this subnet if it is safe for the equipment).', 'Add the device to the patch / maintenance plan.'],
  function (c) { return c.ot && !c.fw ? 'No firmware version reported' : null; });
vr('VULN-UNKNOWN-MODEL', 'info', 0, 'hygiene', 'Device model and vendor not identified',
  'Without the make and model a device cannot be checked against vendor advisories.',
  ['Identify the device (label, switch port, DHCP name) and fill in its details.', 'Turn on Active scanning for this subnet so central can fingerprint it.'],
  function (c) { return c.ot && !c.vendor.trim() && !c.model ? 'Vendor and model are empty' : null; });

/* ---- extra rules the organisation adds itself (Vulnerabilities > Custom rules) ---- */
function vrx(s) { try { return s ? new RegExp(String(s).slice(0, 200), 'i') : null; } catch (e) { return null; } }
function vcompileCustom(list) {
  return (Array.isArray(list) ? list : []).slice(0, 300).map(function (r, i) {
    if (!r || typeof r !== 'object') return null;
    const m = (r.match && typeof r.match === 'object') ? r.match : {};
    const id = S(r.id, 60).replace(/[^A-Za-z0-9_.-]/g, '') || ('CUSTOM-' + (i + 1)), sev = VSEV_NAME.indexOf(String(r.severity).toLowerCase()) !== -1 ? String(r.severity).toLowerCase() : 'medium';
    const rx = { vendor: vrx(m.vendor), model: vrx(m.model), os: vrx(m.os), firmware: vrx(m.firmware), banner: vrx(m.banner), protocol: vrx(m.protocol), device_type: vrx(m.device_type) };
    const ports = [].concat(m.port == null ? [] : m.port).map(function (x) { return parseInt(x, 10); }).filter(Boolean);
    if (!Object.keys(rx).some(function (k) { return rx[k]; }) && !ports.length) return null;       // a rule that matches everything is a mistake
    return { id: id, severity: sev, cvss: Math.min(10, Math.max(0, parseFloat(r.cvss) || 0)), cat: VCAT_LABEL[r.category] ? r.category : 'software', title: S(r.title, 200) || id,
      desc: S(r.description, 800), fix: [].concat(r.resolution || r.fix || []).map(function (x) { return S(x, 300); }).filter(Boolean).slice(0, 10), custom: true,
      cve: [].concat(r.cve || []).map(function (x) { return S(x, 30).toUpperCase(); }).filter(Boolean).slice(0, 10), conf: ['confirmed', 'likely', 'possible'].indexOf(r.confidence) !== -1 ? r.confidence : 'likely',
      test: function (c) {
        if (rx.vendor && !rx.vendor.test(c.vendor)) return null;
        if (rx.model && !rx.model.test(c.model)) return null;
        if (rx.os && !rx.os.test(c.osRaw)) return null;
        if (rx.firmware && !rx.firmware.test(c.fw)) return null;
        if (rx.device_type && !rx.device_type.test(c.dtype)) return null;
        if (rx.protocol && !c.protos.concat(c.serves).some(function (x) { return rx.protocol.test(x); })) return null;
        if (rx.banner && !rx.banner.test([c.http, c.ssh, c.ftp, c.telnet, c.snmp, c.ssdp].join(' | '))) return null;
        if (ports.length && !ports.some(function (p) { return c.ports.has(p); })) return null;
        return 'Matches custom rule ' + id;
      } };
  }).filter(Boolean);
}
const VCUSTOM_CACHE = new Map();
function vrulesFor(tid) {
  const key = String(tid || 'default'), raw = (DB.vrules || {})[key];
  if (!raw || !raw.length) return { list: VRULES, ver: 'b' };
  const h = sha(JSON.stringify(raw)).slice(0, 12), c = VCUSTOM_CACHE.get(key);
  if (c && c.h === h) return c.v;
  const custom = vcompileCustom(raw), ids = new Set(custom.map(function (r) { return r.id; }));
  const v = { list: VRULES.filter(function (r) { return !ids.has(r.id); }).concat(custom), ver: h };
  VCUSTOM_CACHE.set(key, { h: h, v: v });
  return v;
}

function vctx(a) {
  const d = a.data || {}, props = d.properties || {}, low = function (x) { return String(x == null ? '' : x).toLowerCase(); };
  const pv = function (k) { return String(props[k] == null ? '' : (Array.isArray(props[k]) ? props[k].join(' ') : props[k])); };
  const tg = d.tags || {}, ports = new Set();
  (d.listening_ports || []).forEach(function (x) { const n = parseInt(x, 10); if (n) ports.add(n); });
  return { a: a, ports: ports, osRaw: String(a.os || ''), os: low(a.os), vendor: low((a.vendor || '') + ' ' + (d.mac_vendor || '')), model: String(a.model || ''), fw: String(a.firmware || ''), dtype: low(a.device_type),
    ot: !!a.ot, protos: (a.protocols || []).map(low), serves: Object.keys(d.serves || {}).map(low),
    ssh: pv('ssh_banner'), http: pv('http_server') + ' ' + [].concat(tg.http_server || []).join(' '), ftp: pv('ftp_banner'), telnet: pv('telnet_banner'), snmp: pv('snmp_descr'), ssdp: pv('ssdp_server'),
    blob: String(a.search || '') };
}
const VCACHE = new Map();       // sid|id -> { u, ver, list }   (findings of one asset, recomputed only when the asset or the rules change)
function vulnOfAsset(sid, a, rules) {
  const ck = sid + '|' + a.id, hit = VCACHE.get(ck);
  if (hit && hit.u === a.updated && hit.ver === rules.ver) return hit.list;
  const c = vctx(a), out = [];
  rules.list.forEach(function (r) {
    let ev = null;
    try { ev = r.test(c); } catch (e) { ev = null; }
    if (ev) out.push({ vid: r.id, evidence: String(ev) });
  });
  const list = out;
  VCACHE.set(ck, { u: a.updated, ver: rules.ver, list: list });
  if (VCACHE.size > 200000) VCACHE.clear();
  return list;
}
function vstateKey(sid, id, vid) { return sid + '|' + id + '|' + vid; }
/* Default remediation window: how many days a finding gets before it counts as overdue, if nobody sets a due date by hand.
   Shorter when the issue is in the CISA Known Exploited catalog, since those are being actively used in attacks today. */
function vDueDays(sev, kev) {
  const base = { critical: 15, high: 30, medium: 90, low: 180, info: 365 }[sev] || 180;
  return kev ? Math.min(base, 7) : base;
}
/* How urgent a finding is, worst first: criticality, then whether it is actively exploited, then how mature the exploit is, then CVSS. */
function vPriority(r) { return (VWEIGHT[r.severity] || 0) * 100 + (r.kev ? 40 : 0) + (r.maturity === 'weaponized' ? 20 : r.maturity === 'poc' ? 8 : 0) + Math.min(10, r.cvss || 0); }
/* One finding as the screens and reports see it (rule data + device data + the status a person set). */
function vbuild(sid, a, hit, rules, now) {
  const r = rules.byId[hit.vid]; if (!r) return null;
  const site = DB.sites[sid] || {}, key = vstateKey(sid, a.id, r.id), st = (DB.vstate || {})[key];
  let status = st && VSTATUS.indexOf(st.status) !== -1 ? st.status : 'open', reopened = false;
  if (status === 'resolved' && st && a.updated > st.at + 600) { status = 'open'; reopened = true; }      // the sensor still sees it 10 minutes after the fix
  if (!DB.vfirst) DB.vfirst = {};
  if (!DB.vfirst[key]) { DB.vfirst[key] = now; dirty = true; }
  const first = DB.vfirst[key], dueDefault = first + vDueDays(r.severity, r.kev) * 86400, due = (st && st.due) || dueDefault, open = VOPEN(status);
  return { key: key, site: sid, site_name: site.name || '', org_name: tenantName(site.tenant), asset: a.id, ip: a.ip || '', hostname: (a.hostnames || [])[0] || '', vendor: a.vendor || '', device_type: a.device_type || '', os: a.os || '',
    model: a.model || '', firmware: a.firmware || '', ot: a.ot ? 1 : 0, vid: r.id, title: r.title, severity: r.severity, sev: SEV[r.severity], cvss: r.cvss, cve: r.cve, cat: r.cat, cat_label: VCAT_LABEL[r.cat] || r.cat,
    confidence: r.conf, evidence: hit.evidence, status: status, status_label: VSTATUS_LABEL[status], reopened: reopened, note: st ? st.note || '' : '', by: st ? st.by || '' : '', at: st ? st.at || 0 : 0,
    first_seen: first, custom: !!r.custom, kev: !!r.kev, maturity: r.maturity || 'none', priority: vPriority(r), owner: st ? st.owner || '' : '', due: due, due_default: dueDefault,
    overdue: open && now > due };
}
function vindex(rules) { if (!rules.byId) { rules.byId = {}; rules.list.forEach(function (r) { rules.byId[r.id] = r; }); } return rules; }
function vulnAll(scope, only) {
  const out = [], now = Date.now() / 1000;
  for (const sid of scope) {
    if (only && sid !== only) continue;
    const site = DB.sites[sid]; if (!site) continue;
    const rules = vindex(vrulesFor(site.tenant)), A = DB.assets[sid] || {};
    for (const id in A) {
      const a = A[id]; if (a.gone) continue;
      vulnOfAsset(sid, a, rules).forEach(function (h) { const f = vbuild(sid, a, h, rules, now); if (f) out.push(f); });
    }
  }
  return out;
}
function vulnRule(tid, vid) { const r = vindex(vrulesFor(tid)).byId[vid]; return r || null; }
function vulnDetail(f, tid) {       // a finding plus the full text of its rule, reference links, and any alerts central has already raised for this device
  const r = vulnRule(tenantOfSite(f.site), f.vid) || {};
  const refs = f.cve.map(function (c) { return { label: c + ' (NVD)', url: 'https://nvd.nist.gov/vuln/detail/' + c }; });
  if (f.kev) refs.push({ label: 'CISA Known Exploited Vulnerabilities catalog', url: 'https://www.cisa.gov/known-exploited-vulnerabilities-catalog' });
  const keys = [f.ip, f.hostname].filter(Boolean), cut = Date.now() / 1000 - 30 * 86400;
  const related = Object.values(DB.alerts[f.site] || {}).filter(function (x) { return (keys.indexOf(x.src) !== -1 || keys.indexOf(x.dst) !== -1) && x.updated >= cut; })
    .sort(function (x, y) { return y.updated - x.updated; });
  return Object.assign({}, f, { desc: r.desc || '', fix: r.fix || [], refs: refs, kev_asof: VKEV_ASOF, maturity_label: VMAT_LABEL[f.maturity] || '',
    related_alerts: related.length, related_sample: related.slice(0, 3).map(function (x) { return x.title || x.kind; }) });
}
function vulnOfOneAsset(sid, id) {
  const a = devGet(sid, id); if (!a) return [];
  const rules = vindex(vrulesFor(tenantOfSite(sid))), now = Date.now() / 1000;
  return vulnOfAsset(sid, a, rules).map(function (h) { return vbuild(sid, a, h, rules, now); }).filter(Boolean)
    .sort(function (x, y) { return y.sev - x.sev || y.cvss - x.cvss; });
}
function vscore(list) { let s = 0; list.forEach(function (f) { s += VWEIGHT[f.severity] || 0; }); return Math.min(100, s); }
function vcount(list) { const o = { critical: 0, high: 0, medium: 0, low: 0, info: 0 }; list.forEach(function (f) { o[f.severity]++; }); return o; }

/* search box terms: sev:high  status:open  cat:eol  cve:2021-41773  vuln:telnet  ip:10.0.  vendor:siemens  type:camera  site:plant */
function vulnMatch(f, terms) {
  for (const t of terms) {
    let ok;
    const has = function (x) { const v = String(x == null ? '' : x).toLowerCase(); return t.exact ? v === t.val : v.indexOf(t.val) !== -1; };
    const ipSpec = t.key === 'ip' ? zParseSpec(t.val) : null;
    if (t.key === 'device') { if (t.neg ? devHit('vulns', f, t, f.site) : !devHit('vulns', f, t, f.site)) return false; continue; }
    if (t.key === 'sev' || t.key === 'severity') ok = f.severity === t.val;
    else if (t.key === 'status') ok = f.status === t.val || f.status_label.toLowerCase() === t.val;
    else if (t.key === 'cat' || t.key === 'category') ok = f.cat === t.val || has(f.cat_label);
    else if (t.key === 'cve') ok = f.cve.some(function (x) { return x.toLowerCase().indexOf(t.val) !== -1; });
    else if (t.key === 'vuln' || t.key === 'id') ok = has(f.vid) || has(f.title);
    else if (t.key === 'ip') ok = ipSpec ? (zIpOk(f.ip || '') && zIpN(f.ip) >= ipSpec.lo && zIpN(f.ip) <= ipSpec.hi) : has(f.ip);
    else if (t.key === 'vendor') ok = has(f.vendor);
    else if (t.key === 'type') ok = has(f.device_type);
    else if (t.key === 'os') ok = has(f.os);
    else if (t.key === 'site') ok = has(f.site_name);
    else if (t.key === 'conf') ok = f.confidence === t.val;
    else if (t.key === 'owner') ok = has(f.owner) || (t.val === 'none' && !f.owner);
    else if (t.key === 'kev' || t.key === 'exploited') ok = f.kev === (t.val !== 'false' && t.val !== '0' && t.val !== 'no');
    else if (t.key === 'exploit') ok = t.val === 'weaponized' ? f.maturity === 'weaponized' : t.val === 'none' ? f.maturity === 'none' : f.maturity !== 'none';
    else if (t.key === 'overdue') ok = f.overdue === (t.val !== 'false' && t.val !== '0' && t.val !== 'no');
    else ok = has([f.title, f.vid, f.cve.join(' '), f.ip, f.hostname, f.vendor, f.device_type, f.model, f.os, f.evidence, f.site_name, f.cat_label, f.owner].join(' '));
    if (t.neg ? ok : !ok) return false;
  }
  return true;
}
function vulnList(scope, p) {
  const terms = parseQ(p.q), only = p.site ? String(p.site) : '';
  let base = vulnAll(scope, only).filter(function (f) { return vulnMatch(f, terms); });
  if (p.cat) base = base.filter(function (f) { return f.cat === p.cat; });
  const statusSel = p.status === 'all' ? '' : (p.status === 'active' || !p.status ? 'active' : p.status), sevSel = p.sev || '';
  const stOk = function (f) { return !statusSel || (statusSel === 'active' ? VOPEN(f.status) : f.status === statusSel); };
  const facets = { severity: { critical: 0, high: 0, medium: 0, low: 0, info: 0 }, status: {} };
  base.forEach(function (f) {
    if (stOk(f)) facets.severity[f.severity]++;
    if (!sevSel || f.severity === sevSel) facets.status[f.status] = (facets.status[f.status] || 0) + 1;
  });
  const rows = base.filter(function (f) { return stOk(f) && (!sevSel || f.severity === sevSel); })
    .sort(p.sort === 'due'
      ? function (x, y) { return (y.overdue - x.overdue) || (x.due - y.due) || (y.priority - x.priority); }
      : function (x, y) { return y.sev - x.sev || y.cvss - x.cvss || (x.ip > y.ip ? 1 : -1); });
  const total = rows.length, page = Math.max(1, parseInt(p.page, 10) || 1);
  if (p.limit) return { total: total, rows: rows.slice(0, p.limit), facets: facets };
  return { total: total, page: page, size: PAGE_SIZE, facets: facets, rows: rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE) };
}
function vgroup(list) {       // one row per vulnerability: how many devices, worst first
  const m = {};
  list.forEach(function (f) {
    const g = m[f.vid] || (m[f.vid] = { vid: f.vid, title: f.title, severity: f.severity, sev: f.sev, cvss: f.cvss, cve: f.cve, cat: f.cat, cat_label: f.cat_label, confidence: f.confidence, devices: 0, ot_devices: 0, kev: f.kev, maturity: f.maturity });
    g.devices++; if (f.ot) g.ot_devices++; if (!g.site) g.site = f.site;
  });
  return Object.keys(m).map(function (k) { return m[k]; }).sort(function (a, b) { return b.sev - a.sev || b.cvss - a.cvss || b.devices - a.devices; });
}
function vulnSummary(scope, only) {
  const all = vulnAll(scope, only), open = all.filter(function (f) { return VOPEN(f.status); }), now = Date.now() / 1000;
  const byStatus = {}; all.forEach(function (f) { byStatus[f.status] = (byStatus[f.status] || 0) + 1; });
  const dev = {};
  open.forEach(function (f) { const k = f.site + '|' + f.asset, d = dev[k] || (dev[k] = { site: f.site, id: f.asset, ip: f.ip, hostname: f.hostname, vendor: f.vendor, device_type: f.device_type, site_name: f.site_name, ot: f.ot, list: [] }); d.list.push(f); });
  const devices = Object.keys(dev).map(function (k) { const d = dev[k]; const c = vcount(d.list); return { site: d.site, id: d.id, ip: d.ip, hostname: d.hostname, vendor: d.vendor, device_type: d.device_type, site_name: d.site_name, ot: d.ot, score: vscore(d.list), counts: c, total: d.list.length }; })
    .sort(function (a, b) { return b.score - a.score || b.counts.critical - a.counts.critical; });
  const tally = function (fn) { const m = {}; open.forEach(function (f) { const k = fn(f) || 'Unknown'; m[k] = m[k] || { k: k, n: 0, c: 0, h: 0 }; m[k].n++; if (f.severity === 'critical') m[k].c++; if (f.severity === 'high') m[k].h++; }); return Object.keys(m).map(function (k) { return m[k]; }).sort(function (a, b) { return b.c - a.c || b.h - a.h || b.n - a.n; }); };
  const cves = new Set(); open.forEach(function (f) { f.cve.forEach(function (c) { cves.add(c); }); });
  let assets = 0; for (const sid of scope) { if (only && sid !== only) continue; assets += Object.values(DB.assets[sid] || {}).filter(function (a) { return !a.gone; }).length; }
  const cut = now - 30 * 86400, res30 = all.filter(function (f) { return f.status === 'resolved' && f.at >= cut; }).length;
  const kevN = open.filter(function (f) { return f.kev; }).length, pocN = open.filter(function (f) { return !f.kev && f.maturity !== 'none'; }).length;
  const overdueN = open.filter(function (f) { return f.overdue; }).length, unassignedN = open.filter(function (f) { return !f.owner; }).length;
  // trend: the daily snapshots kept by vulnSnapshot(), summed over the sites in scope
  const days = {}; for (const sid of scope) { if (only && sid !== only) continue; const t = (DB.vtrend || {})[sid] || {}; for (const d in t) { const x = days[d] || (days[d] = [0, 0, 0, 0]); for (let i = 0; i < 4; i++) x[i] += t[d][i] || 0; } }
  const labels = Object.keys(days).sort().slice(-30);
  return { totals: Object.assign(vcount(open), { open: open.length, devices_affected: devices.length, devices: assets, cves: cves.size, resolved_30d: res30, kev: kevN, exploit_available: pocN, overdue: overdueN, unassigned: unassignedN, kev_asof: VKEV_ASOF }),
    status: byStatus, top_vulns: vgroup(open).slice(0, 10), top_devices: devices.slice(0, 8), by_category: tally(function (f) { return f.cat_label; }), by_type: tally(function (f) { return f.device_type; }).slice(0, 8),
    by_site: tally(function (f) { return f.site_name; }).slice(0, 10), by_confidence: tally(function (f) { return f.confidence; }),
    trend: { labels: labels, critical: labels.map(function (d) { return days[d][0]; }), high: labels.map(function (d) { return days[d][1]; }), medium: labels.map(function (d) { return days[d][2]; }), low: labels.map(function (d) { return days[d][3]; }) } };
}
function vulnTotals(scope, only) { const o = vcount(vulnAll(scope, only).filter(function (f) { return VOPEN(f.status); })); return o; }
function vulnSnapshot() {             // once an hour: remember today's open counts per site so the dashboard can draw a trend
  try {
    const day = new Date().toISOString().slice(0, 10), all = vulnAll(new Set(Object.keys(DB.sites)), ''), per = {};
    all.forEach(function (f) { if (!VOPEN(f.status)) return; const x = per[f.site] || (per[f.site] = [0, 0, 0, 0]); const i = { critical: 0, high: 1, medium: 2, low: 3 }[f.severity]; if (i !== undefined) x[i]++; });
    DB.vtrend = DB.vtrend || {};
    for (const sid in DB.sites) {
      const t = DB.vtrend[sid] || (DB.vtrend[sid] = {}), now = per[sid] || [0, 0, 0, 0];
      if (!t[day] || t[day].join() !== now.join()) { t[day] = now; dirty = true; }
      const ks = Object.keys(t).sort(); if (ks.length > 120) ks.slice(0, ks.length - 120).forEach(function (k) { delete t[k]; });
    }
  } catch (e) { console.error('Vulnerability snapshot failed: ' + e.message); }
}
function vulnPrune() {                // called by purge(): forget first-seen / status entries of findings that are gone for good
  const live = new Set(vulnAll(new Set(Object.keys(DB.sites)), '').map(function (f) { return f.key; })), cut = Date.now() / 1000 - 30 * 86400;
  for (const k in (DB.vfirst || {})) if (!live.has(k)) { delete DB.vfirst[k]; dirty = true; }
  for (const k in (DB.vstate || {})) if (!live.has(k) && (DB.vstate[k].at || 0) < cut) { delete DB.vstate[k]; dirty = true; }
}

/* ---- CSV and printable reports ---- */
function vh(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function vulnCsv(rows) {
  const cols = ['org_name', 'site_name', 'ip', 'hostname', 'vendor', 'device_type', 'os', 'vid', 'title', 'severity', 'cvss', 'cve', 'kev', 'maturity', 'cat_label', 'confidence', 'evidence', 'resolution', 'status_label', 'owner', 'due', 'overdue', 'note', 'first_seen'];
  return [cols.join(',')].concat(rows.map(function (f) {
    const r = vulnRule(tenantOfSite(f.site), f.vid) || {}, x = Object.assign({}, f, { resolution: (r.fix || []).map(function (s, i) { return (i + 1) + ') ' + s; }).join(' '), cve: f.cve.join(' '), due: f.due ? new Date(f.due * 1000).toISOString().slice(0, 10) : '', first_seen: new Date(f.first_seen * 1000).toISOString().slice(0, 10) });
    return cols.map(function (c) { return csvEscape(x[c]); }).join(',');
  })).join('\r\n');
}
function vulnReport(kind, rows, ctx) {
  const SEVC = { critical: '#c8283b', high: '#e0701f', medium: '#c88a10', low: '#2f9d6a', info: '#4a7fb5' };
  const open = rows.filter(function (f) { return VOPEN(f.status); }), counts = vcount(open), groups = vgroup(open);
  const devKeys = {}; open.forEach(function (f) { devKeys[f.site + '|' + f.asset] = 1; });
  const when = new Date().toISOString().slice(0, 16).replace('T', ' ') + ' UTC';
  const title = { executive: 'Vulnerability executive summary', detailed: 'Vulnerability report: findings by device', remediation: 'Remediation plan: standard resolutions', plan: 'Remediation plan: by due date' }[kind] || 'Vulnerability report';
  const badge = function (s) { return '<span class="b" style="background:' + SEVC[s] + '">' + vh(s) + '</span>'; };
  const xbadge = function (f) { return f.kev ? '<span class="b" style="background:#7a1030">Actively exploited</span>' : f.maturity && f.maturity !== 'none' ? '<span class="b" style="background:#5a4a10">Exploit available</span>' : ''; };
  const dueTxt = function (f) { if (!f.due) return ''; const d = new Date(f.due * 1000).toISOString().slice(0, 10); return f.overdue ? '<b style="color:#c8283b">' + d + ' (overdue)</b>' : d; };
  let h = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + vh(title) + '</title><style>'
    + 'body{font:14px/1.5 "Segoe UI",system-ui,Arial,sans-serif;color:#1a2633;margin:0;background:#eef2f7}main{max-width:980px;margin:0 auto;padding:24px;background:#fff;border-top:6px solid #0fb5cf}'
    + 'h1{font-size:24px;margin:0 0 4px}h2{font-size:17px;margin:26px 0 8px;border-bottom:2px solid #d3dce8;padding-bottom:4px}h3{font-size:15px;margin:16px 0 4px}.m{color:#5a6c80;font-size:12.5px}'
    + '.t{display:flex;flex-wrap:wrap;gap:10px;margin:14px 0}.k{flex:1 1 130px;border:1px solid #d3dce8;border-radius:8px;padding:10px 12px;border-top:4px solid #8397ad}.k b{display:block;font-size:28px;font-weight:300}'
    + 'table{border-collapse:collapse;width:100%;font-size:12.5px;margin:6px 0}th{text-align:left;background:#f1f5fa;padding:6px 8px;border-bottom:1px solid #d3dce8}td{padding:6px 8px;border-bottom:1px solid #e6edf5;vertical-align:top}'
    + '.b{display:inline-block;color:#fff;border-radius:4px;padding:0 7px;font-size:11.5px;font-weight:600;text-transform:uppercase}.c{display:inline-block;background:#e6edf5;border-radius:9px;padding:0 7px;font-size:11.5px;margin:1px 3px 1px 0}'
    + '.bar{height:10px;background:#e6edf5;border-radius:5px}.bar i{display:block;height:100%;border-radius:5px}ol{margin:4px 0 8px 20px;padding:0}.box{border:1px solid #d3dce8;border-radius:8px;padding:10px 14px;margin:10px 0;page-break-inside:avoid}'
    + '.pr{margin:0 0 14px;padding:8px 12px;background:#fff3dc;border:1px solid #e6bd72;border-radius:6px;font-size:12.5px}@media print{body{background:#fff}main{padding:0;max-width:none}.pr{display:none}a{color:inherit;text-decoration:none}}'
    + '</style></head><body><main><div class="pr">Use your browser\'s Print command and choose "Save as PDF" to keep a copy.</div>'
    + '<h1>' + vh(title) + '</h1><div class="m">' + vh(ctx.org) + (ctx.site ? ' &middot; ' + vh(ctx.site) : ' &middot; all sites') + ' &middot; created ' + when + ' by ' + vh(ctx.by) + '</div>';
  h += '<div class="t">' + ['critical', 'high', 'medium', 'low'].map(function (s) { return '<div class="k" style="border-top-color:' + SEVC[s] + '"><b>' + counts[s] + '</b>' + s + '</div>'; }).join('')
    + '<div class="k"><b>' + Object.keys(devKeys).length + '</b>devices affected</div><div class="k"><b>' + groups.length + '</b>different vulnerabilities</div></div>';
  if (!open.length) h += '<p>No open vulnerabilities were found for this selection.</p>';
  const worst = groups.slice(0, 10);
  if (kind === 'executive') {
    const tot = open.length || 1;
    h += '<h2>Where the risk is</h2><p>' + (counts.critical ? '<b>' + counts.critical + ' critical</b> and ' : '') + '<b>' + counts.high + ' high</b> findings need action first. '
      + 'They sit on ' + Object.keys(devKeys).length + ' device(s). Critical and high findings are usually closed by one of the standard resolutions listed below (patching, turning a service off, or restricting who can reach it).</p>';
    h += '<table><tr><th>Criticality</th><th style="width:50%">Share of open findings</th><th>Findings</th></tr>' + ['critical', 'high', 'medium', 'low', 'info'].map(function (s) { return '<tr><td>' + badge(s) + '</td><td><div class="bar"><i style="width:' + Math.round(100 * counts[s] / tot) + '%;background:' + SEVC[s] + '"></i></div></td><td>' + counts[s] + '</td></tr>'; }).join('') + '</table>';
    h += '<h2>Fix these first</h2><table><tr><th>Vulnerability</th><th>Exploit status</th><th>Criticality</th><th>Devices</th><th>Standard resolution (first step)</th></tr>' + worst.map(function (g) { const r = vulnRule(tenantOfSite(g.site), g.vid) || {}; return '<tr><td><b>' + vh(g.title) + '</b>' + (g.cve.length ? '<div>' + g.cve.map(function (c) { return '<span class="c">' + vh(c) + '</span>'; }).join('') + '</div>' : '') + '</td><td>' + (xbadge(g) || '<span class="m">none known</span>') + '</td><td>' + badge(g.severity) + '</td><td>' + g.devices + '</td><td>' + vh((r.fix || [])[0] || '') + '</td></tr>'; }).join('') + '</table>';
    const dev = {}; open.forEach(function (f) { const k = f.site + '|' + f.asset; (dev[k] = dev[k] || { f: f, l: [] }).l.push(f); });
    const top = Object.keys(dev).map(function (k) { return { f: dev[k].f, l: dev[k].l, s: vscore(dev[k].l) }; }).sort(function (a, b) { return b.s - a.s; }).slice(0, 10);
    h += '<h2>Most exposed devices</h2><table><tr><th>Device</th><th>Type</th><th>Site</th><th>Critical</th><th>High</th><th>Medium</th><th>Low</th></tr>' + top.map(function (d) { const c = vcount(d.l); return '<tr><td><b>' + vh(d.f.ip) + '</b>' + (d.f.hostname ? '<div class="m">' + vh(d.f.hostname) + '</div>' : '') + '</td><td>' + vh([d.f.vendor, d.f.device_type].filter(Boolean).join(' ')) + '</td><td>' + vh(d.f.site_name) + '</td><td>' + c.critical + '</td><td>' + c.high + '</td><td>' + c.medium + '</td><td>' + c.low + '</td></tr>'; }).join('') + '</table>';
    h += '<h2>How sure is this report?</h2><p class="m"><b>Confirmed</b> findings were seen directly (an open port, a version in a banner). <b>Likely</b> findings follow from what was seen. <b>Possible</b> findings are products with known flaws in some versions; check the version on the device. Central does not run exploit tests.</p>';
  } else if (kind === 'remediation') {
    h += '<h2>Remediation plan</h2><p class="m">One block per vulnerability, worst first, with the standard resolution and the devices it applies to.</p>';
    groups.forEach(function (g) {
      const r = vulnRule(tenantOfSite(g.site), g.vid) || {}, aff = open.filter(function (f) { return f.vid === g.vid; });
      h += '<div class="box"><h3>' + badge(g.severity) + ' ' + vh(g.title) + (xbadge(g) ? ' ' + xbadge(g) : '') + ' <span class="m">&middot; ' + g.devices + ' device(s) &middot; ' + vh(g.cat_label) + ' &middot; ' + vh(g.confidence) + (g.cvss ? ' &middot; score ' + g.cvss : '') + '</span></h3>'
        + (g.cve.length ? '<div>' + g.cve.map(function (c) { return '<span class="c">' + vh(c) + '</span>'; }).join('') + '</div>' : '') + '<p>' + vh(r.desc || '') + '</p><b>Standard resolution</b><ol>' + (r.fix || []).map(function (s) { return '<li>' + vh(s) + '</li>'; }).join('') + '</ol>'
        + '<div class="m"><b>Affected:</b> ' + aff.slice(0, 60).map(function (f) { return vh(f.ip + (f.hostname ? ' (' + f.hostname + ')' : '') + (f.owner ? ' [' + f.owner + ']' : '') + (f.overdue ? ' (overdue)' : '')); }).join(', ') + (aff.length > 60 ? ' and ' + (aff.length - 60) + ' more' : '') + '</div></div>';
    });
  } else if (kind === 'plan') {
    h += '<h2>Who owns what, and by when</h2><p class="m">Sorted by urgency: overdue items first, then the nearest due date. Due dates are the standard remediation window unless someone set one by hand.</p>';
    h += '<table><tr><th>Due</th><th>Owner</th><th>Criticality</th><th>Finding</th><th>Device</th></tr>' + open.slice(0, 500).map(function (f) {
      return '<tr><td>' + dueTxt(f) + '</td><td>' + vh(f.owner || 'Unassigned') + '</td><td>' + badge(f.severity) + (xbadge(f) ? '<div>' + xbadge(f) + '</div>' : '') + '</td><td><b>' + vh(f.title) + '</b></td><td>' + vh(f.ip) + (f.hostname ? ' <span class="m">' + vh(f.hostname) + '</span>' : '') + '</td></tr>';
    }).join('') + '</table>' + (open.length > 500 ? '<p class="m">And ' + (open.length - 500) + ' more; use the CSV export for the full list.</p>' : '');
  } else {
    const dev = {}; open.forEach(function (f) { const k = f.site + '|' + f.asset; (dev[k] = dev[k] || { f: f, l: [] }).l.push(f); });
    const ds = Object.keys(dev).map(function (k) { return { f: dev[k].f, l: dev[k].l, s: vscore(dev[k].l) }; }).sort(function (a, b) { return b.s - a.s; }).slice(0, 400);
    h += '<h2>Findings by device</h2>';
    ds.forEach(function (d) {
      h += '<h3>' + vh(d.f.ip) + (d.f.hostname ? ' <span class="m">' + vh(d.f.hostname) + '</span>' : '') + ' <span class="m">&middot; ' + vh([d.f.vendor, d.f.device_type].filter(Boolean).join(' ')) + (d.f.os ? ' &middot; ' + vh(d.f.os) : '') + ' &middot; ' + vh(d.f.site_name) + '</span></h3>'
        + '<table><tr><th style="width:80px">Criticality</th><th>Finding</th><th>Evidence</th><th>Standard resolution</th><th style="width:90px">Status</th><th>Owner / due</th></tr>' + d.l.map(function (f) {
          const r = vulnRule(tenantOfSite(f.site), f.vid) || {};
          return '<tr><td>' + badge(f.severity) + (xbadge(f) ? '<div>' + xbadge(f) + '</div>' : '') + '</td><td><b>' + vh(f.title) + '</b>' + (f.cve.length ? '<div>' + f.cve.map(function (c) { return '<span class="c">' + vh(c) + '</span>'; }).join('') + '</div>' : '') + '</td><td>' + vh(f.evidence) + '<div class="m">' + vh(f.confidence) + '</div></td><td>' + vh((r.fix || [])[0] || '') + '</td><td>' + vh(f.status_label) + '</td><td>' + vh(f.owner || '') + (f.owner && f.due ? '<br>' : '') + dueTxt(f) + '</td></tr>';
        }).join('') + '</table>';
    });
  }
  return h + '<p class="m" style="margin-top:28px">Generated by OTSuraksha Central from what the sensors observed. A finding marked "possible" must be checked on the device.</p></main></body></html>';
}

/* ------------------------------------------------------------------ */
/* Risk assessment: IEC 62443 maturity + NIST CSF 2.0, built from this console's own data */
/* ------------------------------------------------------------------ */
/* The 53 questions are the ones in the IEC 62443 maturity workbook. "Central" = this console can look the answer up and suggests a response;
   "Dispel" = remote-access data from a tool that is not connected to this console (enter it by hand); "Manual" = interview / document review.
   fr = IEC 62443-3-3 foundational requirement(s), sr = the system requirement it relates to, csf = NIST CSF 2.0 subcategory.
   Auto-filled responses are only ever SUGGESTIONS: nothing is recorded until a person applies it. */
const RK_DOMAINS = [
  [1, 'Asset Inventory & Network Visibility', '62443-2-1 / SR 7.8'], [2, 'Network Segmentation & Zone/Conduit Model', '62443-3-3 SR 5.1-5.4'],
  [3, 'Secure Remote Access', '62443-2-4 SP.03.03 / SR 1.13'], [4, 'Identity, Access Management & Authentication', '62443-3-3 SR 1.1-1.7'],
  [5, 'Vulnerability & Patch Management', '62443-2-3 / SR 7.7'], [6, 'Incident Detection, Response & Recovery', '62443-2-1 4.3.4 / SR 6.1-6.2'],
  [7, 'Supply Chain & Third-Party Risk', '62443-2-4 / SR 1.13'], [8, 'Policies, Governance & Security Programme', '62443-2-1 4.2'],
  [9, 'Physical Security & Environmental Controls', '62443-3-3 SR 3.7 / 62443-2-1 4.3.3.4']];
const RK_FR = { 1: 'Identification & authentication control', 2: 'Use control', 3: 'System integrity', 4: 'Data confidentiality', 5: 'Restricted data flow', 6: 'Timely response to events', 7: 'Resource availability' };
const RK_CSF = { GV: 'Govern', ID: 'Identify', PR: 'Protect', DE: 'Detect', RS: 'Respond', RC: 'Recover' };
const RK_LEVELS = ['Level 0 - Initial', 'Level 1 - Developing', 'Level 2 - Defined', 'Level 3 - Managed', 'Level 4 - Optimized'];
const RK_SCORE = { 'Compliant': 1, 'Partial': 0.5, 'Non-Compliant': 0 };
// [no, domain, source, priority, question, where to look, template reference, FR list, SR, CSF 2.0 subcategories]
const RK_Q = [
  [1, 1, 'Central', 'High', 'Do you have a complete, current inventory of ALL OT/ICS assets (PLCs, RTUs, HMIs, engineering workstations, historians, sensors)?', 'Assets tab: device count and device types. Compare with the plant\'s own list of expected devices.', '62443-2-1 4.3.4', [7], 'SR 7.8', ['ID.AM-01']],
  [2, 1, 'Central', 'High', 'Are OT assets categorised by criticality, zone, and conduit per IEC 62443-3-2?', 'Segmentation tab: every device should fall inside a defined zone with a Purdue level.', '62443-3-2', [5], 'SR 5.1', ['ID.AM-05']],
  [3, 1, 'Central', 'High', 'Is firmware version known for all control devices (PLCs, RTUs, DCS)?', 'Assets tab: Firmware column for OT devices. Vulnerabilities tab: "OT device firmware version not identified".', 'SR 7.7', [7], 'SR 7.8', ['ID.AM-01']],
  [4, 1, 'Central', 'High', 'Are end-of-life (EOL) / unsupported devices identified and documented?', 'Vulnerabilities tab: category "Unsupported / end of life". Documented = an owner, note or accepted-risk reason is recorded.', 'SR 7.8', [7], 'SR 7.8', ['ID.AM-08']],
  [5, 1, 'Central', 'High', 'Are all active communication flows between OT zones and IT/cloud networks known and documented?', 'Flows and Segmentation tabs: zone-to-zone conduits, with the firewall rule recorded for each.', '62443-3-2 5', [5], 'SR 5.2', ['ID.AM-03']],
  [6, 1, 'Central', 'Medium', 'Are all wireless devices (Wi-Fi, cellular, Bluetooth) in OT areas inventoried and authorised?', 'Assets tab: wireless access points and wireless devices. Authorisation is confirmed by hand.', 'SR 1.1', [1], 'SR 1.6', ['PR.AA-03']],
  [7, 1, 'Manual', 'Medium', 'Is the asset inventory reviewed and updated on a regular schedule (at minimum quarterly)?', 'Interview: ask the OT/IT team for the last inventory review date and the process document.', '62443-2-1 4.3.4', [7], 'SR 7.8', ['ID.AM-01']],
  [8, 2, 'Central', 'High', 'Is there a documented zone and conduit diagram aligned to IEC 62443-3-2?', 'Segmentation tab: the zone diagram and conduit table. Also request the signed-off architecture document.', '62443-3-2', [5], 'SR 5.1', ['PR.IR-01']],
  [9, 2, 'Central', 'High', 'Are OT/IT boundaries enforced by firewalls or data diodes (not just VLANs)?', 'Segmentation tab: firewall zone per zone and the firewall rule status recorded on each conduit. Request the firewall ruleset export.', 'SR 5.1', [5], 'SR 5.2', ['PR.IR-01']],
  [10, 2, 'Central', 'High', 'Is a DMZ architecture in place between IT and OT layers (historian, remote access, SCADA)?', 'Segmentation and Map tabs: a zone at Purdue level 3.5 that holds devices.', 'SR 5.2', [5], 'SR 5.2', ['PR.IR-01']],
  [11, 2, 'Central', 'High', 'Are industrial protocols (Modbus, DNP3, OPC-UA, EtherNet/IP, PROFINET) restricted to authorised segments only?', 'Segmentation tab: conduits marked "OT protocol reaches Enterprise IT". Flows tab: filter by protocol.', 'SR 5.3', [5], 'SR 5.1', ['PR.IR-01']],
  [12, 2, 'Central', 'High', 'Is network anomaly detection or OT IDS/IPS active in OT segments?', 'Sites tab: sensors online. Policies tab: detection policies enabled. Alerts tab: recent alerts.', 'SR 6.1', [6], 'SR 6.2', ['DE.CM-01']],
  [13, 3, 'Dispel', 'High', 'Are remote access paths (VPN, jump hosts) logically separated from OT network segments?', 'Remote-access tool (not connected to this console). Dispel Sessions tab: target zone column.', 'SR 5.1', [1], 'SR 1.13', ['PR.IR-01']],
  [14, 3, 'Dispel', 'High', 'What remote access methods are currently in use (VPN, RDP, jump server, vendor modem, Dispel)?', 'Remote-access tool: access method column. Central shows the remote-admin ports it can see in traffic.', 'SR 1.13', [1], 'SR 1.13', ['ID.AM-03']],
  [15, 3, 'Dispel', 'High', 'Is multi-factor authentication (MFA) enforced on ALL remote OT access sessions?', 'Remote-access tool: MFA used column; any "No" is a finding.', 'SP.03.03', [1], 'SR 1.1', ['PR.AA-03']],
  [16, 3, 'Dispel', 'High', 'Are vendor/third-party remote sessions time-limited, fully recorded, and auditable?', 'Remote-access tool: session recorded and duration columns.', 'SP.03.03', [2], 'SR 2.8', ['DE.CM-03']],
  [17, 3, 'Dispel', 'High', 'Is remote access granted on a just-in-time (JIT), least-privilege basis, not persistent tunnels?', 'Remote-access tool: access type column; flag "Permanent" or "Always-On".', 'SR 1.3', [2], 'SR 2.1', ['PR.AA-05']],
  [18, 3, 'Central', 'High', 'Are there undocumented/rogue remote access paths (legacy modems, unauthorised VPNs) to OT?', 'Flows tab: remote-admin and VPN ports (SSH, RDP, VNC, Telnet, OpenVPN, IPsec) to or from OT devices and the Internet. Cross-check with the authorised session list.', 'SR 1.13', [1], 'SR 1.13', ['DE.CM-01']],
  [19, 3, 'Dispel', 'Medium', 'Are dormant/unused remote access accounts reviewed and deprovisioned regularly?', 'Remote-access tool: users, last login date; flag 90+ days.', 'SR 1.2', [1], 'SR 1.3', ['PR.AA-01']],
  [20, 3, 'Dispel', 'Medium', 'Is a session recording/replay capability available for post-incident investigation?', 'Remote-access tool: confirm sessions are recorded; ask for a sample replay.', 'SP.03.03', [2], 'SR 2.8', ['RS.AN-03']],
  [21, 4, 'Manual', 'High', 'Is role-based access control (RBAC) implemented on HMIs, engineering workstations, and SCADA servers?', 'Interview: request the RBAC policy; check HMI login screens for role differences.', 'SR 1.1', [2], 'SR 2.1', ['PR.AA-05']],
  [22, 4, 'Manual', 'High', 'Are shared/generic accounts (admin, operator, guest, root) still in use on OT systems?', 'Interview and spot check: list local accounts on sample HMIs / engineering workstations.', 'SR 1.1', [1], 'SR 1.3', ['PR.AA-01']],
  [23, 4, 'Manual', 'High', 'Do OT system passwords meet complexity and rotation requirements?', 'Request: OT password policy; compare with SR 1.5 and SR 1.7.', 'SR 1.5', [1], 'SR 1.5', ['PR.AA-01']],
  [24, 4, 'Dispel', 'Medium', 'Is there a Privileged Access Management (PAM) solution for OT engineer/admin accounts?', 'Remote-access tool: engineer accounts and their roles.', 'SR 1.3', [2], 'SR 2.1', ['PR.AA-05']],
  [25, 4, 'Dispel', 'Medium', 'Are inactive OT user accounts reviewed and removed on a defined schedule?', 'Remote-access tool and the directory (AD/LDAP) OT user export: last login date.', 'SR 1.2', [1], 'SR 1.3', ['PR.AA-01']],
  [26, 4, 'Manual', 'High', 'Is there an OT-specific account provisioning/de-provisioning process (joiners/leavers/movers)?', 'Interview: how is OT access revoked when contractors or staff leave?', 'SR 1.2', [1], 'SR 1.3', ['PR.AA-01']],
  [27, 5, 'Manual', 'High', 'Is there a process for receiving and triaging OT-specific CVE/ICS-CERT advisories?', 'Request: advisory subscription evidence or the internal bulletin process.', '62443-2-3', [3], 'SR 3.4', ['ID.RA-02']],
  [28, 5, 'Central', 'High', 'What is the current average patch latency for critical OT systems (target: under 90 days for critical CVEs)?', 'Vulnerabilities tab: critical and high findings still open, and how long ago each was first seen.', 'SR 7.7', [3], 'SR 3.4', ['PR.PS-02']],
  [29, 5, 'Central', 'High', 'Are compensating controls documented for assets that cannot be patched (legacy PLCs, proprietary firmware)?', 'Vulnerabilities tab: open critical/high findings on OT devices with no owner, note or accepted-risk reason.', 'SR 7.7', [3], 'SR 3.4', ['ID.RA-06']],
  [30, 5, 'Central', 'High', 'Is vulnerability/exposure scanning performed on OT networks (passively, to avoid disruption)?', 'Sites tab: sensor online, and whether it scans passively or actively.', 'SR 7.7', [6], 'SR 6.2', ['ID.RA-01']],
  [31, 5, 'Manual', 'Medium', 'Are software/firmware updates cryptographically verified for integrity before deployment?', 'Request: change management / patch deployment procedure; look for a hash or signature check.', 'SR 3.3', [3], 'SR 3.4', ['PR.DS-06']],
  [32, 5, 'Manual', 'Medium', 'Is there a tested rollback/recovery procedure for failed OT patches?', 'Request: patch rollback procedure; ask when it was last tested.', '62443-2-3', [7], 'SR 7.4', ['PR.PS-02']],
  [33, 6, 'Manual', 'High', 'Is there an OT-specific Incident Response Plan (IRP) separate from the corporate IT IRP?', 'Request: OT IRP; check it covers PLC compromise, historian ransomware and safety-system manipulation.', '62443-2-1 4.3.4', [6], 'SR 6.2', ['RS.MA-01']],
  [34, 6, 'Manual', 'High', 'Are OT security events (sensor alerts, firewall logs) forwarded to a SIEM or SOC for correlation?', 'Ask whether a SIEM/SOC feed exists. This console has no outbound SIEM export; it shows how many alerts it raises.', 'SR 6.1', [6], 'SR 6.1', ['DE.AE-03']],
  [35, 6, 'Manual', 'Medium', 'Have tabletop exercises or drills for OT cyber incidents been conducted in the past 12 months?', 'Request: exercise report or after-action review with date and scenario.', '62443-2-1 4.3.4', [], '62443-2-1', ['ID.IM-02']],
  [36, 6, 'Manual', 'High', 'Are OT system backups tested for restorability and stored in an offline/air-gapped location?', 'Request: backup policy and the last restore test evidence.', 'SR 7.3', [7], 'SR 7.3', ['PR.DS-11', 'RC.RP-03']],
  [37, 6, 'Manual', 'High', 'Are Recovery Time Objective (RTO) and Recovery Point Objective (RPO) defined for critical OT systems?', 'Interview: plant/operations manager; check the business continuity plan.', 'SR 7.6', [7], 'SR 7.4', ['RC.RP-01']],
  [38, 6, 'Manual', 'Medium', 'Is there a defined escalation path from site OT engineer to CISO/executive for cyber incidents?', 'Request: escalation matrix or contact tree with OT contacts.', '62443-2-1 4.3.4', [6], 'SR 6.2', ['RS.CO-02']],
  [39, 7, 'Dispel', 'High', 'Are all vendor remote access rights documented, time-boxed, and mapped to specific OT assets?', 'Remote-access tool: vendor users, access scope and expiry.', '62443-2-4', [1], 'SR 1.13', ['GV.SC-05']],
  [40, 7, 'Manual', 'High', 'Do vendor/integrator contracts include OT cybersecurity requirements aligned to IEC 62443-2-4?', 'Request: a sample vendor contract; look for IEC 62443 clauses.', '62443-2-4', [], '62443-2-4', ['GV.SC-05']],
  [41, 7, 'Manual', 'Medium', 'Is there a formal pre-engagement security assessment process for new OT vendors/integrators?', 'Request: vendor security questionnaire or third-party risk process.', '62443-2-4', [], '62443-2-4', ['GV.SC-06']],
  [42, 7, 'Manual', 'Medium', 'Are vendor-supplied components (PLCs, SCADA software, firmware) security-tested before production deployment?', 'Request: FAT / SAT checklists; look for security test steps.', '62443-2-4', [3], 'SR 3.3', ['ID.RA-09']],
  [43, 7, 'Dispel', 'High', 'Are active vendor sessions monitored in real time during maintenance windows?', 'Remote-access tool: monitored column for vendor sessions.', 'SR 1.13', [6], 'SR 6.2', ['DE.CM-06']],
  [44, 8, 'Manual', 'High', 'Is there a documented OT Cybersecurity Policy, signed off by senior leadership (CISO/COO)?', 'Request: the policy; check signature page and review date.', '62443-2-1 4.2', [], '62443-2-1', ['GV.PO-01']],
  [45, 8, 'Manual', 'High', 'Is a Cyber Security Management System (CSMS) formally defined and implemented per IEC 62443-2-1?', 'Request: CSMS documentation; map it to the 62443-2-1 requirements.', '62443-2-1', [], '62443-2-1', ['GV.PO-01', 'GV.OV-02']],
  [46, 8, 'Manual', 'High', 'Are OT security roles and responsibilities formally assigned (OT Security Owner, site lead, vendor manager)?', 'Request: RACI matrix or org chart with named people.', '62443-2-1 4.2', [], '62443-2-1', ['GV.RR-02']],
  [47, 8, 'Manual', 'Medium', 'Is OT-specific cybersecurity awareness training provided to operations and maintenance staff?', 'Request: training completion records; check it covers OT threats.', '62443-2-1 4.3', [], '62443-2-1', ['PR.AT-01']],
  [48, 8, 'Manual', 'Medium', 'Is there a formal risk assessment methodology applied to OT/ICS environments (HAZOP, Bow-Tie, or cyber risk)?', 'Request: the latest OT cyber risk assessment. The Risk register in this tab can be used as the cyber risk input.', '62443-2-1 4.3', [], '62443-3-2', ['ID.RA-05']],
  [49, 8, 'Central', 'High', 'Are OT security KPIs/metrics tracked and reported to management on a regular basis?', 'Vulnerabilities tab: open critical/high count, overdue findings and the 30-day trend. How often it is reported is confirmed with management.', '62443-3-2', [], '62443-2-1', ['GV.OV-03']],
  [50, 9, 'Manual', 'Medium', 'Are OT control rooms, server rooms, and field device panels physically restricted to authorised personnel only?', 'Site walk / interview: badge access, CCTV or key locks on control rooms and panels.', '62443-2-1 4.4', [], '62443-2-1', ['PR.AA-06']],
  [51, 9, 'Manual', 'High', 'Are USB ports and removable media access disabled or controlled on OT endpoints (HMIs, EWS)?', 'Check endpoint policy on sample HMIs / EWS. This console does not see USB activity.', 'SR 3.7', [2], 'SR 2.3', ['PR.PS-01']],
  [52, 9, 'Manual', 'Medium', 'Are portable engineering laptops/programming devices subject to security controls (AV, patching, approval) before connecting to OT?', 'Request: portable device procedure; ask how laptops are cleared before plugging into a PLC.', '62443-2-1 4.3.3.4', [2], 'SR 2.3', ['PR.PS-01']],
  [53, 9, 'Manual', 'Low', 'Is there a clear-desk / clean-screen policy enforced in OT control rooms?', 'Site walk: unattended logged-in HMIs or printed passwords in control rooms.', '62443-2-1 4.3.3.4', [], '62443-2-1', ['PR.AA-06']]
].map(function (r) { return { n: r[0], d: r[1], src: r[2], pri: r[3], q: r[4], where: r[5], ref: r[6], fr: r[7], sr: r[8], csf: r[9] }; });
const RK_QBY = {}; RK_Q.forEach(function (q) { RK_QBY[q.n] = q; });

const RK_LV = ['0', '1', '2', '3', '3.5', '4'];
const RK_OT = { 502: 'Modbus', 102: 'Siemens S7', 44818: 'EtherNet/IP', 2222: 'EtherNet/IP', 20000: 'DNP3', 2404: 'IEC-104', 4840: 'OPC UA', 47808: 'BACnet', 34962: 'PROFINET', 18245: 'GE SRTP' };
const RK_ADMIN = { 23: 'Telnet', 21: 'FTP', 69: 'TFTP', 445: 'SMB', 139: 'NetBIOS', 135: 'Windows RPC', 3389: 'RDP', 5900: 'VNC', 161: 'SNMP' };
const RK_CLEAR = { 23: 1, 21: 1, 69: 1 };
const RK_REMOTE = { 22: 'SSH', 23: 'Telnet', 3389: 'RDP', 5900: 'VNC', 1194: 'OpenVPN', 4500: 'IPsec', 500: 'IPsec', 1723: 'PPTP' };
const RK_DANGER = ['stop', 'program', 'control', 'write'];
const RK_IMPACT = { '0': 5, '1': 5, '2': 4, '3': 3, '3.5': 3, '4': 2, 'U': 3 };
const RK_OUT = 'Outside zones';        // same name the Segmentation tab uses, so firewall rules recorded there match
const RK_TREAT = ['', 'mitigate', 'accept', 'transfer', 'avoid'], RK_TSTAT = ['open', 'in_progress', 'accepted', 'closed'];
const RK_CACHE = new Map();
// which assessment domain's maturity lowers the likelihood of each kind of risk
const RK_RDOM = { VULN: 5, EOL: 5, SEG: 2, ADMIN: 4, EXT: 3, VIS: 1, ALERT: 6, CMD: 6, MON: 6 };
const RK_ACT = {
  VULN: 'Patch or apply the vendor mitigation in the next maintenance window, starting with anything in the CISA Known Exploited catalog. For devices that cannot be patched, record compensating controls (segmentation, allow-listing) and accept the risk with a reason on the Vulnerabilities tab.',
  EOL: 'Plan replacement. Until then keep unsupported devices in their own zone behind a firewall and record the compensating controls.',
  SEG: 'Block or restrict the flagged conduits on the firewall, put a DMZ at Purdue level 3.5 between IT and OT, and record each firewall rule on the Segmentation tab.',
  ADMIN: 'Disable the service or limit it to a jump host. Replace Telnet and FTP with SSH and SFTP. Use a managed remote-access gateway with MFA for engineers and vendors.',
  EXT: 'Remove direct Internet paths to control-level devices. Route required vendor access through a controlled remote-access gateway in the DMZ.',
  VIS: 'Define the zone on the Segmentation tab with a Purdue level and firewall zone, then identify each unclassified device (owner, model, firmware).',
  ALERT: 'Work the alerts on the Alerts tab. If confirmed, contain the device and follow the OT incident response plan.',
  CMD: 'Confirm with the control engineer that the commands were authorised. Allow only known engineering workstations to reach the controllers and use the controller\'s run-mode / key-switch protection.',
  MON: 'Bring the sensor back online (Sites tab), enable detection policies, and add a second sensor if a zone is not covered.'
};
function rkBand(s) { return s >= 20 ? 'critical' : s >= 12 ? 'high' : s >= 6 ? 'medium' : 'low'; }
function rkSltOf(imp) { return imp >= 5 ? 3 : imp >= 3 ? 2 : 1; }
function rkMLevel(m) { return m === null || m === undefined ? 'No data' : RK_LEVELS[m < 0.25 ? 0 : m < 0.5 ? 1 : m < 0.75 ? 2 : m < 0.9 ? 3 : 4]; }
function rkState(sid, create) {
  const all = DB.risk || (DB.risk = {});
  if (!all[sid] && create) all[sid] = { answers: {}, meta: {}, zt: {}, treat: {}, manual: [], seq: 1, auto: true };
  return all[sid] || { answers: {}, meta: {}, zt: {}, treat: {}, manual: [], seq: 1 };
}
/* conduit verdict: the same rules the Segmentation tab uses in the browser */
function rkJudge(e) {
  const n = function (x) { return x === 'X' ? 9 : RK_LV.indexOf(x); }, R = { OK: 0, Medium: 1, High: 2 };
  let sev = 'OK'; const w = [], tg = [];
  const add = function (s, t, g) { w.push(t); if (tg.indexOf(g) === -1) tg.push(g); if (R[s] > R[sev]) sev = s; };
  const ext = e.fl === 'X' || e.tl === 'X', inner = e.fl === 'X' ? e.tl : e.fl, known = e.fl !== 'U' && e.tl !== 'U';
  if (!known) add('High', 'An endpoint is outside every defined zone', 'unzoned');
  else if (!ext && Math.abs(n(e.fl) - n(e.tl)) > 1) add('High', 'Skips the DMZ / levels: L' + e.fl + ' talks directly to L' + e.tl, 'skip');
  if (ext && known && n(inner) <= 3) add('High', 'Direct Internet communication with a control-level zone (L' + inner + ')', 'ext');
  if (RK_ADMIN[e.port]) add(known && Math.min(n(e.fl), n(e.tl)) <= 3 ? 'High' : 'Medium', RK_ADMIN[e.port] + ' (admin / legacy protocol) crosses zones', 'admin');
  if (e.otp && (e.fl === '4' || e.tl === '4' || ext)) add('High', e.otp + ' (OT protocol) reaches ' + (ext ? 'the Internet' : 'Enterprise IT'), 'ot-it');
  if (!w.length) w.push('Adjacent levels. Keep only if the business need is documented');
  e.sev = sev; e.why = w.join('; '); e.tags = tg;
}
function rkChk(e, r) {      // the verdict above is a guess from built-in rules; this compares it with the firewall rule a person recorded
  const st = r && r.st || '', s = e.sev;
  if (!st) return s === 'OK' ? ['', ''] : ['Medium', 'Record the firewall rule'];
  if (st === 'allowed') return s === 'High' ? ['High', 'Allowed but high risk: review or block'] : s === 'Medium' ? ['Medium', 'Allowed but flagged: confirm it is needed'] : ['OK', 'Allowed, low risk'];
  if (st === 'blocked') return [s === 'High' ? 'High' : 'Medium', 'Traffic is still seen: check rule order, or whether the sensor sits before the firewall'];
  return [s === 'High' ? 'High' : 'Medium', 'Change still open'];
}
const rkPct = function (a, b) { return b ? Math.round(100 * a / b) : 0; };
const rkList = function (a, n) { return a.length > n ? a.slice(0, n).join(', ') + ' and ' + (a.length - n) + ' more' : a.join(', '); };

/* Everything that comes from live data (cached for 20 s). The person's answers are NOT in here: see rkCompose. */
function rkBuild(sid) {
  const now = Date.now() / 1000, site = DB.sites[sid] || {};
  const A = Object.values(DB.assets[sid] || {}).filter(function (a) { return !a.gone; }), hasOt = A.some(function (a) { return a.ot; });
  let hub = '';
  A.forEach(function (a) { if (!hub && /\.1$/.test(a.ip || '')) hub = a.id; });
  A.forEach(function (a) { if (!hub && /router|gateway|firewall/i.test(a.device_type || '')) hub = a.id; });
  const zs = zonesOfSite(sid), zdefs = (DB.zones || {})[sid] || [], assets = [], byIp = {}, byId = {};
  A.forEach(function (a) {
    const seg = assetSeg(sid, a), host = (a.hostnames || [])[0] || '';
    const guess = a.id === hub ? '3.5' : purdue({ device_type: a.device_type, hn: host, ot: a.ot, protocols: a.protocols }, hasOt);
    const o = { id: a.id, ip: a.ip || '', host: host, type: a.device_type || '', ot: !!a.ot, fw: a.firmware || '', os: a.os || '', protos: a.protocols || [], guess: guess, zone: seg.seg_zone || '',
      ports: ((a.data && a.data.listening_ports) || []).map(function (x) { return parseInt(x, 10); }).filter(Boolean), last: a.last_seen || '',
      control: !!a.ot || /plc|rtu|controller/i.test(a.device_type || ''), wireless: /access point|wireless|wi-?fi|\bap\b|cellular|\blte\b|bluetooth/i.test(a.device_type || ''),
      unclass: !String(a.device_type || '').trim() || /^(unknown|unclassified|other|generic)\b/i.test(String(a.device_type || '').trim()) };
    assets.push(o); byId[a.id] = o; if (o.ip) byIp[o.ip] = o;
  });
  const Z = {}, zget = function (name, level, prov) { return Z[name] || (Z[name] = { name: name, level: level, provisional: !!prov, specs: [], fw: [], assets: [] }); };
  zdefs.forEach(function (z) {
    if (!z || !z.name) return;
    const o = zget(z.name, String(z.level || '4'));
    if (z.spec) o.specs.push(z.spec);
    if (z.vlans) o.specs.push('VLAN ' + z.vlans);
    if (z.fw && o.fw.indexOf(z.fw) === -1) o.fw.push(z.fw);
  });
  assets.forEach(function (o) {
    let zn = o.zone;
    if (!zn) { const m = !zs && /^(\d+\.\d+\.\d+)\.\d+$/.exec(o.ip); zn = m ? '(provisional) ' + m[1] + '.x' : RK_OUT; }
    o.zone = zn; zget(zn, zn === RK_OUT ? 'U' : '4', zn !== RK_OUT && !zs).assets.push(o);
  });
  Object.keys(Z).forEach(function (k) {
    const z = Z[k]; if (!z.provisional) return;
    const c = {}; z.assets.forEach(function (o) { if (o.guess !== 'U') c[o.guess] = (c[o.guess] || 0) + 1; });
    z.level = Object.keys(c).sort(function (a, b) { return c[b] - c[a]; })[0] || 'U';
  });
  const zonedN = zs ? assets.filter(function (o) { return o.zone !== RK_OUT; }).length : 0;
  const zoneOfIp = function (ip) {
    const o = byIp[ip]; if (o) return { name: o.zone, level: Z[o.zone].level };
    if (isExtIp(ip)) return { name: 'Internet', level: 'X' };
    if (zs) { const z = zoneFor(sid, ip, []); if (z) return { name: z.name, level: String(z.level || '4') }; }
    return { name: RK_OUT, level: 'U' };
  };
  /* conduits: zone-to-zone traffic, one row per from-zone, to-zone and port */
  const F = Object.values(DB.flows[sid] || {}), RU = (DB.fwrules || {})[sid] || {}, C = {}, extEv = [];
  let intra = 0, otFlows = 0;
  F.forEach(function (f) {
    if (f.ot) otFlows++;
    const a = zoneOfIp(f.client), b = zoneOfIp(f.server), port = parseInt(f.port, 10) || 0;
    if (a.name === b.name) { intra++; return; }
    if (a.level === 'X' && b.level === 'X') return;
    const key = a.name + '|' + b.name + '|' + port, e = C[key] || (C[key] = { key: key, from: a.name, to: b.name, fl: a.level, tl: b.level, port: port, svc: RK_OT[port] || RK_ADMIN[port] || RK_REMOTE[port] || '', n: 0, flows: 0, otp: '', ex: [] });
    e.n += f.packets || 1; e.flows++;
    if (RK_OT[port]) e.otp = RK_OT[port]; else if (f.ot && !e.otp) e.otp = f.proto || 'OT protocol';
    if (e.ex.length < 3) e.ex.push(f.client + ' > ' + f.server);
    if (a.level === 'X' || b.level === 'X') extEv.push({ zone: a.level === 'X' ? b.name : a.name, asset: byIp[a.level === 'X' ? f.server : f.client], port: port, ot: !!f.ot });
  });
  const conduits = Object.values(C);
  conduits.forEach(function (e) { rkJudge(e); e.rule = RU[e.key] ? { st: RU[e.key].st || '', note: RU[e.key].note || '' } : { st: '', note: '' }; const c = rkChk(e, RU[e.key]); e.chk = { sev: c[0], text: c[1] }; });
  const sevR = { High: 2, Medium: 1, OK: 0 };
  conduits.sort(function (x, y) { return sevR[y.sev] - sevR[x.sev] || y.n - x.n; });
  /* vulnerabilities, alerts, commands per zone */
  const V = vulnAll(new Set([sid]), ''), ZS = {};
  const zs0 = function (name) { return ZS[name] || (ZS[name] = { crit: 0, high: 0, med: 0, kev: 0, weap: 0, vdevs: {}, eol: 0, eolCrit: 0, eolDevs: {}, alerts: 0, alertCrit: 0, cmds: 0, cmdStop: 0, cmdOut: 0, cmdEx: [], ext: 0, extOt: 0, extPorts: {}, adminAssets: [], adminPorts: {}, clear: false, adminOt: false, conduitsHigh: [] }); };
  const vm = { crit: 0, high: 0, med: 0, kev: 0, overdue: 0, chOpen: 0, old90: 0, ages: [], oldest: 0, otCh: 0, otChDoc: 0, eol: 0, eolDoc: 0, total: V.length };
  V.forEach(function (f) {
    if (!VOPEN(f.status)) return;
    const o = byId[f.asset], z = o ? zs0(o.zone) : null, doc = f.status !== 'open' || !!f.owner || !!f.note;
    if (f.overdue) vm.overdue++;
    if (f.cat === 'eol') { vm.eol++; if (doc) vm.eolDoc++; if (z) { z.eol++; if (f.severity === 'critical') z.eolCrit++; z.eolDevs[f.asset] = 1; } }
    else if (z) {
      if (f.severity === 'critical') z.crit++; else if (f.severity === 'high') z.high++; else if (f.severity === 'medium') z.med++;
      if (f.kev) z.kev++; if (f.maturity === 'weaponized') z.weap++;
      if (f.severity === 'critical' || f.severity === 'high') z.vdevs[f.asset] = 1;
    }
    if (f.severity === 'critical') vm.crit++; else if (f.severity === 'high') vm.high++; else if (f.severity === 'medium') vm.med++;
    if (f.kev) vm.kev++;
    if (f.severity === 'critical' || f.severity === 'high') {
      vm.chOpen++; const age = Math.max(0, (now - f.first_seen) / 86400); vm.ages.push(age); if (age > 90) vm.old90++;
      if (o && o.control) { vm.otCh++; if (doc) vm.otChDoc++; }
    }
  });
  vm.oldest = vm.ages.length ? Math.round(Math.max.apply(null, vm.ages)) : 0; vm.avg = vm.ages.length ? Math.round(vm.ages.reduce(function (s, x) { return s + x; }, 0) / vm.ages.length) : 0; delete vm.ages;
  const alerts = Object.values(DB.alerts[sid] || {}), openAl = alerts.filter(function (x) { return x.status === 'new'; });
  const am = { total: alerts.length, open: openAl.length, crit: openAl.filter(function (x) { return x.sev === 4; }).length, high: openAl.filter(function (x) { return x.sev === 3; }).length };
  openAl.filter(function (x) { return x.sev >= 3; }).forEach(function (x) {
    const seen = {}; [x.src, x.dst].forEach(function (k) { const o = byIp[k] || byId[k]; if (o && !seen[o.zone]) { seen[o.zone] = 1; const z = zs0(o.zone); z.alerts++; if (x.sev === 4) z.alertCrit++; } });
  });
  let cmdN = 0;
  (ACT[sid] || []).forEach(function (r) {
    if (RK_DANGER.indexOf(r.cat) === -1) return;
    const t = byIp[r.dst]; if (!t || !t.ot) return;
    cmdN++; const z = zs0(t.zone), sl = zoneOfIp(r.src).level;
    z.cmds++; if (r.cat === 'stop' || r.cat === 'program') z.cmdStop++; if (sl === '4' || sl === 'U' || sl === 'X') z.cmdOut++;
    if (z.cmdEx.length < 3) z.cmdEx.push((r.func || r.cat) + ' ' + r.src + ' > ' + r.dst);
  });
  extEv.forEach(function (x) {
    const z = zs0(x.zone), lv = Z[x.zone] ? Z[x.zone].level : 'U';
    if (!x.asset || !(x.asset.control || RK_LV.indexOf(lv) <= 3 && RK_LV.indexOf(lv) >= 0)) return;
    z.ext++; if (x.asset.ot || RK_OT[x.port]) z.extOt++; z.extPorts[RK_REMOTE[x.port] || RK_ADMIN[x.port] || RK_OT[x.port] || (x.port ? 'port ' + x.port : 'other')] = 1;
  });
  assets.forEach(function (o) {
    o.ports.forEach(function (p) {
      if (!RK_ADMIN[p]) return;
      const z = zs0(o.zone); z.adminPorts[RK_ADMIN[p]] = (z.adminPorts[RK_ADMIN[p]] || 0) + 1;
      if (z.adminAssets.indexOf(o.ip || o.id) === -1) z.adminAssets.push(o.ip || o.id);
      if (RK_CLEAR[p]) z.clear = true; if (o.control) z.adminOt = true;
    });
  });
  conduits.forEach(function (e) { if (e.sev !== 'High') return; [e.from, e.to].forEach(function (n) { if (Z[n]) zs0(n).conduitsHigh.push(e); }); });
  /* sensor and policies */
  const mt = site.meta || {}, status = siteStatus(site, now), scanMode = site.scan_mode || mt.scan_mode || '';
  const pols = (DB.policies || []).filter(function (p) { return p.enabled && (!p.tenant || p.tenant === site.tenant) && (!(p.sites || []).length || p.sites.indexOf(sid) !== -1); }).length;
  const recorded = conduits.filter(function (e) { return e.rule.st; }).length;
  const isBoundary = function (e) { const hi = function (x) { return x === '4' || x === 'X' || x === 'U'; }, lo = function (x) { return RK_LV.indexOf(x) >= 0 && RK_LV.indexOf(x) <= 4 && x !== '4'; }; return (hi(e.fl) && lo(e.tl)) || (hi(e.tl) && lo(e.fl)); };
  const bnd = conduits.filter(isBoundary), controlN = assets.filter(function (o) { return o.control; }).length;
  const eolList = V.filter(function (f) { return f.cat === 'eol'; });
  const remAdmin = conduits.filter(function (e) { return e.tags.indexOf('admin') !== -1 && Z[e.to] && RK_LV.indexOf(Z[e.to].level) >= 0 && RK_LV.indexOf(Z[e.to].level) <= 3; });
  const M = {
    assets: assets.length, ot: assets.filter(function (o) { return o.ot; }).length, unclass: assets.filter(function (o) { return o.unclass; }).length, control: controlN, fwKnown: assets.filter(function (o) { return o.control && o.fw; }).length,
    zones: zs ? Object.keys(Z).filter(function (k) { return !Z[k].provisional && k !== RK_OUT; }).length : 0, zoned: zonedN, wireless: assets.filter(function (o) { return o.wireless; }).length,
    flows: F.length, otFlows: otFlows, intra: intra, conduits: conduits.length, recorded: recorded, high: conduits.filter(function (e) { return e.sev === 'High'; }).length, otIt: conduits.filter(function (e) { return e.tags.indexOf('ot-it') !== -1; }).length,
    boundary: bnd.length, boundaryRec: bnd.filter(function (e) { return e.rule.st; }).length, boundaryOpen: bnd.filter(function (e) { return e.rule.st === 'change' || e.chk.sev === 'High'; }).length,
    fwZones: Object.keys(Z).filter(function (k) { return Z[k].fw.length; }).length, dmz: Object.keys(Z).filter(function (k) { return Z[k].level === '3.5' && !Z[k].provisional; }).length, dmzDev: Object.keys(Z).filter(function (k) { return Z[k].level === '3.5' && !Z[k].provisional && Z[k].assets.length; }).length,
    extOt: extEv.filter(function (x) { return x.asset && (x.asset.control || x.asset.ot); }).length, remAdmin: remAdmin.length, remAdminPorts: rkList(Object.keys(remAdmin.reduce(function (o, e) { o[RK_ADMIN[e.port]] = 1; return o; }, {})), 4),
    status: status, seen: !!site.last_seen, age: site.last_seen ? Math.floor(now - site.last_seen) : null, scan: scanMode, policies: pols, alerts: am, vulns: vm, cmds: cmdN,
    eolTotal: vm.eol, eolDoc: vm.eolDoc, eolAll: eolList.length, hub: hub ? 1 : 0 };
  /* the risks that come from data: one scenario per zone it applies to */
  const risks = [];
  Object.keys(Z).forEach(function (name) {
    const z = Z[name], s = ZS[name] || zs0(name), lv = z.level, ctl = RK_LV.indexOf(lv) >= 0 && RK_LV.indexOf(lv) <= 3;
    const exposed = s.conduitsHigh.length > 0 || s.ext > 0, add = function (code, title, scen, ev, L, lf, fr, sr, csf) {
      risks.push({ id: code + '|' + name, code: code, zone: name, level: lv, title: title, scenario: scen, evidence: ev, L: Math.max(1, Math.min(5, L)), lf: lf, fr: fr, sr: sr, csf: csf, dom: RK_RDOM[code], action: RK_ACT[code], src: 'auto' });
    };
    const nv = Object.keys(s.vdevs).length;
    if (s.crit + s.high > 0) {
      const lf = ['2 base: open critical/high vulnerabilities'];
      let L = 2; if (s.crit) { L++; lf.push('+1 critical finding'); } if (s.kev || s.weap) { L++; lf.push('+1 actively exploited or exploit code is public'); } if (exposed) { L++; lf.push('+1 zone is reachable through a high-risk conduit or from the Internet'); }
      add('VULN', 'Exploitation of known vulnerabilities', 'An attacker or malware that reaches this zone uses a known weakness to take control of, or disrupt, a device.',
        s.crit + ' critical and ' + s.high + ' high findings on ' + nv + ' device(s)' + (s.kev ? ', ' + s.kev + ' in the CISA Known Exploited catalog' : '') + (s.weap ? ', ' + s.weap + ' with public exploit code' : '') + '.', L, lf, [3, 5], 'SR 3.2, SR 3.4, SR 5.1', ['ID.RA-01', 'PR.PS-02']);
    }
    if (s.eol > 0) {
      const lf = ['2 base: unsupported components present']; let L = 2; if (s.eolCrit) { L++; lf.push('+1 a critical unsupported system'); } if (exposed) { L++; lf.push('+1 zone is reachable through a high-risk conduit or from the Internet'); } if (z.assets.length && s.eol >= Math.max(3, z.assets.length / 4)) { L++; lf.push('+1 many devices are affected'); }
      add('EOL', 'Unsupported / end-of-life components', 'No security fixes exist for these devices, so any weakness found stays open for the life of the device.',
        s.eol + ' end-of-life or unsupported finding(s) on ' + Object.keys(s.eolDevs).length + ' device(s).', L, lf, [7, 3], 'SR 7.8, SR 3.4', ['ID.AM-08', 'PR.PS-02']);
    }
    if (s.conduitsHigh.length) {
      const hi = s.conduitsHigh, tags = {}; hi.forEach(function (e) { e.tags.forEach(function (t) { tags[t] = 1; }); });
      const lf = ['2 base: high-risk conduit']; let L = 2;
      if (hi.length >= 3) { L++; lf.push('+1 three or more high-risk conduits'); } if (tags['ot-it'] || tags.ext) { L++; lf.push('+1 an OT protocol or the Internet crosses the boundary'); }
      if (hi.filter(function (e) { return !e.rule.st; }).length * 2 > hi.length) { L++; lf.push('+1 no firewall rule is recorded for most of them'); }
      add('SEG', 'Weak zone boundary', 'Traffic crosses a zone boundary that should be tighter, so a compromise elsewhere can spread into or out of this zone.',
        hi.length + ' high-risk conduit(s): ' + rkList(hi.map(function (e) { return e.from + ' > ' + e.to + (e.svc ? ' (' + e.svc + ')' : e.port ? ' (port ' + e.port + ')' : ''); }), 3) + '.', L, lf, [5], 'SR 5.1, SR 5.2', ['PR.IR-01']);
    }
    if (s.adminAssets.length) {
      const lf = ['2 base: remote-admin or legacy service open']; let L = 2;
      if (s.clear) { L++; lf.push('+1 clear-text login (Telnet / FTP / TFTP)'); } if (s.adminOt) { L++; lf.push('+1 on an OT / control device'); } if (s.conduitsHigh.some(function (e) { return e.tags.indexOf('admin') !== -1; })) { L++; lf.push('+1 reachable from another zone'); }
      add('ADMIN', 'Remote-admin and clear-text services exposed', 'Services meant for administration or legacy transfer are open, and can be used to log in, read credentials or move files.',
        Object.keys(s.adminPorts).map(function (k) { return k + ' x' + s.adminPorts[k]; }).join(', ') + ' open on ' + rkList(s.adminAssets, 4) + '.', L, lf, [1, 4], 'SR 1.13, SR 4.1, SR 7.7', ['PR.AA-03', 'PR.DS-02']);
    }
    if (s.ext > 0) {
      const lf = ['3 base: direct Internet traffic with a control-level device']; let L = 3;
      if (s.extOt) { L++; lf.push('+1 involves an OT device or OT protocol'); } if (Object.keys(s.extPorts).some(function (k) { return /SSH|Telnet|RDP|VNC|OpenVPN|IPsec|PPTP/.test(k); })) { L++; lf.push('+1 remote-access protocol'); }
      add('EXT', 'Direct Internet communication', 'Control-level devices talk to the Internet without passing a DMZ or remote-access gateway.', s.ext + ' flow(s) with Internet addresses (' + Object.keys(s.extPorts).slice(0, 5).join(', ') + ').', L, lf, [5, 1], 'SR 5.2, SR 1.13', ['PR.IR-01', 'DE.CM-01']);
    }
    const un = z.assets.filter(function (o) { return o.unclass; }).length;
    if (name === RK_OUT && z.assets.length || (z.assets.length >= 3 && un * 4 >= z.assets.length)) {
      const lf = []; let L = 2; lf.push('2 base: devices not fully identified or not inside a zone');
      if (name === RK_OUT) { L += 2; lf.push('+2 devices are outside every defined zone'); } if (un * 2 >= z.assets.length) { L++; lf.push('+1 half or more are unclassified'); }
      add('VIS', name === RK_OUT ? 'Devices outside every defined zone' : 'Unclassified devices', 'Devices that are not identified or not placed in a zone cannot be protected by zone rules and are easy to miss in an incident.',
        z.assets.length + ' device(s)' + (name === RK_OUT ? ' outside every zone' : '') + ', ' + un + ' not classified.', L, lf, [7, 5], 'SR 7.8, SR 5.1', ['ID.AM-01', 'ID.AM-02']);
    }
    if (s.alerts > 0) {
      const lf = ['3 base: unresolved high or critical alerts']; let L = 3; if (s.alertCrit) { L++; lf.push('+1 a critical alert'); } if (s.alerts >= 5) { L++; lf.push('+1 five or more alerts'); }
      add('ALERT', 'Unresolved high / critical alerts', 'The sensors have seen behaviour that matches an attack or a serious policy breach and nobody has closed it.', s.alerts + ' open high or critical alert(s)' + (s.alertCrit ? ', ' + s.alertCrit + ' critical' : '') + '.', L, lf, [6], 'SR 6.2', ['DE.AE-02', 'RS.MA-01']);
    }
    if (s.cmds > 0) {
      const lf = ['2 base: process-affecting commands seen']; let L = 2; if (s.cmdStop) { L++; lf.push('+1 stop or program-change commands'); } if (s.cmdOut) { L++; lf.push('+1 sent from Enterprise IT, the Internet or an unzoned address'); } if (s.cmds >= 20) { L++; lf.push('+1 twenty or more commands'); }
      add('CMD', 'Process-affecting commands on controllers', 'Stop, program, control or write commands reached OT devices. They may be normal engineering work, or an attacker changing the process.', s.cmds + ' command(s) in the retained activity history, e.g. ' + s.cmdEx.join('; ') + '.', L, lf, [2, 3], 'SR 2.1, SR 3.4', ['DE.CM-01', 'PR.AA-05']);
    }
  });
  if (status !== 'online' || pols === 0) {
    const lf = ['3 base: monitoring is weaker than it should be']; let L = 3;
    if (!M.seen) { L += 2; lf.push('+2 the sensor has never reported'); } else if (status !== 'online' && M.age > 86400) { L++; lf.push('+1 sensor offline for more than a day'); }
    risks.push({ id: 'MON|Site', code: 'MON', zone: 'Site (all zones)', level: '', title: status !== 'online' ? 'Sensor offline: no monitoring' : 'No detection policies enabled', scenario: 'While the sensor is offline or no policy is enabled, an attack on any zone is not seen.',
      evidence: (status !== 'online' ? (M.seen ? 'Sensor last reported ' + Math.round(M.age / 3600) + ' h ago. ' : 'The sensor has never reported. ') : '') + pols + ' detection polic' + (pols === 1 ? 'y' : 'ies') + ' enabled.', L: Math.min(5, L), lf: lf, fr: [6], sr: 'SR 6.1, SR 6.2', csf: ['DE.CM-01'], dom: 6, action: RK_ACT.MON, src: 'auto' });
  }
  /* suggested responses for the assessment questions that this console can answer */
  const sg = {}, put = function (n, s, b) { sg[n] = { s: s, basis: b }; };
  const as = M.assets, cls = rkPct(as - M.unclass, as);
  if (!as) put(1, 'Non-Compliant', 'No devices have been discovered at this site yet.');
  else put(1, cls < 50 ? 'Non-Compliant' : 'Partial', as + ' devices discovered (' + M.ot + ' OT), ' + cls + '% identified by type. Sensor ' + status + '. Compare with the plant\'s list of expected devices before marking Compliant.');
  if (!M.zones) put(2, 'Non-Compliant', 'No zones are defined on the Segmentation tab' + (as ? ', so none of the ' + as + ' devices has a zone.' : '.'));
  else { const p = rkPct(zonedN, as); put(2, p >= 95 ? 'Compliant' : p >= 50 ? 'Partial' : 'Non-Compliant', M.zones + ' zone(s) defined; ' + zonedN + ' of ' + as + ' devices (' + p + '%) fall inside one. Each zone has a Purdue level.'); }
  if (!controlN) put(3, '', 'No OT / control devices seen yet.');
  else { const p = rkPct(M.fwKnown, controlN); put(3, p >= 90 ? 'Compliant' : p >= 40 ? 'Partial' : 'Non-Compliant', M.fwKnown + ' of ' + controlN + ' OT / control devices (' + p + '%) have a known firmware version.'); }
  if (!vm.eol) put(4, 'Compliant', 'No unsupported or end-of-life findings are open.');
  else put(4, vm.eolDoc === vm.eol ? 'Compliant' : vm.eolDoc > 0 ? 'Partial' : 'Non-Compliant', vm.eol + ' open unsupported / end-of-life finding(s); ' + vm.eolDoc + ' have an owner, note or accepted-risk reason recorded.');
  if (!F.length) put(5, 'Non-Compliant', 'No traffic flows have been captured, so communication paths are not known.');
  else { const p = rkPct(recorded, conduits.length); let s = p >= 80 ? 'Compliant' : 'Partial'; if (!M.zones) s = 'Partial'; if (M.extOt > 0 && s === 'Compliant') s = 'Partial';
    put(5, s, F.length + ' flows seen, ' + conduits.length + ' zone-to-zone conduits, ' + recorded + ' with a firewall rule recorded (' + p + '%).' + (M.extOt ? ' ' + M.extOt + ' flow(s) between control-level devices and the Internet.' : '') + (M.zones ? '' : ' Define zones to see real zone-to-zone paths.')); }
  if (!M.wireless) put(6, '', 'No wireless access points or wireless devices identified.');
  else put(6, 'Partial', M.wireless + ' wireless device(s) found. Confirm each one is authorised.');
  if (M.zones >= 2) put(8, rkPct(recorded, conduits.length) >= 80 && conduits.length ? 'Compliant' : 'Partial', M.zones + ' zones with Purdue levels and ' + conduits.length + ' conduits are modelled on the Segmentation tab; ' + recorded + ' conduits have a firewall rule recorded. Also request the signed-off diagram.');
  else put(8, M.zones ? 'Partial' : 'Non-Compliant', M.zones ? 'Only one zone is defined, so there is no zone and conduit model yet.' : 'No zones are defined on the Segmentation tab.');
  if (!bnd.length) put(9, '', 'No traffic crosses the IT / OT boundary yet' + (M.zones ? '.' : ', or zones are not defined.'));
  else if (!M.boundaryRec && !M.fwZones) put(9, '', bnd.length + ' conduit(s) cross the IT / OT boundary, but no firewall rule or firewall zone is recorded, so enforcement cannot be told from here.');
  else put(9, M.boundaryRec === bnd.length && !M.boundaryOpen ? 'Compliant' : 'Partial', bnd.length + ' conduit(s) cross the IT / OT boundary; ' + M.boundaryRec + ' have a firewall rule recorded' + (M.boundaryOpen ? ', ' + M.boundaryOpen + ' still flagged' : '') + '. ' + M.fwZones + ' zone(s) have a firewall zone. Request the ruleset to confirm.');
  if (!M.zones) put(10, '', 'Define zones first (Segmentation tab).');
  else put(10, M.dmzDev ? 'Compliant' : M.dmz ? 'Partial' : 'Non-Compliant', M.dmzDev ? M.dmzDev + ' zone(s) at Purdue level 3.5 hold devices.' : M.dmz ? 'A level 3.5 zone is defined but holds no devices.' : 'No zone is defined at Purdue level 3.5 (Gateway / DMZ).');
  if (!otFlows) put(11, '', 'No industrial-protocol traffic has been seen.');
  else if (!M.zones) put(11, '', otFlows + ' industrial-protocol flows seen. Define zones to check where they travel.');
  else put(11, M.otIt === 0 ? 'Compliant' : M.otIt <= 2 ? 'Partial' : 'Non-Compliant', M.otIt === 0 ? otFlows + ' industrial-protocol flows, none reach Enterprise IT or the Internet.' : M.otIt + ' conduit(s) carry an OT protocol to Enterprise IT or the Internet.');
  if (!M.seen) put(12, 'Non-Compliant', 'The sensor has never reported.');
  else put(12, status === 'online' && pols > 0 ? 'Compliant' : 'Partial', 'Sensor ' + status + '; ' + pols + ' detection polic' + (pols === 1 ? 'y' : 'ies') + ' enabled; ' + am.total + ' alerts raised (' + am.open + ' open).');
  put(14, '', Object.keys(RK_REMOTE).map(function (p) { const n = conduits.filter(function (e) { return e.port === +p; }).length + assets.filter(function (o) { return o.ports.indexOf(+p) !== -1; }).length; return n ? RK_REMOTE[p] + ' (' + n + ')' : ''; }).filter(Boolean).join(', ') || 'No remote-access ports seen in traffic or on devices.');
  if (!F.length) put(18, '', 'No traffic flows captured yet.');
  else if (M.extOt) put(18, 'Non-Compliant', M.extOt + ' flow(s) between control-level devices and the Internet' + '. Compare with the authorised remote-access sessions.');
  else if (M.remAdmin) put(18, 'Partial', M.remAdmin + ' conduit(s) carry remote-admin protocols (' + M.remAdminPorts + ') into control-level zones.');
  else put(18, 'Compliant', 'No Internet paths to control-level devices and no remote-admin protocols into control zones. Cross-check with the authorised session list.');
  if (!vm.chOpen) put(28, 'Compliant', 'No critical or high findings are open.');
  else put(28, vm.old90 === 0 ? 'Compliant' : vm.old90 * 4 <= vm.chOpen ? 'Partial' : 'Non-Compliant', vm.chOpen + ' critical/high findings open; ' + vm.old90 + ' older than 90 days; oldest ' + vm.oldest + ' days, average ' + vm.avg + ' days (counted from when this console first saw the finding).');
  if (!vm.otCh) put(29, 'Compliant', 'No critical or high findings are open on OT / control devices.');
  else { const p = rkPct(vm.otChDoc, vm.otCh); put(29, p >= 80 ? 'Compliant' : p >= 30 ? 'Partial' : 'Non-Compliant', vm.otCh + ' critical/high findings on OT devices; ' + vm.otChDoc + ' (' + p + '%) have an owner, note or accepted-risk reason.'); }
  if (!M.seen) put(30, 'Non-Compliant', 'The sensor has never reported.');
  else put(30, status === 'online' && scanMode !== 'active' ? 'Compliant' : 'Partial', 'Sensor ' + status + ', scan mode ' + (scanMode || 'decided by the sensor') + (scanMode === 'active' ? '. Active scanning can disturb fragile OT devices; use passive on OT segments.' : '.'));
  put(34, '', am.total + ' alerts raised by this console (' + am.open + ' open). It has no outbound SIEM feed, so forwarding must be checked on the SIEM side.');
  if (as || vm.total) put(49, 'Partial', vm.chOpen + ' critical/high findings open, ' + vm.overdue + ' overdue, ' + vm.kev + ' in the CISA catalog; a 30-day trend is on the Vulnerabilities tab. Confirm these are reported to management on a schedule.');
  return { site: { id: sid, name: site.name || '', status: status, age: M.age }, now: now, M: M, suggest: sg, zones: Object.keys(Z).map(function (k) { const z = Z[k], s = ZS[k] || {}, ty = {};
    z.assets.forEach(function (o) { const t = o.type || 'Unclassified'; ty[t] = (ty[t] || 0) + 1; });
    return { name: z.name, level: z.level, provisional: z.provisional, specs: z.specs, fw: z.fw, devices: z.assets.length, ot: z.assets.filter(function (o) { return o.ot; }).length, control: z.assets.filter(function (o) { return o.control; }).length,
      types: Object.keys(ty).sort(function (a, b) { return ty[b] - ty[a]; }).slice(0, 4).map(function (t) { return t + ' ' + ty[t]; }),
      crit: s.crit || 0, high: s.high || 0, eol: s.eol || 0, alerts: s.alerts || 0, cmds: s.cmds || 0, ext: s.ext || 0, conduits_high: (s.conduitsHigh || []).length }; }),
    conduits: conduits.slice(0, 300).map(function (e) { return { key: e.key, from: e.from, to: e.to, fl: e.fl, tl: e.tl, port: e.port, svc: e.svc, n: e.n, sev: e.sev, why: e.why, tags: e.tags, rule: e.rule, chk: e.chk, ex: e.ex }; }), conduit_total: conduits.length, risks: risks };
}
function rkEv(sid, fresh) {
  const c = RK_CACHE.get(sid);
  if (!fresh && c && Date.now() - c.t < 20000) return c.ev;
  const ev = rkBuild(sid); RK_CACHE.set(sid, { t: Date.now(), ev: ev });
  if (RK_CACHE.size > 200) RK_CACHE.clear();
  return ev;
}
/* what a person has answered turns into maturity, FR / CSF coverage, residual risk and programme risks */
function rkScoreAnswers(answers) {
  const dom = {}, fr = {}, fn = {}, tot = { c: 0, p: 0, nc: 0, na: 0, ans: 0, sum: 0, high: 0, q: 0 };
  RK_DOMAINS.forEach(function (d) { dom[d[0]] = { n: d[0], name: d[1], ref: d[2], total: 0, c: 0, p: 0, nc: 0, na: 0, ans: 0, sum: 0, gaps: [] }; });
  Object.keys(RK_FR).forEach(function (k) { fr[k] = { fr: +k, name: RK_FR[k], total: 0, ans: 0, sum: 0 }; });
  Object.keys(RK_CSF).forEach(function (k) { fn[k] = { fn: k, name: RK_CSF[k], total: 0, ans: 0, sum: 0 }; });
  RK_Q.forEach(function (q) {
    const a = answers[q.n], r = a && a.resp, d = dom[q.d]; d.total++; tot.q++;
    q.fr.forEach(function (f) { fr[f].total++; });
    const fns = {}; q.csf.forEach(function (c) { fns[c.slice(0, 2)] = 1; }); Object.keys(fns).forEach(function (f) { fn[f].total++; });
    if (r === 'N/A') { d.na++; tot.na++; return; }
    if (!(r in RK_SCORE)) return;
    const sc = RK_SCORE[r]; d.ans++; d.sum += sc; tot.ans++; tot.sum += sc;
    if (r === 'Compliant') { d.c++; tot.c++; } else if (r === 'Partial') { d.p++; tot.p++; } else { d.nc++; tot.nc++; if (q.pri === 'High') tot.high++; }
    if (r !== 'Compliant') d.gaps.push({ n: q.n, r: r, pri: q.pri });
    q.fr.forEach(function (f) { fr[f].ans++; fr[f].sum += sc; });
    Object.keys(fns).forEach(function (f) { fn[f].ans++; fn[f].sum += sc; });
  });
  const fin = function (o) { o.m = o.ans ? o.sum / o.ans : null; return o; };
  return { domains: Object.keys(dom).map(function (k) { const d = fin(dom[k]); d.level = rkMLevel(d.m); return d; }), fr: Object.keys(fr).map(function (k) { return fin(fr[k]); }), csf: Object.keys(fn).map(function (k) { return fin(fn[k]); }),
    overall: { total: tot.q, answered: tot.ans, c: tot.c, p: tot.p, nc: tot.nc, na: tot.na, m: tot.ans ? tot.sum / tot.ans : null, level: rkMLevel(tot.ans ? tot.sum / tot.ans : null), high_gaps: tot.high } };
}
function rkCompose(sid, ev, st) {
  const eff = {}, ans = st.answers || {}, autoOn = st.auto !== false;
  Object.keys(ans).forEach(function (k) { eff[k] = ans[k]; });
  if (autoOn) Object.keys(ev.suggest).forEach(function (k) { const g = ev.suggest[k]; if (g.s && !(ans[k] && ans[k].resp)) eff[k] = { resp: g.s, note: (ans[k] && ans[k].note) || '', owner: (ans[k] && ans[k].owner) || '', auto: true }; });
  const sc = rkScoreAnswers(eff), zt = st.zt || {}, dm = {}; sc.domains.forEach(function (d) { dm[d.n] = d; });
  let maxImp = 0;
  const zones = ev.zones.map(function (z) {
    const o = zt[z.name] || {}, def = RK_IMPACT[z.level] || 3, imp = o.impact >= 1 && o.impact <= 5 ? o.impact : def, slt = o.slt >= 1 && o.slt <= 4 ? o.slt : rkSltOf(imp);
    if (z.devices > 0 && imp > maxImp) maxImp = imp;
    return Object.assign({}, z, { impact: imp, impact_default: def, impact_set: !!(o.impact >= 1 && o.impact <= 5), slt: slt, slt_default: rkSltOf(imp), slt_set: !!(o.slt >= 1 && o.slt <= 4) });
  });
  const zi = {}; zones.forEach(function (z) { zi[z.name] = z.impact; });
  const progI = Math.max(2, Math.min(4, (maxImp || 3) - 1));
  const T = st.treat || {}, risks = [];
  const fin = function (r) {
    const t = T[r.id] || {};
    r.score = r.L * r.I; r.band = rkBand(r.score);
    if (r.rL) { r.rscore = r.rL * r.I; r.rband = rkBand(r.rscore); }
    r.tr = t.tr || ''; r.status = t.st || 'open'; r.owner = t.owner || ''; r.due = t.due || ''; r.note = t.note || ''; r.by = t.by || ''; r.at = t.at || 0;
    risks.push(r);
  };
  ev.risks.forEach(function (r) {
    const d = dm[r.dom], m = d && d.m !== null && d.ans * 2 >= d.total ? d.m : null, rr = Object.assign({}, r, { I: zi[r.zone] || (r.code === 'MON' ? (maxImp || 3) : progI) });
    rr.m = m; rr.rL = m === null ? 0 : Math.max(1, Math.round(r.L * (1 - 0.5 * m)));
    fin(rr);
  });
  sc.domains.forEach(function (d) {
    if (d.m === null || d.m >= 0.75 || d.ans * 2 < d.total) return;       // needs at least half of the domain answered before it counts as a risk
    const L = 1 + Math.round(4 * (1 - d.m)), hi = d.gaps.filter(function (g) { return g.r === 'Non-Compliant' && g.pri === 'High'; }).map(function (g) { return '#' + g.n; });
    const frs = {}, csf = {}; d.gaps.forEach(function (g) { RK_QBY[g.n].fr.forEach(function (f) { frs[f] = 1; }); RK_QBY[g.n].csf.forEach(function (c) { csf[c] = 1; }); });
    fin({ id: 'P|D' + d.n, code: 'PRG', zone: 'Site programme', level: '', title: d.name + ': maturity ' + Math.round(d.m * 100) + '% (' + d.level + ')', scenario: 'Controls or processes in this area are missing or only partly in place, so technical risks in the zones are less likely to be prevented, detected or recovered from.',
      evidence: d.c + ' compliant, ' + d.p + ' partial, ' + d.nc + ' non-compliant of ' + d.ans + ' answered' + (hi.length ? '. High-priority gaps: questions ' + hi.slice(0, 6).join(', ') + '.' : '.'), L: L, I: progI,
      lf: ['1 + 4 x (1 - maturity ' + Math.round(d.m * 100) + '%) = ' + L], fr: Object.keys(frs).map(Number), sr: RK_DOMAINS[d.n - 1][2], csf: Object.keys(csf).slice(0, 6), dom: d.n, rL: 0, m: null, action: 'Close the gaps listed for domain ' + d.n + ' on the Assessment sub-tab, starting with the high-priority non-compliant questions.', src: 'programme' });
  });
  (st.manual || []).forEach(function (m) {
    fin({ id: m.id, code: 'MAN', zone: m.zone || 'Site', level: '', title: m.title, scenario: m.desc || '', evidence: 'Added by ' + (m.by || 'a user') + '.', L: m.L, I: m.I, lf: [], fr: m.fr || [], sr: '', csf: m.csf ? String(m.csf).split(/[ ,;]+/).filter(Boolean) : [], dom: 0, rL: m.rL || 0, m: null, action: '', src: 'manual' });
  });
  risks.sort(function (a, b) { return b.score - a.score || b.L - a.L; });
  const open = risks.filter(function (r) { return r.status !== 'closed'; });
  const mx = function (key) { const g = []; for (let i = 0; i < 5; i++) { g.push([0, 0, 0, 0, 0]); } open.forEach(function (r) { const L = key === 'r' && r.rL ? r.rL : r.L; g[L - 1][r.I - 1]++; }); return g; };
  const cnt = function (f) { const o = { critical: 0, high: 0, medium: 0, low: 0 }; open.forEach(function (r) { o[f(r)]++; }); return o; };
  zones.forEach(function (z) {
    const zr = open.filter(function (r) { return r.zone === z.name; }); z.risks = zr.length;
    z.top = zr.length ? zr[0].score : 0; z.top_band = zr.length ? zr[0].band : ''; z.top_L = zr.length ? Math.max.apply(null, zr.map(function (r) { return r.L; })) : 0;
  });
  zones.sort(function (a, b) { return b.top - a.top || RK_LV.indexOf(a.level) - RK_LV.indexOf(b.level) || a.name.localeCompare(b.name); });
  return { site: ev.site, generated: ev.now, metrics: ev.M, suggest: ev.suggest, domains: sc.domains, fr: sc.fr, csf: sc.csf, overall: sc.overall, zones: zones, conduits: ev.conduits, conduit_total: ev.conduit_total, risks: risks,
    eff: eff, auto: autoOn, auto_n: Object.keys(eff).filter(function (k) { return eff[k].auto; }).length,
    summary: { open: open.length, inherent: cnt(function (r) { return r.band; }), residual: cnt(function (r) { return r.rL ? r.rband : r.band; }), matrix_i: mx('i'), matrix_r: mx('r'), prog_impact: progI },
    state: { auto: autoOn, answers: st.answers || {}, meta: st.meta || {}, zt: zt, treat: T, manual: st.manual || [], updated: st.updated || 0 } };
}
function rkResponse(sid, withCatalog, fresh) {
  const out = rkCompose(sid, rkEv(sid, fresh), rkState(sid));
  if (withCatalog) { out.catalog = RK_Q; out.domain_names = RK_DOMAINS; out.fr_names = RK_FR; out.csf_names = RK_CSF; }
  return out;
}
function rkCsvCell(v) { v = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; return csvEscape(v); }
function rkCsv(kind, m) {
  const rows = [];
  if (kind === 'register') {
    rows.push(['ID', 'Zone', 'Purdue level', 'Risk', 'Scenario', 'Evidence', 'Likelihood', 'Impact', 'Inherent score', 'Inherent rating', 'Residual likelihood', 'Residual score', 'Residual rating', 'IEC 62443-3-3 FR', 'IEC 62443-3-3 SR', 'NIST CSF 2.0', 'Treatment', 'Status', 'Owner', 'Due', 'Note', 'Recommended action']);
    m.risks.forEach(function (r) { rows.push([r.id, r.zone, r.level, r.title, r.scenario, r.evidence, r.L, r.I, r.score, r.band, r.rL || '', r.rscore || '', r.rband || '', (r.fr || []).map(function (f) { return 'FR' + f; }).join(' '), r.sr, (r.csf || []).join(' '), r.tr, r.status, r.owner, r.due, r.note, r.action]); });
  } else {
    rows.push(['#', 'Domain', 'Question', 'Data source', 'Priority', 'IEC reference', 'IEC 62443-3-3 FR', 'IEC 62443-3-3 SR', 'NIST CSF 2.0', 'Suggested by Central', 'Evidence from Central', 'Response', 'Score', 'Notes', 'Action owner', 'Response set by']);
    RK_Q.forEach(function (q) {
      const a = m.eff[q.n] || {}, sg = m.suggest[q.n] || {};
      rows.push([q.n, q.d + '. ' + RK_DOMAINS[q.d - 1][1], q.q, q.src, q.pri, q.ref, q.fr.map(function (f) { return 'FR' + f; }).join(' '), q.sr, q.csf.join(' '), sg.s || '', sg.basis || '', a.resp || '', a.resp in RK_SCORE ? RK_SCORE[a.resp] : '', a.note || '', a.owner || '', a.resp ? (a.auto ? 'Central (automatic)' : 'Person') : '']);
    });
  }
  return rows.map(function (r) { return r.map(rkCsvCell).join(','); }).join('\r\n') + '\r\n';
}
function rkReport(m, ctx) {
  const E = vh, meta = m.state.meta || {}, pc = function (x) { return x === null || x === undefined ? 'n/a' : Math.round(x * 100) + '%'; };
  const BC = { critical: '#c8283b', high: '#c65b1a', medium: '#a2650a', low: '#1d8a5a' };
  const pill = function (b, t) { return '<span style="background:' + BC[b] + ';color:#fff;border-radius:10px;padding:1px 8px;font-size:11px;font-weight:700">' + E(t || b) + '</span>'; };
  const tbl = function (head, rows) { return '<table><thead><tr>' + head.map(function (h) { return '<th>' + E(h) + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table>'; };
  const grid = function (g, key) { let h = '<table class="mx"><tr><th></th>' + [1, 2, 3, 4, 5].map(function (i) { return '<th>I' + i + '</th>'; }).join('') + '</tr>';
    for (let L = 5; L >= 1; L--) { h += '<tr><th>L' + L + '</th>' + [1, 2, 3, 4, 5].map(function (I) { const b = rkBand(L * I), n = g[L - 1][I - 1]; return '<td style="background:' + BC[b] + (n ? '' : '33') + ';color:' + (n ? '#fff' : '#555') + ';text-align:center;font-weight:700">' + (n || '') + '</td>'; }).join('') + '</tr>'; }
    return h + '</table>'; };
  let h = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OT risk assessment - ' + E(m.site.name) + '</title><style>'
    + 'body{font:13px/1.45 "Segoe UI",system-ui,sans-serif;color:#1a2633;margin:0;padding:24px;max-width:1100px;margin:auto}h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:26px 0 8px;border-bottom:2px solid #d3dce8;padding-bottom:4px}'
    + 'table{border-collapse:collapse;width:100%;margin:6px 0}th,td{border:1px solid #d3dce8;padding:5px 7px;text-align:left;vertical-align:top;font-size:12px}th{background:#eef2f7}.mx{width:auto}.mx td,.mx th{width:46px;height:30px}.m{color:#5a6c80}.kp{display:flex;gap:10px;flex-wrap:wrap}.kp div{border:1px solid #d3dce8;border-radius:8px;padding:8px 14px;min-width:120px}.kp b{display:block;font-size:22px}'
    + '@media print{body{padding:0}h2{break-after:avoid}tr{break-inside:avoid}}</style></head><body>'
    + '<h1>OT cyber risk assessment</h1><div class="m">' + E(m.site.name) + (ctx.org ? ' &middot; ' + E(ctx.org) : '') + ' &middot; generated ' + E(new Date(m.generated * 1000).toISOString().slice(0, 16).replace('T', ' ')) + ' UTC by ' + E(ctx.by) + '</div>'
    + '<div class="m">' + [meta.org && 'Organisation: ' + meta.org, meta.site && 'Site / plant: ' + meta.site, meta.assessor && 'Assessor: ' + meta.assessor, meta.ref && 'Ref: ' + meta.ref, meta.date && 'Assessment date: ' + meta.date].filter(Boolean).map(E).join(' &middot; ') + '</div>'
    + '<p class="m">Method: IEC 62443 maturity workbook (53 questions, scored Compliant 1 / Partial 0.5 / Non-Compliant 0, N/A left out), mapped to IEC 62443-3-3 foundational requirements and NIST CSF 2.0. Risk = likelihood x impact on a 5 x 5 scale, scored per zone from this console\'s own asset, flow, vulnerability, alert and activity data. '
    + 'Likelihood falls by up to half when the linked assessment domain is fully compliant. Coverage by foundational requirement is not a formal security-level (SL-A) rating.</p>';
  h += '<h2>Summary</h2><div class="kp"><div><b>' + pc(m.overall.m) + '</b>Maturity (' + E(m.overall.level) + ')</div><div><b>' + m.overall.answered + ' / ' + m.overall.total + '</b>Questions answered</div><div><b>' + m.overall.high_gaps + '</b>High-priority gaps</div><div><b>' + m.summary.open + '</b>Open risks</div>'
    + '<div><b>' + m.summary.inherent.critical + ' / ' + m.summary.inherent.high + '</b>Critical / high (inherent)</div><div><b>' + m.summary.residual.critical + ' / ' + m.summary.residual.high + '</b>Critical / high (residual)</div></div>';
  h += '<h2>Risk matrix</h2><div style="display:flex;gap:30px;flex-wrap:wrap"><div><b>Inherent</b>' + grid(m.summary.matrix_i) + '</div><div><b>Residual</b>' + grid(m.summary.matrix_r) + '</div></div>';
  h += '<h2>Maturity by domain</h2>' + tbl(['Domain', 'Compliant', 'Partial', 'Non-compliant', 'N/A', 'Answered', 'Maturity', 'Level'], m.domains.map(function (d) { return '<tr><td>' + d.n + '. ' + E(d.name) + '</td><td>' + d.c + '</td><td>' + d.p + '</td><td>' + d.nc + '</td><td>' + d.na + '</td><td>' + d.ans + ' / ' + d.total + '</td><td>' + pc(d.m) + '</td><td>' + E(d.level) + '</td></tr>'; }));
  h += '<h2>IEC 62443-3-3 foundational requirements and NIST CSF 2.0</h2><div style="display:flex;gap:20px;flex-wrap:wrap"><div style="flex:1 1 380px">' + tbl(['Foundational requirement', 'Questions', 'Coverage'], m.fr.map(function (f) { return '<tr><td>FR' + f.fr + ' ' + E(f.name) + '</td><td>' + f.ans + ' / ' + f.total + '</td><td>' + pc(f.m) + '</td></tr>'; }))
    + '</div><div style="flex:1 1 300px">' + tbl(['CSF 2.0 function', 'Questions', 'Score'], m.csf.map(function (f) { return '<tr><td>' + f.fn + ' ' + E(f.name) + '</td><td>' + f.ans + ' / ' + f.total + '</td><td>' + pc(f.m) + '</td></tr>'; })) + '</div></div>';
  h += '<h2>Zones</h2>' + tbl(['Zone', 'Purdue', 'Devices (OT)', 'Impact', 'Proposed SL-T', 'Open risks', 'Worst risk'], m.zones.map(function (z) { return '<tr><td>' + E(z.name) + (z.provisional ? ' <span class="m">(provisional)</span>' : '') + '</td><td>' + E(z.level) + '</td><td>' + z.devices + ' (' + z.ot + ')</td><td>' + z.impact + '</td><td>SL ' + z.slt + '</td><td>' + z.risks + '</td><td>' + (z.top ? pill(z.top_band, z.top_band + ' ' + z.top) : '') + '</td></tr>'; }));
  h += '<h2>Risk register</h2>' + tbl(['Zone', 'Risk', 'L', 'I', 'Inherent', 'Residual', 'FR', 'CSF 2.0', 'Treatment', 'Owner', 'Evidence'], m.risks.map(function (r) {
    return '<tr><td>' + E(r.zone) + '</td><td><b>' + E(r.title) + '</b><div class="m">' + E(r.scenario) + '</div></td><td>' + r.L + '</td><td>' + r.I + '</td><td>' + pill(r.band, r.score) + '</td><td>' + (r.rL ? pill(r.rband, r.rscore) : '<span class="m">-</span>') + '</td><td>' + E((r.fr || []).map(function (f) { return 'FR' + f; }).join(' ')) + '</td><td>' + E((r.csf || []).join(' ')) + '</td><td>' + E([r.tr, r.status].filter(Boolean).join(' / ')) + (r.note ? '<div class="m">' + E(r.note) + '</div>' : '') + '</td><td>' + E(r.owner) + '</td><td>' + E(r.evidence) + '</td></tr>'; }));
  h += '<h2>Assessment answers</h2>' + tbl(['#', 'Question', 'Source', 'Priority', 'Response', 'Central suggested', 'Notes'], RK_Q.map(function (q) { const a = m.eff[q.n] || {}, sg = m.suggest[q.n] || {};
    return '<tr><td>' + q.n + '</td><td>' + E(q.q) + '</td><td>' + E(q.src) + '</td><td>' + E(q.pri) + '</td><td>' + E(a.resp || 'Not assessed') + (a.auto ? ' <span class="m">(automatic)</span>' : '') + '</td><td>' + E(sg.s || '') + (sg.basis ? '<div class="m">' + E(sg.basis) + '</div>' : '') + '</td><td>' + E(a.note || '') + '</td></tr>'; }));
  return h + '</body></html>';
}

/* ------------------------------------------------------------------ */
/* Packet captures: an on-demand capture central asks a sensor to run, and a short pcap a sensor      */
/* attaches to an alert on its own. Sensors only ever push to central, so a capture request is handed */
/* to the sensor as part of its next regular check-in (the /api/ingest reply), and the sensor uploads */
/* the finished pcap as its own small POST once it is done. Files live on disk; only their metadata is */
/* kept in DB.                                                                                         */
const PCAP_DIR = path.join(DATA_DIR, 'pcaps');
const CAPTURE_MAX_S = 300, CAPTURE_MIN_S = 10, CAPTURE_JOB_TIMEOUT_S = 15 * 60, PCAP_MAX_BYTES = 40 * 1024 * 1024, PCAP_RETENTION_S = 30 * 86400;
try { fs.mkdirSync(PCAP_DIR, { recursive: true }); } catch (e) {}
function pcapId() { return 'pc_' + crypto.randomBytes(9).toString('hex'); }
function pcapPath(id) { return path.join(PCAP_DIR, id.replace(/[^a-z0-9_]/gi, '') + '.pcap'); }
/* The single next job a sensor should run, or null. Marking it 'sent' happens here, at hand-off time,
   so a sensor that never calls back (offline, or the file never shows up) ages out on its own. */
function captureNext(sid) {
  const jobs = DB.ccmd[sid] || [], now = Date.now() / 1000;
  jobs.forEach(function (j) { if (j.status === 'sent' && now - j.sent_at > CAPTURE_JOB_TIMEOUT_S) { j.status = 'error'; j.error = 'the sensor never reported back'; dirty = true; } });
  const j = jobs.find(function (x) { return x.status === 'pending'; });
  if (!j) return null;
  j.status = 'sent'; j.sent_at = now; dirty = true;
  return { id: j.id, seconds: j.seconds, bpf: j.bpf || '' };
}
function captureStart(sid, seconds, bpf, label, by) {
  const jobs = DB.ccmd[sid] || (DB.ccmd[sid] = []);
  const j = { id: pcapId(), status: 'pending', seconds: Math.max(CAPTURE_MIN_S, Math.min(CAPTURE_MAX_S, parseInt(seconds, 10) || 60)), bpf: S(bpf, 200), label: S(label, 120), by: by, at: Date.now() / 1000, pcap: '' };
  jobs.push(j);
  if (jobs.length > 30) jobs.splice(0, jobs.length - 30);
  dirty = true;
  return j.id;
}
function captureJobs(sid) { return (DB.ccmd[sid] || []).slice().sort(function (a, b) { return b.at - a.at; }); }
function pcapSave(buf, meta) {       // meta: { site, kind: 'alert'|'manual', ref, label }
  if (buf.length > PCAP_MAX_BYTES) throw new Error('pcap too large (max ' + (PCAP_MAX_BYTES / 1024 / 1024) + ' MB)');
  if (buf.length < 24 || buf.readUInt32LE(0) !== 0xa1b2c3d4 && buf.readUInt32BE(0) !== 0xa1b2c3d4 && buf.readUInt32LE(0) !== 0x4d3cb2a1 && buf.readUInt32BE(0) !== 0x0a0d0d0a) throw new Error('not a pcap/pcapng file');
  const id = pcapId();
  fs.writeFileSync(pcapPath(id), buf);
  DB.pcaps[id] = { id: id, site: meta.site, kind: meta.kind, ref: meta.ref, label: meta.label || '', size: buf.length, created: Date.now() / 1000 };
  dirty = true;
  return id;
}
function pcapPrune() {
  const cut = Date.now() / 1000 - PCAP_RETENTION_S;
  for (const id in DB.pcaps) {
    const p = DB.pcaps[id];
    if (p.created < cut) { try { fs.unlinkSync(pcapPath(id)); } catch (e) {} delete DB.pcaps[id]; dirty = true; }
  }
  for (const sid in DB.ccmd) {
    DB.ccmd[sid] = DB.ccmd[sid].filter(function (j) { return j.at >= cut || j.status === 'pending' || j.status === 'sent'; });
    if (!DB.ccmd[sid].length) delete DB.ccmd[sid];
  }
}
function toCsv(kind, rows) {
  const cols = { assets: ['org_name', 'site_name', 'ip', 'mac', 'vendor', 'device_type', 'model', 'firmware', 'os', 'zone', 'vlan', 'seg_zone', 'ot', 'risk', 'protocols', 'first_seen', 'last_seen'],
    alerts: ['org_name', 'site_name', 'severity', 'kind', 'title', 'src', 'dst', 'proto', 'count', 'mitre', 'status', 'first_seen', 'last_seen', 'note'],
    flows: ['org_name', 'site_name', 'client', 'server', 'proto', 'l4', 'port', 'ot', 'packets', 'bytes', 'first_seen', 'last_seen'],
    activities: ['org_name', 'site_name', 'sensor', 'last', 'text', 'first', 'src', 'src_mac', 'dst', 'dst_mac', 'proto', 'l4', 'port', 'func', 'cat', 'ot', 'pkts', 'bytes', 'detail'] }[kind];
  return [cols.join(',')].concat(rows.map(function (r) {
    return cols.map(function (c) { return csvEscape(Array.isArray(r[c]) ? r[c].join(' ') : r[c]); }).join(',');
  })).join('\r\n');
}

/* ------------------------------------------------------------------ */
/* HTTP                                                                */
/* ------------------------------------------------------------------ */
function send(res, code, body, type, extra) {
  const h = Object.assign({ 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin' }, extra || {});
  res.writeHead(code, h);
  res.end(body);
}
/* ===================================================================== */
/* Remote access: approved, time-limited sessions to one device through   */
/* the site sensor. Everything is plain HTTPS (works on Plesk): the sensor */
/* and the helper on the engineer's computer both call central; central    */
/* only passes bytes between them. The target is fixed by the approved     */
/* session; neither end can choose another.                                */
/* ===================================================================== */
const RA_PORTS = [3389, 22, 44818, 5900, 443, 102, 502];
const RA_CH = new Map();      // channel id -> { sid, site, up, down, created, last }
const RA_SQ = {};             // site id -> { orders: [], waiter }  (orders waiting for the sensor)
function raSite(sid) { const s = DB.sites[sid]; if (!s) return null; return (s.ra = s.ra || { on: false, ports: RA_PORTS.slice(), self: false, maxmin: 120 }); }
function raStore() { return (DB.ra = DB.ra || { seq: 0, s: {} }); }
function raLive(s) { return s.status === 'approved' && s.expires > Date.now() / 1000; }
function raQ() { return { buf: [], bytes: 0, closed: false, err: '', waiter: null }; }
function raWake(q) { if (q.waiter) { const w = q.waiter; q.waiter = null; clearTimeout(w.t); w.fn(); } }
function raPush(q, b) { q.buf.push(b); q.bytes += b.length; raWake(q); }
function raPull(q, res, ms) {         // answer now when there is data or the other side closed, otherwise hold the request open
  const reply = function () {
    if (q.bytes) {
      const all = Buffer.concat(q.buf); const out = all.length > 262144 ? all.subarray(0, 262144) : all, rest = all.subarray(out.length);
      q.buf = rest.length ? [Buffer.from(rest)] : []; q.bytes = rest.length;
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': out.length, 'Cache-Control': 'no-store', 'X-Closed': q.closed && !q.bytes ? '1' : '' });
      return res.end(out);
    }
    if (q.closed) { res.writeHead(200, { 'Content-Length': 0, 'X-Closed': '1', 'X-Error': encodeURIComponent(q.err || ''), 'Cache-Control': 'no-store' }); return res.end(); }
    res.writeHead(204, { 'Cache-Control': 'no-store' }); res.end();
  };
  if (q.bytes || q.closed) return reply();
  raWake(q);
  const w = { fn: reply, t: setTimeout(function () { if (q.waiter === w) q.waiter = null; reply(); }, ms) }; q.waiter = w;
  res.on('close', function () { if (q.waiter === w) { clearTimeout(w.t); q.waiter = null; } });
}
function raOrder(sid, o) { const q = RA_SQ[sid] = RA_SQ[sid] || { orders: [], waiter: null }; q.orders.push(o); if (q.orders.length > 500) q.orders.shift(); if (q.waiter) { const w = q.waiter; q.waiter = null; clearTimeout(w.t); w.fn(); } }
function raCloseCh(id, err) {
  const c = RA_CH.get(id); if (!c || c.closing) return; c.closing = true;
  [c.up, c.down].forEach(function (q) { q.closed = true; if (err && !q.err) q.err = err; raWake(q); });
  raOrder(c.sid, { op: 'close', ch: id });
  setTimeout(function () { RA_CH.delete(id); }, 60000).unref();
}
function raEndSession(s, status, who, why) {
  if (s.status === 'ended' || s.status === 'expired' || s.status === 'denied') return;
  s.status = status; s.ended = Date.now() / 1000; s.htok = ''; dirty = true;
  RA_CH.forEach(function (c, id) { if (c.rid === s.id) raCloseCh(id, why || 'session ended'); });
  audit(who || 'system', 'ra.' + status, s.id + ' ' + s.ip + ' ' + (why || ''), (DB.sites[s.site] || {}).tenant || null);
}
setInterval(function () {
  const now = Date.now() / 1000, st = raStore();
  Object.keys(st.s).forEach(function (k) {
    const s = st.s[k];
    if (s.status === 'approved' && s.expires <= now) raEndSession(s, 'expired', 'system', 'time limit reached');
    else if (s.status === 'pending' && s.created + 86400 < now) raEndSession(s, 'expired', 'system', 'nobody approved it within 24 hours');
  });
  RA_CH.forEach(function (c, id) { if (!c.closing && now - c.last > 600) raCloseCh(id, 'idle'); });
}, 10000).unref();
function raView(s, me) {
  const o = {}; ['id', 'site', 'ip', 'ports', 'reason', 'status', 'by', 'created', 'decided_by', 'decided', 'expires', 'ended', 'minutes', 'ch_n', 'up', 'down', 'last', 'deny'].forEach(function (k) { o[k] = s[k]; });
  const site = DB.sites[s.site] || {}; o.site_name = site.name || ''; o.tenant = site.tenant || ''; o.tenant_name = tenantName(site.tenant);
  o.live = raLive(s); o.mine = s.by === me.name; o.can_decide = s.status === 'pending' && (s.by !== me.name || !!(site.ra || {}).self); o.helper = o.live && o.mine;
  return o;
}
/* ---- the helper on the engineer's computer ---- */
function raHelperAuth(req) {
  const tok = bearer(req); if (!tok) return null; const h = sha(tok), st = raStore();
  for (const k in st.s) { const s = st.s[k]; if (s.htok && s.htok === h && raLive(s)) return s; }
  return null;
}
async function raHelper(req, res, p, q) {
  const s = raHelperAuth(req); if (!s) { await delay(300); return fail(res, 401, 'this session is not active (not approved, expired or ended)'); }
  const site = DB.sites[s.site]; if (!site || !(site.ra && site.ra.on) || !DB.tenants[site.tenant] || DB.tenants[site.tenant].status === 'suspended') return fail(res, 403, 'remote access is switched off for this site');
  s.last = Date.now() / 1000;
  if (p === '/api/ra/h/open' && req.method === 'POST') {
    const port = parseInt(q.port, 10);
    if (s.ports.indexOf(port) === -1) return fail(res, 403, 'port ' + port + ' is not part of this approved session');
    let n = 0; RA_CH.forEach(function (c) { if (c.rid === s.id && !c.closing) n++; });
    if (n >= 24) return fail(res, 429, 'too many open connections in this session');
    const id = crypto.randomBytes(9).toString('base64url');
    RA_CH.set(id, { sid: String(s.site), rid: s.id, up: raQ(), down: raQ(), created: Date.now() / 1000, last: Date.now() / 1000 });
    s.ch_n = (s.ch_n || 0) + 1; dirty = true;
    raOrder(String(s.site), { op: 'open', ch: id, ip: s.ip, port: port, exp: s.expires });
    return json(res, { ch: id });
  }
  const c = RA_CH.get(S(q.ch, 40)); if (!c || c.rid !== s.id) return fail(res, 404, 'no such connection');
  c.last = Date.now() / 1000;
  if (p === '/api/ra/h/send' && req.method === 'POST') {
    let b; try { b = await readBody(req, 1024 * 1024); } catch (e) { return fail(res, 413, 'too large'); }
    if (c.up.closed) return fail(res, 410, 'closed');
    if (c.up.bytes > 4 * 1024 * 1024) return fail(res, 429, 'slow down');
    raPush(c.up, b); s.up = (s.up || 0) + b.length; return json(res, { ok: true });
  }
  if (p === '/api/ra/h/recv' && req.method === 'GET') {
    const ms = Math.max(1, Math.min(25, parseInt(q.wait, 10) || 20)) * 1000;
    const bytesBefore = c.down.bytes; s.down = (s.down || 0) + 0;
    return raPull(c.down, res, ms);
  }
  if (p === '/api/ra/h/close' && req.method === 'POST') { raCloseCh(S(q.ch, 40), ''); return json(res, { ok: true }); }
  return fail(res, 404, 'not found');
}

/* ---- remote desktop in the browser (Guacamole HTTP tunnel protocol, so the stock guacamole-common-js client works) ---- */
function guacIns(a) { return a.map(function (v) { v = String(v); return Array.from(v).length + '.' + v; }).join(',') + ';'; }
function raPullText(q, res, ms) {      // like raPull, but speaks the Guacamole protocol: keep-alive = nop, end = disconnect / error
  const reply = function () {
    let body = '';
    if (q.bytes) { body = Buffer.concat(q.buf).toString('utf8'); q.buf = []; q.bytes = 0; }
    else if (q.closed) {
      if (q.final) { res.writeHead(404, { 'Guacamole-Status-Code': '519', 'Guacamole-Error-Message': 'closed', 'Content-Length': 0 }); return res.end(); }
      q.final = true; body = q.err ? guacIns(['error', q.err, '519']) : guacIns(['disconnect']);
    } else body = '3.nop;';
    res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store' }); res.end(body);
  };
  if (q.bytes || q.closed) return reply();
  raWake(q);
  const w = { fn: reply, t: setTimeout(function () { if (q.waiter === w) q.waiter = null; reply(); }, ms) }; q.waiter = w;
  res.on('close', function () { if (q.waiter === w) { clearTimeout(w.t); q.waiter = null; } });
}
async function raWebTunnel(req, res, u) {
  const me = readCookie(req); if (!me) return fail(res, 401, 'sign in required');
  const sf = req.headers['sec-fetch-site']; if (sf && sf !== 'same-origin' && sf !== 'none') return fail(res, 403, 'not allowed from another site');
  const cmd = String(u.search || '').replace(/^\?/, ''), parts = cmd.split(':'), op = parts[0], id = S(parts[1], 40);
  if (op === 'connect' && req.method === 'POST') {
    let raw; try { raw = (await readBody(req, 8192)).toString('utf8'); } catch (e) { return fail(res, 413, 'too large'); }
    const f = Object.fromEntries(new URLSearchParams(raw).entries()), st = raStore(), s = st.s[S(f.session, 30)];
    if (!s || s.by !== me.name || !raLive(s)) return fail(res, 403, 'this session is not active, or is not yours');
    const site = DB.sites[s.site]; if (!site || !(site.ra && site.ra.on)) return fail(res, 403, 'remote access is switched off for this site');
    if (!scopeOf(Object.assign({ isSuper: me.role === 'superadmin' }, me), '').has(String(s.site))) return fail(res, 403, 'not allowed');
    const port = parseInt(f.port, 10) || 3389; if (s.ports.indexOf(port) === -1) return fail(res, 403, 'port ' + port + ' is not part of this session');
    let n = 0; RA_CH.forEach(function (c) { if (c.rid === s.id && !c.closing) n++; }); if (n >= 24) return fail(res, 429, 'too many open connections in this session');
    const cid = crypto.randomBytes(12).toString('hex'), num = function (x, d, lo, hi) { x = parseInt(x, 10); return x >= lo && x <= hi ? x : d; };
    RA_CH.set(cid, { sid: String(s.site), rid: s.id, up: raQ(), down: raQ(), created: Date.now() / 1000, last: Date.now() / 1000, web: true });
    s.ch_n = (s.ch_n || 0) + 1; s.last = Date.now() / 1000; dirty = true;
    audit(me.name, 'ra.browser', s.id + ' ' + s.ip + ':' + port + ' as ' + S(f.user, 60), site.tenant);       // the password is never logged or stored
    raOrder(String(s.site), { op: 'open', mode: 'guac', ch: cid, ip: s.ip, port: port, exp: s.expires,
      params: { user: S(f.user, 100), pass: S(f.pass, 200), domain: S(f.domain, 100), width: num(f.width, 1280, 200, 4096), height: num(f.height, 720, 200, 4096), dpi: num(f.dpi, 96, 48, 300) } });
    res.writeHead(200, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' }); return res.end(cid);
  }
  const c = RA_CH.get(id), s = c && raStore().s[c.rid];
  if (!c || !c.web || !s || s.by !== me.name) return fail(res, 404, 'no such connection');
  if (!raLive(s)) { raCloseCh(id, 'session time is over'); }
  c.last = Date.now() / 1000;
  if (op === 'read' && req.method === 'GET') return raPullText(c.down, res, 8000);
  if (op === 'write' && req.method === 'POST') {
    let b; try { b = await readBody(req, 1024 * 1024); } catch (e) { return fail(res, 413, 'too large'); }
    if (c.up.closed) return fail(res, 410, 'closed');
    if (c.up.bytes < 4 * 1024 * 1024) { raPush(c.up, b); s.up = (s.up || 0) + b.length; }
    res.writeHead(200, { 'Content-Length': 0 }); return res.end();
  }
  if (op === 'abort' && req.method === 'POST') { raCloseCh(id, ''); res.writeHead(200, { 'Content-Length': 0 }); return res.end(); }
  return fail(res, 400, 'bad request');
}
/* ---- the sensor ---- */
async function raSensor(req, res, p, q, site) {
  const sid = String(site.id), ra = raSite(sid);
  if (!ra || !ra.on || !DB.tenants[site.tenant] || DB.tenants[site.tenant].status === 'suspended') return json(res, { on: false, orders: [] });
  if (p === '/api/ra/s/poll') {
    const sq = RA_SQ[sid] = RA_SQ[sid] || { orders: [], waiter: null };
    const reply = function () { const o = sq.orders.splice(0, 50); json(res, { on: true, orders: o }); };
    if (sq.orders.length) return reply();
    if (sq.waiter) { const w0 = sq.waiter; sq.waiter = null; clearTimeout(w0.t); w0.fn(); }
    const w = { fn: reply, t: setTimeout(function () { if (sq.waiter === w) sq.waiter = null; reply(); }, 22000) }; sq.waiter = w;
    res.on('close', function () { if (sq.waiter === w) { clearTimeout(w.t); sq.waiter = null; } });
    return;
  }
  const c = RA_CH.get(S(q.ch, 40)); if (!c || c.sid !== sid) return fail(res, 404, 'no such connection');
  c.last = Date.now() / 1000;
  const sess = raStore().s[c.rid];
  if (p === '/api/ra/s/recv' && req.method === 'GET') return raPull(c.up, res, Math.max(1, Math.min(25, parseInt(q.wait, 10) || 20)) * 1000);
  if (p === '/api/ra/s/send' && req.method === 'POST') {
    let b; try { b = await readBody(req, 1024 * 1024); } catch (e) { return fail(res, 413, 'too large'); }
    if (c.down.closed) return fail(res, 410, 'closed');
    if (c.down.bytes > 4 * 1024 * 1024) return fail(res, 429, 'slow down');
    raPush(c.down, b); if (sess) sess.down = (sess.down || 0) + b.length; return json(res, { ok: true });
  }
  if (p === '/api/ra/s/close' && req.method === 'POST') { raCloseCh(S(q.ch, 40), S(q.err, 200)); return json(res, { ok: true }); }
  return fail(res, 404, 'not found');
}
function raHelperFile(s, base) {
  const tok = newToken(); s.htok = sha(tok); dirty = true;
  const cfg = { url: base, token: tok, session: s.id, ip: s.ip, ports: s.ports, bind: '127.0.0.2', expires: s.expires, name: (DB.sites[s.site] || {}).name || '' };
  return fs.readFileSync(path.join(__dirname, 'ra-helper.py'), 'utf8').replace('__CONFIG__', JSON.stringify(cfg).replace(/'/g, '\\u0027'));
}
const json = function (res, obj, code, extra) { send(res, code || 200, JSON.stringify(obj), 'application/json; charset=utf-8', extra); };
const fail = function (res, code, msg) { json(res, { error: msg }, code); };

function readBody(req, limit) {
  return new Promise(function (resolve, reject) {
    const chunks = []; let size = 0;
    req.on('data', function (c) { size += c.length; if (size > limit) { reject({ code: 413, msg: 'request too large' }); req.destroy(); } else chunks.push(c); });
    req.on('end', function () { resolve(Buffer.concat(chunks)); });
    req.on('error', function () { reject({ code: 400, msg: 'bad request' }); });
  });
}
async function jsonBody(req) {
  const raw = await readBody(req, 1024 * 1024);
  try { const b = JSON.parse(raw.toString() || '{}'); return (b && typeof b === 'object') ? b : {}; }
  catch (e) { throw { code: 400, msg: 'invalid JSON' }; }
}
function delay(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

async function handle(req, res) {
  const u = new URL(req.url, 'http://x');
  let p = u.pathname;
  if (p === '/otsense-central') p = '/'; else if (p.indexOf('/otsense-central/') === 0) p = p.slice(16);     // the console may sit in a sub-folder of the site
  const q = Object.fromEntries(u.searchParams.entries());
  if (req.method === 'GET' && (p === '/' || p === '/index.html')) return send(res, 200, loadPage(), 'text/html; charset=utf-8', { 'Cache-Control': 'no-store' });
  if (req.method === 'GET' && (p === '/login' || p === '/login.html' || p === '/login/')) return send(res, 200, loadLoginPage(), 'text/html; charset=utf-8', { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY' });
  if (req.method === 'GET' && /^\/vendor\/[a-z0-9.\-]{3,60}\.js$/.test(p)) {            // browser libraries you drop into public/vendor (e.g. guacamole-common.min.js)
    const vf = path.join(__dirname, 'public', 'vendor', path.basename(p));
    try { return send(res, 200, fs.readFileSync(vf), 'application/javascript; charset=utf-8', { 'Cache-Control': 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff' }); } catch (e) { return fail(res, 404, 'not found'); }
  }
  if (req.method === 'GET' && (p === '/healthz' || p === '/health')) return json(res, { ok: true, version: 'central-node' });   // /health is what the sensor page's "Test connection" calls

  /* ---- sensor endpoints (site token, no cookie) ---- */
  if (req.method === 'POST' && p === '/api/ingest') {
    const site = siteByToken(bearer(req));
    if (!site) { await delay(500); return fail(res, 401, 'invalid site token'); }
    if (!DB.tenants[site.tenant] || DB.tenants[site.tenant].status === 'suspended') return fail(res, 403, 'this organisation is suspended');
    if (!rateOk('i' + site.id, INGEST_PER_MIN)) return fail(res, 429, 'too many pushes - slow down');
    let raw = await readBody(req, MAX_BODY);
    if ((req.headers['content-encoding'] || '').toLowerCase() === 'gzip') {
      try { raw = zlib.gunzipSync(raw, { maxOutputLength: MAX_JSON }); } catch (e) { return fail(res, 400, 'bad gzip data'); }
    }
    let body;
    try { body = JSON.parse(raw.toString('utf8')); } catch (e) { return fail(res, 400, 'invalid JSON'); }
    if (!body || typeof body !== 'object' || Array.isArray(body)) return fail(res, 400, 'JSON object expected');
    // the reply carries central's orders for this sensor: scan_mode '' = the sensor decides, 'passive' / 'active' = central decides;
    // capture is a one-shot job (start a timed packet capture and upload it) the sensor should run and then clear by uploading its result.
    const accepted = ingestVia(site, body, bearer(req));
    if (Array.isArray(body.snmp)) { try { snmpStore(site, body.snmp); devAutoMerge(String(site.id)); } catch (e) { console.error('SNMP results ignored: ' + e.message); } }
    return json(res, { ok: true, site: site.name, accepted: accepted, scan_mode: site.scan_mode || '', capture: captureNext(String(site.id)), snmp: snmpOrders(site), ra: { on: !!(site.ra && site.ra.on) } });
  }
  if (p === '/api/ra/web/tunnel') return raWebTunnel(req, res, u);
  if (p.indexOf('/api/ra/h/') === 0) return raHelper(req, res, p, q);
  if (p.indexOf('/api/ra/s/') === 0) {
    const rs = siteByToken(bearer(req)); if (!rs) { await delay(500); return fail(res, 401, 'invalid site token'); }
    return raSensor(req, res, p, q, rs);
  }
  if (req.method === 'POST' && p === '/api/pcap-upload') {
    // a sensor delivering a capture: either a job central asked for (kind=manual, ref=the job id) or one it took on its own at
    // the moment an alert fired (kind=alert, ref=the alert's uid). Binary body, optionally gzip-compressed like /api/ingest.
    const site = siteByToken(bearer(req));
    if (!site) { await delay(500); return fail(res, 401, 'invalid site token'); }
    if (!rateOk('pc' + site.id, 20)) return fail(res, 429, 'too many pcap uploads - slow down');
    const kind = q.kind === 'alert' ? 'alert' : 'manual', ref = S(q.ref, 64);
    if (!ref) return fail(res, 400, 'ref required');
    let raw;
    try { raw = await readBody(req, PCAP_MAX_BYTES + 4096); } catch (e) { return fail(res, 413, 'pcap too large'); }
    if ((req.headers['content-encoding'] || '').toLowerCase() === 'gzip') {
      try { raw = zlib.gunzipSync(raw, { maxOutputLength: PCAP_MAX_BYTES }); } catch (e) { return fail(res, 400, 'bad gzip data'); }
    }
    const sid = String(site.id);
    let id;
    try { id = pcapSave(raw, { site: sid, kind: kind, ref: ref, label: S(q.label, 120) }); } catch (e) { return fail(res, 400, e.message); }
    if (kind === 'manual') {
      const j = (DB.ccmd[sid] || []).find(function (x) { return x.id === ref; });
      if (j) { j.status = 'done'; j.pcap = id; dirty = true; }
    } else {
      const a = (DB.alerts[sid] || {})[ref];
      if (a) { a.pcap = id; dirty = true; }
    }
    return json(res, { ok: true, id: id });
  }
  if (req.method === 'POST' && p === '/api/sensor-auth') {
    const site = siteByToken(bearer(req));
    if (!site) { await delay(500); return fail(res, 401, 'invalid site token'); }
    const ip = 's:' + clientIp(req);
    if (tooManyFails(ip)) return fail(res, 429, 'too many failed logins - wait a few minutes');
    const b = await jsonBody(req), name = S(b.user, 80), k = userKey(name), us = k ? DB.users[k] : null;
    // only users of the site's own organisation (and platform staff) may open this sensor's page
    const allowed = us && !us.disabled && (us.role === 'superadmin' || (us.tenant === site.tenant && (!(us.sites || []).length || us.sites.map(String).indexOf(String(site.id)) !== -1)));
    if (!allowed || !checkPw(b.password, us.pw)) {
      noteFail(ip); audit(name, 'sensor.login.fail', site.name, site.tenant); await delay(800);
      return fail(res, 401, 'wrong username or password');
    }
    fails.delete(ip); audit(k, 'sensor.login', site.name, site.tenant);
    return json(res, { ok: true, user: k, role: us.role === 'superadmin' ? 'admin' : us.role, site: site.name });
  }

  /* ---- branding (public, so the sign-in page can look like the client's) ---- */
  if (req.method === 'GET' && p === '/api/brand') {
    const t = hostTenant(req) || tenantBySlug(q.org);
    if (!t || t.status === 'suspended') return json(res, {});
    return json(res, Object.assign(brandOf(t), { sso: !!(t.sso && t.sso.enabled), host_locked: !!hostTenant(req), name: t.name }));
  }
  if (req.method === 'GET' && p === '/brand/logo') {
    const t = tenantBySlug(q.o), m = t && t.brand && t.brand.logo ? LOGO_RE.exec(t.brand.logo) : null;
    if (!m) return fail(res, 404, 'no logo');
    return send(res, 200, Buffer.from(m[2], 'base64'), 'image/' + m[1], { 'Cache-Control': 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; sandbox" });
  }
  /* ---- password reset and invitations (public) ---- */
  if (req.method === 'GET' && p === '/reset') return send(res, 200, resetPage(), 'text/html; charset=utf-8', { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
  if (req.method === 'POST' && p === '/api/reset/request') {
    const ip = clientIp(req);
    if (!rateOk('rr' + ip, 5)) return fail(res, 429, 'too many requests - wait a minute');
    const b = await jsonBody(req), who = S(b.user, 120).trim().toLowerCase();
    let k = userKey(who);
    if (!k && who.indexOf('@') > 0) { const m = Object.keys(DB.users).filter(function (n) { return String(DB.users[n].email || '').toLowerCase() === who; }); if (m.length === 1) k = m[0]; }
    const u = k ? DB.users[k] : null, tn = u && u.tenant ? DB.tenants[u.tenant] : null;
    if (u && !u.disabled && u.role !== undefined && smtpConf(u.tenant) && emailOf(k) && (!u.tenant || (tn && tn.status !== 'suspended')) && !(tn && tn.sso && tn.sso.enforce && !u.breakglass) && rateOk('rk' + k, 3)) {
      audit(k, 'password.reset.request', ip, u.tenant || null);
      mailLink(req, k, 'reset').then(function (e) { if (e) console.error('Reset mail failed: ' + e); });
    }
    await delay(300); return json(res, { ok: true });       // same answer whether or not the user exists
  }
  if (req.method === 'POST' && p === '/api/reset/complete') {
    const b = await jsonBody(req), h = sha(S(b.token, 200)), t = (DB.tokens || {})[h];
    if (!rateOk('rc' + clientIp(req), 10)) return fail(res, 429, 'too many attempts - wait a minute');
    if (!t || t.exp < Date.now() / 1000 || !hasOwn(DB.users, t.u)) { await delay(500); return fail(res, 400, 'this link has expired or was already used - ask for a new one'); }
    const u = DB.users[t.u], pr = pwProblem(b.password, t.u); if (pr) return fail(res, 400, pr);
    if (u.disabled) return fail(res, 403, 'this account is disabled');
    u.pw = hashPw(String(b.password)); u.must_change = false; u.pv = (u.pv || 0) + 1; u.fails = 0; u.lock_until = 0;
    dropTokens(t.u); dirty = true; audit(t.u, t.kind === 'invite' ? 'invite.accept' : 'password.reset', clientIp(req), u.tenant || null);
    return json(res, { ok: true });
  }

  /* ---- single sign-on ---- */
  if (req.method === 'GET' && p === '/api/sso/info') {        // login page asks whether an organisation uses SSO
    const t = tenantBySlug(q.org); return json(res, { sso: !!(t && t.status !== 'suspended' && t.sso && t.sso.enabled) });
  }
  if (req.method === 'GET' && p === '/sso/start') {
    const ht0 = hostTenant(req), t = ht0 || tenantBySlug(q.org);
    if (!t || t.status === 'suspended' || !t.sso || !t.sso.enabled) return ssoPage(res, 'Single sign-on is not set up for that organisation.');
    if (!rateOk('sso' + clientIp(req), 30)) return ssoPage(res, 'Too many attempts - wait a minute.');
    try {
      const cfg = await oidcConfig(t.sso.issuer), st = crypto.randomBytes(16).toString('hex'), nonce = crypto.randomBytes(16).toString('hex'), ver = crypto.randomBytes(32).toString('base64url');
      const au = new URL(cfg.authorization_endpoint);
      au.searchParams.set('response_type', 'code'); au.searchParams.set('client_id', t.sso.client_id); au.searchParams.set('redirect_uri', baseUrl(req) + '/sso/callback');
      au.searchParams.set('scope', 'openid email profile' + (t.sso.group_claim === 'groups' ? ' groups' : '')); au.searchParams.set('state', st); au.searchParams.set('nonce', nonce);
      au.searchParams.set('code_challenge', crypto.createHash('sha256').update(ver).digest('base64url')); au.searchParams.set('code_challenge_method', 'S256');
      const secure = req.headers['x-forwarded-proto'] === 'https' || req.socket.encrypted;
      res.writeHead(302, { Location: au.toString(), 'Set-Cookie': 'otsso=' + sigCookie({ s: st, n: nonce, v: ver, t: t.id, e: Date.now() + 600000 }) + '; Path=/sso; HttpOnly; SameSite=Lax; Max-Age=600' + (secure ? '; Secure' : ''), 'Cache-Control': 'no-store' });
      return res.end();
    } catch (e) { return ssoPage(res, 'Could not reach the identity provider: ' + e.message); }
  }
  if (req.method === 'GET' && p === '/sso/callback') {
    const ck = readSigCookie(req, 'otsso');
    if (!ck || !q.state || q.state !== ck.s) return ssoPage(res, 'The sign-in session expired. Start again.');
    const t = DB.tenants[ck.t];
    if (!t || t.status === 'suspended' || !t.sso || !t.sso.enabled) return ssoPage(res, 'Single sign-on is not available.');
    { const ht1 = hostTenant(req); if (ht1 && ht1.id !== t.id) return ssoPage(res, 'This address belongs to another organisation.'); }
    if (q.error || !q.code) return ssoPage(res, 'The identity provider refused the sign-in.');
    try {
      const conf = t.sso, cfg = await oidcConfig(conf.issuer), sec = conf.secret ? (pendOpen(conf.secret) || {}).s : '';
      const form = new URLSearchParams({ grant_type: 'authorization_code', code: q.code, redirect_uri: baseUrl(req) + '/sso/callback', client_id: conf.client_id, code_verifier: ck.v });
      if (sec) form.set('client_secret', sec);
      const tr = await ssoFetch(cfg.token_endpoint, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form.toString() });
      if (!tr.json || !tr.json.id_token) throw new Error('no id_token returned');
      const cl = await verifyIdToken(tr.json.id_token, cfg, conf, ck.n);
      const email = String(cl.email || '').toLowerCase(), dom = email.split('@')[1] || '';
      if (!email || cl.email_verified === false) throw new Error('the identity provider did not give a verified email address');
      if (verifiedDomains(t).indexOf(dom) === -1) throw new Error('email domain ' + dom + ' is not verified for this organisation');
      const role = ssoRole(conf, cl);
      let name = '';
      for (const n in DB.users) { const u = DB.users[n]; if (u.tenant === t.id && u.sso && u.sso.iss === conf.issuer && u.sso.sub === String(cl.sub)) { name = n; break; } }
      if (!name) { const k = userKey(email); if (k) { if (DB.users[k].tenant !== t.id || DB.users[k].role === 'superadmin') throw new Error('this email belongs to another account'); name = k; } }
      if (!name) {
        if (!role) throw new Error('no access has been granted to your account yet - ask your administrator');
        name = email; DB.users[name] = { pw: hashPw(tempPassword()), role: role, tenant: t.id, sites: [], email: email, disabled: false, must_change: false, pv: 0, created: Date.now() / 1000 };
        audit(name, 'user.sso.create', role, t.id);
      }
      const us = DB.users[name];
      if (us.disabled) throw new Error('this account is disabled - ask your administrator');
      if (!us.sso) us.sso = { iss: conf.issuer, sub: String(cl.sub) };
      if (conf.group_claim && role && us.role !== 'superadmin') us.role = role;     // roles follow the identity provider's groups
      us.last_login = Date.now() / 1000; us.must_change = false; dirty = true; audit(name, 'login.sso', clientIp(req), t.id);
      res.writeHead(302, { Location: '/', 'Set-Cookie': [cookieHeader(req, name), 'otsso=; Path=/sso; HttpOnly; Max-Age=0'], 'Cache-Control': 'no-store' });
      return res.end();
    } catch (e) { audit('sso', 'login.sso.fail', e.message, t.id); return ssoPage(res, e.message); }
  }

  /* ---- login ---- */
  if (req.method === 'POST' && p === '/api/login') {
    if (!/application\/json/.test(req.headers['content-type'] || '')) return fail(res, 415, 'JSON required');
    const ip = clientIp(req);
    if (tooManyFails(ip)) return fail(res, 429, 'too many failed logins - wait a few minutes');
    const b = await jsonBody(req), name = S(b.user, 80).trim(), k = userKey(name), us = k ? DB.users[k] : null, now = Date.now() / 1000;
    if (us && us.lock_until > now) { await delay(500); return fail(res, 429, 'this account is locked for a few minutes after too many wrong passwords'); }
    if (!us || !checkPw(b.password, us.pw)) {
      noteFail(ip);
      if (us) { us.fails = (us.fails || 0) + 1; if (us.fails >= 5) { us.lock_until = now + 900; us.fails = 0; audit(k, 'login.locked', ip); } dirty = true; }
      audit(name, 'login.fail', ip, us ? (us.tenant || null) : null); await delay(800);
      return fail(res, 401, 'wrong username or password');
    }
    const ht = hostTenant(req);
    if (ht && userOrgs(us).indexOf(ht.id) === -1) { noteFail(ip); await delay(800); return fail(res, 401, 'wrong username or password'); }    // an organisation's own address only signs in that organisation
    if (us.disabled) { await delay(500); return fail(res, 403, 'this account is disabled - ask your administrator'); }
    /* The sign-in page has two doors. "admin" is for platform administrators only. "org" lets in an organisation's own users.
       The organisation login name is optional: the account already knows its organisation. If the account belongs to several, the page shows a list to choose from. */
    const mode = b.mode === 'admin' ? 'admin' : b.mode === 'org' ? 'org' : '';
    if (mode === 'admin' && us.role !== 'superadmin') return fail(res, 403, 'this account belongs to an organisation - use the Organisation Login tab');
    if (mode === 'org' && us.role === 'superadmin') return fail(res, 403, 'platform administrators sign in on the OTSuraksha Admin tab');
    let selTid = us.tenant || null;
    if (us.role !== 'superadmin' && mode !== 'admin') {
      const mine = userOrgs(us), live = mine.filter(function (id) { return DB.tenants[id] && DB.tenants[id].status !== 'suspended'; }), asked = S(b.org, 60).trim();
      if (ht) selTid = ht.id;
      else if (asked) {
        const ot = tenantBySlug(asked);
        if (!ot || mine.indexOf(ot.id) === -1) { noteFail(ip); audit(k, 'login.fail.org', ip, us.tenant || null); await delay(800); return fail(res, 401, 'wrong organisation, username or password'); }
        selTid = ot.id;
      }
      else if (live.length > 1) return json(res, { ok: false, choose_org: live.map(function (id) { return { slug: DB.tenants[id].slug, name: DB.tenants[id].name }; }) });
      else selTid = live[0] || us.tenant;
      if (selTid && (!DB.tenants[selTid] || DB.tenants[selTid].status === 'suspended')) return fail(res, 403, 'this organisation is suspended');
    }
    const tn = selTid ? DB.tenants[selTid] : null;
    if (tn && tn.sso && tn.sso.enabled && tn.sso.enforce && !us.breakglass) return fail(res, 403, 'your organisation requires single sign-on');
    if (us.totp_on) {
      if (!b.code) return json(res, { ok: false, need_totp: true });
      if (!userTotpOk(us, b.code)) { noteFail(ip); audit(k, 'login.totp.fail', ip); await delay(800); return fail(res, 401, 'wrong authentication code'); }
    }
    fails.delete(ip); us.fails = 0; us.lock_until = 0; us.last_login = now; dirty = true; audit(k, 'login', ip);
    return json(res, { ok: true, user: k, role: us.role, must_change: !!us.must_change }, 200, { 'Set-Cookie': cookieHeader(req, k, selTid) });
  }
  if (req.method === 'POST' && p === '/api/logout') return json(res, { ok: true }, 200, { 'Set-Cookie': 'otc=; Path=/; HttpOnly; Max-Age=0' });

  /* ---- everything below needs a console login ---- */
  let me = null;
  const btok = bearer(req);
  if (btok.indexOf('otsk_') === 0) {                         // read-only API key of one organisation
    const kk = findKey(btok);
    if (!kk || kk.t.status === 'suspended') { await delay(300); return fail(res, 401, 'invalid API key'); }
    if (req.method !== 'GET') return fail(res, 403, 'API keys are read-only');
    kk.k.last = Date.now() / 1000;
    me = { name: 'api:' + kk.k.name, role: 'viewer', tenant: kk.t.id, sites: [], must_change: false, theme: '', api: true };
  } else me = readCookie(req);
  if (!me) return fail(res, 401, 'sign in required');
  me.isSuper = me.role === 'superadmin';
  const isAdmin = me.role === 'admin' || me.isSuper, canHandle = me.role !== 'viewer';
  const scope = scopeOf(me, me.isSuper ? (q.tenant || '') : '');       // the sites this user may see; everything below goes through it
  const inScope = function (sid) { return scope.has(String(sid)); };
  if (req.method === 'POST' && !/application\/json/.test(req.headers['content-type'] || '')) return fail(res, 415, 'JSON required');
  if (me.must_change && p !== '/api/me' && p !== '/api/password' && p !== '/api/me/password') return fail(res, 403, 'password change required');

  if (req.method === 'GET') {
    if (p === '/api/me') return json(res, { user: me.name, role: me.role, tenant: me.tenant, tenant_name: me.tenant ? tenantName(me.tenant) : '', must_change: me.must_change, theme: me.theme || ((DB.tenants[me.tenant] || {}).theme || ''),
      brand: me.tenant ? brandOf(DB.tenants[me.tenant]) : {}, mail: !!smtpConf(me.tenant), totp: !!(DB.users[me.name] || {}).totp_on, sso: !!(DB.users[me.name] || {}).sso, tenant_slug: me.tenant ? (DB.tenants[me.tenant] || {}).slug : '' });
    if (p === '/api/ra') {
      const st = raStore(), rows = Object.values(st.s).filter(function (x) { return inScope(x.site); }).sort(function (a, b) { return b.created - a.created; }).slice(0, 300).map(function (x) { return raView(x, me); });
      const sites = Array.from(scope).filter(function (id) { return DB.sites[id]; }).map(function (id) { const r = raSite(id); return { id: id, name: DB.sites[id].name, tenant: tenantName(DB.sites[id].tenant), on: !!r.on, ports: r.ports, self: !!r.self, maxmin: r.maxmin, online: (Date.now() / 1000 - (DB.sites[id].last_seen || 0)) < 180 }; });
      return json(res, { sessions: rows, sites: sites, admin: isAdmin, can_request: canHandle, default_ports: RA_PORTS });
    }
    if (p === '/api/ra/helper') {
      const s = raStore().s[S(q.id, 30)]; if (!s || !inScope(s.site)) return fail(res, 404, 'session not found');
      if (s.by !== me.name) return fail(res, 403, 'only the person who requested the session can download its helper');
      if (!raLive(s)) return fail(res, 409, 'the session is not approved, or its time is over');
      const base = S(q.base, 300).replace(/\/+$/, ''); if (!/^https?:\/\/[^\s'"<>]+$/.test(base)) return fail(res, 400, 'bad address');
      audit(me.name, 'ra.helper', s.id + ' ' + s.ip, (DB.sites[s.site] || {}).tenant || null);
      const body = Buffer.from(raHelperFile(s, base));
      res.writeHead(200, { 'Content-Type': 'text/x-python; charset=utf-8', 'Content-Length': body.length, 'Content-Disposition': 'attachment; filename="otsuraksha-helper-' + s.id + '.py"', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
      return res.end(body);
    }
    if (p === '/api/policies') {
      const key = me.tenant || '', pick = me.isSuper ? (q.tenant || '') : key, mine = function (x) { return (me.isSuper && !pick) || x.tenant === '' || x.tenant === pick; }, cnt = {};
      for (const sid in DB.alerts) if (inScope(sid)) for (const u in DB.alerts[sid]) { const a = DB.alerts[sid][u]; if (a.kind === 'policy' && a.status !== 'closed') cnt[a.policy_id] = (cnt[a.policy_id] || 0) + 1; }
      return json(res, { policies: (DB.policies || []).filter(mine).map(function (x) { return Object.assign({}, x, { alerts: cnt[x.id] || 0, editable: me.isSuper || x.tenant === key }); }),
        wlists: (DB.wlists || []).filter(mine).map(function (x) { return Object.assign({}, x, { editable: me.isSuper || x.tenant === key }); }),
        fields: POL_FIELDS, ops: POL_OPS, kinds: POL_KINDS, sites: Array.from(scope).filter(function (id) { return DB.sites[id]; }).map(function (id) { return { id: id, name: DB.sites[id].name }; }) });
    }
    if (p === '/api/image/dl') {      // plain download of a built image (the Raspberry Pi image is not stamped; the ISO here has an empty slot)
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const t = IMG_TARGETS[u.searchParams.get('t') || ''], fp = t && path.join(imageDir(), t.file);
      let st = null; try { st = fp && fs.statSync(fp); } catch (e) {}
      if (!st) return fail(res, 404, 'not built yet');
      audit(me.name, 'image.download', t.file);
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': st.size, 'Content-Disposition': 'attachment; filename="' + t.file + '"' });
      return fs.createReadStream(fp).pipe(res);
    }
    if (p === '/api/images') { if (!isAdmin) return fail(res, 403, 'admin only'); return json(res, me.isSuper ? { dir: imageDir(), images: listBases() } : { images: listBases() }); }
    if (p === '/api/image/status') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const st = imgStatus();
      return json(res, me.isSuper ? st : { exists: st.exists, running: false, can_build: false, targets: st.targets.map(function (t) { return { id: t.id, label: t.label, exists: t.exists, import_only: t.import_only }; }) });
    }
    if (p === '/api/sensors/platforms') { if (!isAdmin) return fail(res, 403, 'admin only'); return json(res, Object.keys(sensorBuild.PLATFORMS).map(function (k) { return { id: k, label: sensorBuild.PLATFORMS[k].label, seed: sensorBuild.PLATFORMS[k].seed }; })); }
    if (p === '/api/sensors/dl') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const bd = BUILDS.get(q.id), f = bd && bd.files.find(function (x) { return x.name === q.f; });
      if (!f || bd.exp < Date.now()) return fail(res, 404, 'download expired - build the sensor again');
      audit(me.name, 'sensor.download', f.name);
      return sendBuildFile(res, f);
    }
    if (p === '/api/sites/pending') {       // settings of a sensor that has not connected yet (for the Edit form); never returns the token
      if (!isAdmin) return fail(res, 403, 'admin only');
      const s = DB.sites[q.id], pd = s && inScope(s.id) && s.pending && pendOpen(s.pending.blob);
      if (!pd) return fail(res, 404, 'no stored sensor files for this site (the sensor has already connected, or none was built)');
      return json(res, { name: s.name, opts: pd.opts, console_password: pd.pw, files: s.pending.files });
    }
    if (p === '/api/sites/dl') {            // re-download the ISO / Windows app of a sensor that has not connected yet
      if (!isAdmin) return fail(res, 403, 'admin only');
      const s = DB.sites[q.id], xs = s && q.sensor ? (s.sensors2 || []).find(function (x) { return x.id === q.sensor; }) : null, pd = s && inScope(s.id) && (xs ? xs.pending : s.pending) && pendOpen((xs ? xs.pending : s.pending).blob);
      if (!pd) return fail(res, 404, 'no stored sensor files for this site (the sensor has already connected, or none was built)');
      let r; try { r = sensorBuild.build(s.name, pd.token, pd.opts, Object.assign(buildCtx(String(pd.opts.base || '')), { pw: pd.pw })); } catch (e) { return fail(res, 400, e.message); }
      const f = r.files.find(function (x) { return x.name === q.f; });
      if (!f) return fail(res, 404, 'file not found');
      audit(me.name, 'sensor.download', s.name + ' / ' + f.name);
      return sendBuildFile(res, f);
    }
    if (p === '/api/sites') return json(res, sitesList(scope));
    if (p === '/api/overview') return json(res, overview(q, scope));
    if (p === '/api/assets' || p === '/api/alerts' || p === '/api/flows') return json(res, listRows(p.slice(5), q, undefined, scope));
    if (p === '/api/activities') return json(res, listActivities(q, undefined, scope));
    if (p === '/api/search/related') return json(res, searchRelated(q, scope));
    if (p === '/api/search/values') return json(res, searchValues(({ assets: 'assets', alerts: 'alerts', flows: 'flows', activity: 'activities', activities: 'activities', vulns: 'vulns' })[String(q.kind || '')] || 'assets', String(q.field || ''), q, scope));
    if (p === '/api/asset') { const d = inScope(q.site) ? assetDetail(q.site, q.id || '', 0, scope) : null; return d ? json(res, d) : fail(res, 404, 'asset not found'); }
    if (p === '/api/map') return inScope(q.site) ? json(res, topo(q.site)) : fail(res, 404, 'site not found');
    if (p === '/api/zones') {
      if (!inScope(q.site)) return fail(res, 404, 'site not found');
      const sid = String(q.site), vv = {};      // VLAN ids seen in 802.1Q tags of this site's traffic
      Object.values(DB.assets[sid] || {}).forEach(function (a) {
        ((a.data && a.data.vlans) || []).forEach(function (v) {
          v = parseInt(v, 10); if (!(v >= 0)) return;
          const e = vv[v] = vv[v] || { id: v, devices: 0, subnets: {}, last_seen: '' };
          e.devices++; if (zIpOk(a.ip || '')) e.subnets[a.ip.split('.').slice(0, 3).join('.') + '.0/24'] = 1;
          if ((a.last_seen || '') > e.last_seen) e.last_seen = a.last_seen;
        });
      });
      const vlans = Object.values(vv).sort(function (x, y) { return x.id - y.id; }).map(function (e) { return { id: e.id, devices: e.devices, subnets: Object.keys(e.subnets).slice(0, 6), last_seen: e.last_seen }; });
      return json(res, { zones: (DB.zones || {})[sid] || [], saved: !!(DB.zones || {})[sid], vlans: vlans, rules: (DB.fwrules || {})[sid] || {} });
    }
    if (p === '/api/capture/jobs') {
      const sid = String(q.site || ''); if (!inScope(sid)) return fail(res, 404, 'site not found');
      return json(res, { jobs: captureJobs(sid) });
    }
    if (p === '/api/pcap') {
      const meta = DB.pcaps[S(q.id, 40)];
      if (!meta || !inScope(meta.site)) return fail(res, 404, 'not found, or it has aged off (captures are kept 30 days)');
      let buf;
      try { buf = fs.readFileSync(pcapPath(meta.id)); } catch (e) { return fail(res, 404, 'the file is missing on disk'); }
      audit(me.name, 'capture.download', (DB.sites[meta.site] || {}).name + ' (' + meta.kind + ')');
      const fn = (meta.label || meta.kind + '-' + meta.id).replace(/[^a-z0-9_.-]/gi, '_') + '.pcap';
      return send(res, 200, buf, 'application/vnd.tcpdump.pcap', { 'Content-Disposition': 'attachment; filename="' + fn + '"' });
    }
    if (p === '/api/vulns') return json(res, vulnList(scope, q));
    if (p === '/api/vulns/summary') return json(res, vulnSummary(scope, q.site ? String(q.site) : ''));
    if (p === '/api/vulns/plan') {        // remediation plan: open findings worth working on next, overdue first
      const only = q.site && inScope(q.site) ? String(q.site) : '', now = Date.now() / 1000;
      const open = vulnAll(scope, only).filter(function (f) { return VOPEN(f.status); });
      const owners = {}; open.forEach(function (f) { const k = f.owner || 'Unassigned'; owners[k] = (owners[k] || 0) + 1; });
      return json(res, { overdue: open.filter(function (f) { return f.overdue; }).length, due_soon: open.filter(function (f) { return !f.overdue && f.due - now < 7 * 86400; }).length,
        unassigned: open.filter(function (f) { return !f.owner; }).length, by_owner: Object.keys(owners).sort(function (a, b) { return owners[b] - owners[a]; }).map(function (k) { return { k: k, n: owners[k] }; }) });
    }
    if (p === '/api/vulns/one') {         // one finding with its full description and standard resolution
      if (!inScope(q.site)) return fail(res, 404, 'not found');
      const f = vulnOfOneAsset(String(q.site), String(q.asset || '')).find(function (x) { return x.vid === q.vid; });
      if (!f) return fail(res, 404, 'finding not found (it may have been fixed)');
      const same = vulnAll(scope, '').filter(function (x) { return x.vid === f.vid && VOPEN(x.status); }).length;
      return json(res, Object.assign(vulnDetail(f, tenantOfSite(f.site)), { same_count: same }));
    }
    if (p === '/api/vulns/report') {
      const kind = ['executive', 'detailed', 'remediation', 'plan', 'csv'].indexOf(q.kind) !== -1 ? q.kind : 'executive', only = q.site && inScope(q.site) ? String(q.site) : '';
      const rows = vulnList(scope, Object.assign({}, q, { page: 1, limit: 100000, status: q.status || 'active', sort: kind === 'plan' ? 'due' : '' })).rows;
      audit(me.name, 'vuln.report', kind + (only ? ' site ' + only : ''));
      if (kind === 'csv') return send(res, 200, vulnCsv(rows), 'text/csv; charset=utf-8', { 'Content-Disposition': 'attachment; filename="otsense-vulnerabilities.csv"' });
      const org = me.tenant ? tenantName(me.tenant) : (only ? tenantName(tenantOfSite(only)) : (q.tenant ? tenantName(q.tenant) : 'All organisations'));
      return send(res, 200, vulnReport(kind, rows, { org: org, site: only ? (DB.sites[only] || {}).name : '', by: me.name }), 'text/html; charset=utf-8');
    }
    if (p === '/api/vulns/rules') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const tk = me.tenant || S(q.tenant, 60) || 'default';
      return json(res, { custom: (DB.vrules || {})[tk] || [], builtin: VRULES.map(function (r) { return { id: r.id, title: r.title, severity: r.severity, cve: r.cve }; }) });
    }
    if (p === '/api/risk') {            // IEC 62443 maturity + NIST CSF 2.0 + risk register for one site, from this console's own data
      if (!inScope(q.site)) return fail(res, 404, 'site not found');
      return json(res, rkResponse(String(q.site), q.catalog !== '0', q.fresh === '1'));
    }
    if (p === '/api/risk/export') {
      if (!inScope(q.site)) return fail(res, 404, 'site not found');
      const kind = q.kind === 'register' ? 'register' : 'assessment', m = rkResponse(String(q.site), false);
      audit(me.name, 'risk.export', kind + ' site ' + q.site);
      return send(res, 200, rkCsv(kind, m), 'text/csv; charset=utf-8', { 'Content-Disposition': 'attachment; filename="otsense-risk-' + kind + '.csv"' });
    }
    if (p === '/api/risk/report') {
      if (!inScope(q.site)) return fail(res, 404, 'site not found');
      const m = rkResponse(String(q.site), false, true);
      audit(me.name, 'risk.report', 'site ' + q.site);
      return send(res, 200, rkReport(m, { org: tenantName(tenantOfSite(String(q.site))), by: me.name }), 'text/html; charset=utf-8');
    }
    if (p === '/api/export') {
      const kind = ['assets', 'alerts', 'flows', 'activities'].indexOf(q.kind) !== -1 ? q.kind : 'assets';
      audit(me.name, 'export', kind);
      const rows = kind === 'activities' ? listActivities(q, 200000, scope).rows : listRows(kind, Object.assign({}, q, { page: 1 }), 100000, scope).rows;
      return send(res, 200, toCsv(kind, rows), 'text/csv; charset=utf-8',
        { 'Content-Disposition': 'attachment; filename="otsense-' + kind + '.csv"' });
    }
    if (p === '/api/integrations') {
      if (!isAdmin || me.api) return fail(res, 403, 'admin only');
      const t = DB.tenants[me.tenant || (me.isSuper ? S(q.tenant, 60) : '')]; if (!t) return fail(res, 404, 'choose an organisation first');
      return json(res, { tenant: t.id, name: t.name, sso: !!(t.sso && t.sso.enabled), keys: (t.keys || []).length, feeds: intView(t), mail: !!smtpConf(t.id), min: INT_MIN });
    }
    if (p === '/api/snmp' || p === '/api/snmp/topology') {
      const sid = String(q.site || ''); if (!sid || !DB.sites[sid] || !inScope(sid)) return fail(res, 404, 'site not found');
      if (p === '/api/snmp/topology') return json(res, snmpTopo(sid));
      if (!isAdmin || me.api) return fail(res, 403, 'admin only');
      return json(res, snmpView(DB.sites[sid]));
    }
    if (p === '/api/integrations/mail') {
      if (!isAdmin || me.api) return fail(res, 403, 'admin only');
      const t = DB.tenants[me.tenant || (me.isSuper ? S(q.tenant, 60) : '')]; if (!t) return fail(res, 404, 'choose an organisation first');
      const o = t.smtp || {};
      return json(res, { own: !!o.host, host: o.host || '', port: o.port || 587, mode: o.mode || 'starttls', user: o.user || '', from: o.from || '', has_pass: !!o.pass, platform_ready: !!smtpConf() });
    }
    if (p === '/api/smtp') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const c = smtpConf(); return json(res, c ? { configured: true, host: c.host, port: c.port, mode: c.mode, user: c.user, from: c.from, has_pass: !!c.pass, source: c.source } : { configured: false });
    }
    if (p === '/api/audit/export') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const rows = me.isSuper ? (q.tenant ? DB.audit.filter(function (a) { return a.tenant === q.tenant; }) : DB.audit) : DB.audit.filter(function (a) { return a.tenant === me.tenant; });
      audit(me.name, 'audit.export', rows.length + ' rows');
      return send(res, 200, auditExport(rows), 'text/csv; charset=utf-8', { 'Content-Disposition': 'attachment; filename="audit.csv"' });
    }
    if (p === '/api/org/info') {
      if (!isAdmin || me.api) return fail(res, 403, 'admin only');
      const t = DB.tenants[me.tenant || q.tenant || '']; if (!t) return fail(res, 404, 'choose an organisation first');
      return json(res, Object.assign(brandOf(t), { name: t.name, hosts: t.hosts || [], theme: t.theme || '' }));
    }
    if (p === '/api/keys') {
      if (!isAdmin || me.api) return fail(res, 403, 'admin only');
      const t = DB.tenants[me.tenant || q.tenant || '']; if (!t) return json(res, []);
      return json(res, (t.keys || []).map(function (k) { return { id: k.id, name: k.name, created: k.created, last: k.last || 0, prefix: k.prefix }; }));
    }
    if (p === '/api/sso') {
      if (!isAdmin || me.api) return fail(res, 403, 'admin only');
      const t = DB.tenants[me.tenant || q.tenant || '']; if (!t) return fail(res, 404, 'choose an organisation first');
      return json(res, Object.assign(ssoView(t), { redirect_uri: baseUrl(req) + '/sso/callback', login_name: t.slug }));
    }
    if (p === '/api/tenants/export') {
      const tid = me.isSuper ? S(q.id, 60) : me.tenant;
      if (!isAdmin || me.api || !DB.tenants[tid]) return fail(res, 403, 'admin only');
      audit(me.name, 'tenant.export', DB.tenants[tid].name, tid);
      return send(res, 200, zlib.gzipSync(JSON.stringify(tenantExport(tid))), 'application/gzip', { 'Content-Disposition': 'attachment; filename="' + DB.tenants[tid].slug + '-export.json.gz"', 'Cache-Control': 'no-store' });
    }
    if (p === '/api/audit') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const rows = me.isSuper ? (q.tenant ? DB.audit.filter(function (a) { return a.tenant === q.tenant; }) : DB.audit) : DB.audit.filter(function (a) { return a.tenant === me.tenant; });
      return json(res, rows.slice(0, 150));
    }
    if (p === '/api/users') { if (!isAdmin) return fail(res, 403, 'admin only'); return json(res, Object.keys(DB.users).filter(function (n) { const u = DB.users[n]; return me.isSuper ? (!q.tenant || (u.tenant === q.tenant && u.role !== 'superadmin')) : u.tenant === me.tenant; }).map(function (n) { return userView(n); })); }
    if (p === '/api/tenants') { if (!me.isSuper) return fail(res, 403, 'platform admin only'); return json(res, tenantsList()); }
    return fail(res, 404, 'not found');
  }

  if (req.method === 'POST') {
    const b = await jsonBody(req);
    if (p === '/api/password' || p === '/api/me/password') {
      const us = DB.users[me.name];
      if (!checkPw(b.old, us.pw)) { audit(me.name, 'password.change.fail', ''); await delay(800); return fail(res, 403, 'current password is wrong'); }
      const pr = pwProblem(b.new, me.name); if (pr) return fail(res, 400, pr);
      if (checkPw(b.new, us.pw)) return fail(res, 400, 'choose a password different from the current one');
      us.pw = hashPw(String(b.new)); us.must_change = false; us.pv = (us.pv || 0) + 1; dirty = true; audit(me.name, 'password.change', '');
      return json(res, { ok: true }, 200, { 'Set-Cookie': cookieHeader(req, me.name) });   // every older session ends; this one continues
    }
    if (p === '/api/me/prefs') {
      const t = String(b.theme || '');
      if (['light', 'dark', 'system'].indexOf(t) === -1) return fail(res, 400, 'theme must be light, dark or system');
      DB.users[me.name].theme = t; dirty = true;
      return json(res, { ok: true, theme: t });
    }
    if (p === '/api/policies/save' || p === '/api/policies/toggle' || p === '/api/policies/delete' || p === '/api/policies/run' || p === '/api/whitelist/add' || p === '/api/whitelist/delete' || p === '/api/whitelist/from-alert' || p === '/api/whitelist/list/save' || p === '/api/whitelist/list/delete') {
      const key = me.tenant || '', own = function (x) { return me.isSuper || x.tenant === key; };
      const polById = function (id) { return (DB.policies || []).filter(function (x) { return x.id === S(id, 20); })[0]; };
      const wlById = function (id) { return (DB.wlists || []).filter(function (x) { return x.id === S(id, 20); })[0]; };
      const wlCheck = function (kind, val) {
        if (POL_KINDS.indexOf(kind) === -1 || !val) return 'kind and value required';
        if (kind === 'ip' && ipNum(val) === null) return 'not a valid IPv4 address';
        if (kind === 'cidr' && !val.split(',').every(function (c) { return /^\d+\.\d+\.\d+\.\d+(\/\d{1,2})?$/.test(c.trim()); })) return 'not a valid network (example 10.1.2.0/24)';
        return '';
      };
      const wlTaken = function (name, tenant, exceptId) { return (DB.wlists || []).some(function (x) { return x.tenant === tenant && x.id !== exceptId && x.name.toLowerCase() === name.toLowerCase(); }); };
      const wlPush = function (l, kind, val, note) {
        if (l.entries.some(function (x) { return x.kind === kind && String(x.value).toLowerCase() === val.toLowerCase(); })) return null;
        const e = { id: 'w' + (DB.pol_seq++), kind: kind, value: val, note: note, by: me.name, at: Date.now() / 1000 }; l.entries.push(e); return e;
      };
      if (p === '/api/whitelist/from-alert') {                      // add the alert's device / address to a named whitelist (existing or new) and attach that list to the alert's policy
        if (!canHandle) return fail(res, 403, 'viewers cannot whitelist');
        const a = inScope(b.site) ? (DB.alerts[String(b.site)] || {})[String(b.uid)] : null;
        if (!a || !a.policy_id || !a.wl_value) return fail(res, 400, 'this alert cannot be whitelisted');
        let l = b.list ? wlById(b.list) : null;
        if (b.list && (!l || !own(l))) return fail(res, 403, 'not your whitelist');
        if (!l) {
          const name = S(b.name, 80).trim(); if (!name) return fail(res, 400, 'give the new whitelist a name');
          if (wlTaken(name, key, '')) return fail(res, 400, 'a whitelist with that name already exists');
          l = { id: 'L' + (DB.pol_seq++), tenant: key, name: name, description: '', all: false, policies: [], entries: [], by: me.name, at: Date.now() / 1000 }; DB.wlists.push(l);
        }
        wlPush(l, a.wl_kind || 'ip', S(a.wl_value, 200), S(b.note, 200) || 'from alert');
        if (!l.all && l.policies.indexOf(a.policy_id) === -1) l.policies.push(a.policy_id);
        dirty = true; audit(me.name, 'whitelist.add', l.name + ': ' + (a.wl_kind || 'ip') + ' ' + a.wl_value); evalAllPolicies();
        return json(res, { ok: true, list: l.id });
      }
      if (!isAdmin) return fail(res, 403, 'admin only');
      if (p === '/api/policies/run') { evalAllPolicies(); return json(res, { ok: true }); }
      if (p === '/api/whitelist/list/save') {
        const old = b.id ? wlById(b.id) : null;
        if (old && !own(old)) return fail(res, 403, 'not your whitelist');
        const name = S(b.name, 80).trim(); if (!name) return fail(res, 400, 'give the whitelist a name');
        const tenant = old ? old.tenant : key;
        if (wlTaken(name, tenant, old ? old.id : '')) return fail(res, 400, 'a whitelist with that name already exists');
        const pols = (Array.isArray(b.policies) ? b.policies : []).map(String).filter(function (id, i, arr) { return polById(id) && arr.indexOf(id) === i; });
        const rec = { id: old ? old.id : 'L' + (DB.pol_seq++), tenant: tenant, name: name, description: S(b.description, 300), all: !!b.all, policies: pols, entries: old ? old.entries : [], by: me.name, at: Date.now() / 1000 };
        if (old) Object.assign(old, rec); else DB.wlists.push(rec);
        dirty = true; audit(me.name, 'whitelist.save', rec.name); evalAllPolicies();
        return json(res, { ok: true, id: rec.id });
      }
      if (p === '/api/whitelist/list/delete') {
        const l = wlById(b.id); if (!l || !own(l)) return fail(res, 404, 'not found');
        DB.wlists.splice(DB.wlists.indexOf(l), 1); dirty = true; audit(me.name, 'whitelist.delete', l.name); evalAllPolicies();
        return json(res, { ok: true });
      }
      if (p === '/api/whitelist/add') {
        const l = wlById(b.list); if (!l || !own(l)) return fail(res, 404, 'whitelist not found');
        const kind = S(b.kind, 20), val = S(b.value, 200).trim(), er = wlCheck(kind, val); if (er) return fail(res, 400, er);
        const e = wlPush(l, kind, val, S(b.note, 200)); if (!e) return fail(res, 400, 'that entry is already in this whitelist');
        dirty = true; audit(me.name, 'whitelist.add', l.name + ': ' + kind + ' ' + val); evalAllPolicies();
        return json(res, { ok: true, id: e.id });
      }
      if (p === '/api/whitelist/delete') {
        const l = wlById(b.list); if (!l || !own(l)) return fail(res, 404, 'whitelist not found');
        const i = l.entries.findIndex(function (x) { return x.id === S(b.id, 20); }); if (i < 0) return fail(res, 404, 'not found');
        const e = l.entries.splice(i, 1)[0]; dirty = true; audit(me.name, 'whitelist.delete', l.name + ': ' + e.kind + ' ' + e.value); evalAllPolicies();
        return json(res, { ok: true });
      }
      if (p === '/api/policies/toggle' || p === '/api/policies/delete') {
        const pol = polById(b.id);
        if (!pol || !(own(pol) || p === '/api/policies/toggle')) return fail(res, 404, 'not found');
        if (p === '/api/policies/toggle') { pol.enabled = !!b.enabled; pol.updated = Date.now() / 1000; pol.by = me.name; audit(me.name, 'policy.' + (pol.enabled ? 'enable' : 'disable'), pol.id + ' ' + pol.title); }
        else { if (pol.builtin) return fail(res, 400, 'built-in policies can only be disabled'); DB.policies.splice(DB.policies.indexOf(pol), 1); (DB.wlists || []).forEach(function (l) { const j = (l.policies || []).indexOf(pol.id); if (j !== -1) l.policies.splice(j, 1); }); audit(me.name, 'policy.delete', pol.id + ' ' + pol.title); }
        dirty = true; evalAllPolicies(); return json(res, { ok: true });
      }
      const old = b.id ? polById(b.id) : null;                       // policies/save
      if (old && !own(old)) return fail(res, 403, 'not your policy');
      const type = POL_FIELDS[b.type] ? b.type : null, title = S(b.title, 120).trim();
      if (!type) return fail(res, 400, 'bad type');
      if (!title) return fail(res, 400, 'give the policy a title');
      const ok = POL_FIELDS[type].map(function (f) { return f[0]; });
      const conds = (Array.isArray(b.conds) ? b.conds : []).slice(0, 12).map(function (c) { return { f: S(c && c.f, 30), op: S(c && c.op, 20), v: S(c && c.v, 500).trim() }; })
        .filter(function (c) { return ok.indexOf(c.f) !== -1 && POL_OPS.some(function (o) { return o[0] === c.op; }) && c.v !== ''; });
      if (!conds.length) return fail(res, 400, 'add at least one condition');
      const rec = { id: old ? old.id : String(DB.pol_seq++), tenant: old ? old.tenant : key, title: title, description: S(b.description, 500), enabled: !!b.enabled, type: type, match: b.match === 'any' ? 'any' : 'all', conds: conds,
        severity: POL_SEV.indexOf(b.severity) !== -1 ? b.severity : 'medium', sites: (Array.isArray(b.sites) ? b.sites : []).map(String).filter(function (x) { return DB.sites[x] && inScope(x); }),
        labels: (Array.isArray(b.labels) ? b.labels : S(b.labels, 200).split(',')).map(function (x) { return S(x, 30).trim(); }).filter(Boolean).slice(0, 8), mitre: S(b.mitre, 80), builtin: old ? !!old.builtin : false, updated: Date.now() / 1000, by: me.name };
      if (old) Object.assign(old, rec); else DB.policies.push(rec);
      if (Array.isArray(b.whitelists)) {                              // which whitelists this policy uses (only lists the person can edit and was shown)
        const want = b.whitelists.map(String), shown = (Array.isArray(b.whitelists_shown) ? b.whitelists_shown : []).map(String);
        (DB.wlists || []).forEach(function (l) {
          if (!own(l) || l.all || shown.indexOf(l.id) === -1) return;
          const j = l.policies.indexOf(rec.id);
          if (want.indexOf(l.id) !== -1 && j === -1) l.policies.push(rec.id); else if (want.indexOf(l.id) === -1 && j !== -1) l.policies.splice(j, 1);
        });
      }
      dirty = true; audit(me.name, 'policy.save', rec.id + ' ' + rec.title); evalAllPolicies();
      return json(res, { ok: true, id: rec.id });
    }
    if (p === '/api/alerts/status') {
      if (!canHandle) return fail(res, 403, 'viewers cannot change alerts');
      const st = ['new', 'ack', 'closed'].indexOf(b.status) !== -1 ? b.status : null;
      if (!st) return fail(res, 400, 'bad status');
      let n = 0;
      (Array.isArray(b.items) ? b.items : []).slice(0, 500).forEach(function (it) {
        const a = inScope(it.site) ? (DB.alerts[String(it.site)] || {})[String(it.uid)] : null;
        if (a) { a.status = st; a.note = S(b.note, 300); a.handled_by = me.name; a.handled_at = Date.now() / 1000; n++; }
      });
      dirty = true; audit(me.name, 'alert.' + st, n + ' alert(s)');
      return json(res, { ok: true, changed: n });
    }
    if (p === '/api/capture/start') {
      if (!canHandle) return fail(res, 403, 'viewers cannot start a capture');
      const sid = String(b.site || '');
      if (!inScope(sid)) return fail(res, 404, 'site not found');
      const pending = (DB.ccmd[sid] || []).filter(function (j) { return j.status === 'pending' || j.status === 'sent'; });
      if (pending.length) return fail(res, 409, 'a capture is already pending or running on this sensor');
      if (/[^a-z0-9 .:&|!()_\-\/]/i.test(b.bpf || '')) return fail(res, 400, 'that filter has characters a capture filter cannot use');
      const id = captureStart(sid, b.seconds, b.bpf, b.label, me.name);
      audit(me.name, 'capture.start', (DB.sites[sid] || {}).name + ', ' + (parseInt(b.seconds, 10) || 60) + 's' + (b.bpf ? ' (' + b.bpf + ')' : ''));
      return json(res, { ok: true, id: id });
    }
    if (p === '/api/capture/cancel') {
      if (!canHandle) return fail(res, 403, 'viewers cannot cancel a capture');
      const sid = String(b.site || ''); if (!inScope(sid)) return fail(res, 404, 'site not found');
      const j = (DB.ccmd[sid] || []).find(function (x) { return x.id === S(b.id, 40) && (x.status === 'pending' || x.status === 'sent'); });
      if (!j) return fail(res, 404, 'nothing pending to cancel');
      j.status = 'error'; j.error = 'cancelled'; dirty = true;
      return json(res, { ok: true });
    }
    if (p === '/api/vulns/status') {
      if (!canHandle) return fail(res, 403, 'viewers cannot change vulnerabilities');
      const st = VSTATUS.indexOf(b.status) !== -1 ? b.status : null, note = S(b.note, 300).trim();
      if (!st) return fail(res, 400, 'bad status');
      if ((st === 'accepted' || st === 'false_positive') && !note) return fail(res, 400, 'please give a short reason');
      let items = (Array.isArray(b.items) ? b.items : []).slice(0, 500).map(function (it) { return { site: String(it.site), asset: String(it.asset), vid: String(it.vid) }; });
      if (b.all_vid && items.length) {      // the same vulnerability on every device this person may see
        const vid = items[0].vid;
        items = vulnAll(scope, '').filter(function (f) { return f.vid === vid; }).slice(0, 5000).map(function (f) { return { site: f.site, asset: f.asset, vid: f.vid }; });
      }
      const ownerGiven = b.owner !== undefined, owner = ownerGiven ? S(b.owner, 80).trim() : '', dueGiven = b.due !== undefined, due = dueGiven ? (Math.floor(+b.due) || 0) : 0;
      DB.vstate = DB.vstate || {};
      let n = 0;
      items.forEach(function (it) {
        if (!inScope(it.site) || !vulnOfOneAsset(it.site, it.asset).some(function (f) { return f.vid === it.vid; })) return;
        const dv0 = devGet(it.site, it.asset), k = vstateKey(it.site, dv0 ? dv0.id : it.asset, it.vid), cur = DB.vstate[k] || {};
        const o2 = ownerGiven ? owner : (cur.owner || ''), d2 = dueGiven ? due : (cur.due || 0), note2 = note || (st === cur.status ? (cur.note || '') : '');
        if (st === 'open' && !o2 && !d2 && !note2) delete DB.vstate[k];
        else DB.vstate[k] = { status: st, note: note2, owner: o2, due: d2, by: me.name, at: Date.now() / 1000 };
        n++;
      });
      RK_CACHE.clear(); dirty = true; audit(me.name, 'vuln.' + st, n + ' finding(s)' + (owner ? ', assigned to ' + owner : '') + (note ? ': ' + note.slice(0, 80) : ''));
      return json(res, { ok: true, changed: n });
    }
    if (p === '/api/ra/settings') {
      if (!isAdmin) return fail(res, 403, 'only an administrator can change remote access settings');
      if (!inScope(b.site)) return fail(res, 404, 'site not found');
      const r = raSite(String(b.site)), ports = (Array.isArray(b.ports) ? b.ports : []).map(function (x) { return parseInt(x, 10); }).filter(function (x) { return x >= 1 && x <= 65535; });
      r.on = !!b.on; if (ports.length) r.ports = uniq(ports, 30); r.self = !!b.self; const mm = parseInt(b.maxmin, 10); if (mm >= 5 && mm <= 1440) r.maxmin = mm;
      dirty = true; audit(me.name, 'ra.settings', DB.sites[b.site].name + ': ' + (r.on ? 'ON' : 'off') + ' ports ' + r.ports.join(','), DB.sites[b.site].tenant);
      if (!r.on) Object.values(raStore().s).forEach(function (x) { if (String(x.site) === String(b.site)) raEndSession(x, x.status === 'pending' ? 'denied' : 'ended', me.name, 'remote access switched off'); });
      return json(res, { ok: true });
    }
    if (p === '/api/ra/request') {
      if (!canHandle) return fail(res, 403, 'viewers cannot request remote access');
      if (!inScope(b.site)) return fail(res, 404, 'site not found');
      const sid = String(b.site), r = raSite(sid), ip = S(b.ip, 45).trim();
      if (!r.on) return fail(res, 400, 'remote access is not switched on for this site');
      if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip) || ip.split('.').some(function (x) { return +x > 255; }) || /^(127|0)\./.test(ip) || +ip.split('.')[0] >= 224) return fail(res, 400, 'enter the IPv4 address of the device');
      if (!assetByIp(DB.assets[sid], ip)) return fail(res, 400, 'that address is not a device this site has discovered');
      const ports = uniq((Array.isArray(b.ports) ? b.ports : []).map(function (x) { return parseInt(x, 10); }), 10);
      if (!ports.length) return fail(res, 400, 'choose at least one port');
      const bad = ports.filter(function (x) { return r.ports.indexOf(x) === -1; });
      if (bad.length) return fail(res, 400, 'port ' + bad.join(', ') + ' is not allowed at this site');
      const mins = Math.max(5, Math.min(r.maxmin || 120, parseInt(b.minutes, 10) || 60)), reason = S(b.reason, 300).trim();
      if (reason.length < 5) return fail(res, 400, 'give a short reason (this is shown to the approver and kept in the log)');
      const st = raStore(); st.seq++; const id = 'RA-' + String(st.seq).padStart(5, '0');
      st.s[id] = { id: id, site: sid, ip: ip, ports: ports, reason: reason, status: 'pending', by: me.name, created: Date.now() / 1000, minutes: mins, htok: '' };
      audit(me.name, 'ra.request', id + ' ' + ip + ' ports ' + ports.join(',') + ' ' + mins + ' min: ' + reason, DB.sites[sid].tenant);
      return json(res, { ok: true, id: id });
    }
    if (p === '/api/ra/decide') {
      const s = raStore().s[S(b.id, 30)]; if (!s || !inScope(s.site)) return fail(res, 404, 'request not found');
      if (!isAdmin) return fail(res, 403, 'only an administrator can approve or deny');
      if (s.status !== 'pending') return fail(res, 409, 'this request is already ' + s.status);
      const r = raSite(String(s.site)); if (s.by === me.name && !r.self) return fail(res, 403, 'you cannot approve your own request. Ask an administrator of the organisation');
      if (!b.approve) { s.status = 'denied'; s.decided_by = me.name; s.decided = Date.now() / 1000; s.deny = S(b.why, 200); dirty = true; audit(me.name, 'ra.deny', s.id + ' ' + s.ip, DB.sites[s.site].tenant); return json(res, { ok: true }); }
      if (!r.on) return fail(res, 400, 'remote access is switched off for this site');
      const mins = Math.max(5, Math.min(s.minutes, r.maxmin || 120, parseInt(b.minutes, 10) || s.minutes));
      s.status = 'approved'; s.decided_by = me.name; s.decided = Date.now() / 1000; s.minutes = mins; s.expires = s.decided + mins * 60; dirty = true;
      audit(me.name, 'ra.approve', s.id + ' ' + s.ip + ' ports ' + s.ports.join(',') + ' for ' + mins + ' min (requested by ' + s.by + ')', DB.sites[s.site].tenant);
      return json(res, { ok: true });
    }
    if (p === '/api/ra/end') {
      const s = raStore().s[S(b.id, 30)]; if (!s || !inScope(s.site)) return fail(res, 404, 'session not found');
      if (s.by !== me.name && !isAdmin) return fail(res, 403, 'only the requester or an administrator can end a session');
      if (s.status === 'pending') { s.status = 'denied'; s.deny = 'withdrawn'; s.decided_by = me.name; dirty = true; return json(res, { ok: true }); }
      raEndSession(s, 'ended', me.name, 'ended by ' + me.name); return json(res, { ok: true });
    }
    if (p === '/api/device/merge' || p === '/api/device/split') {      // one device recognised as two (merge), or two things joined by mistake (split)
      if (!canHandle) return fail(res, 403, 'viewers cannot change devices');
      if (!inScope(b.site)) return fail(res, 404, 'site not found');
      const sid = String(b.site), who = me.name;
      if (p === '/api/device/merge') {
        const t = devGet(sid, S(b.into, 60)), others = uniq((Array.isArray(b.ids) ? b.ids : []).map(function (x) { const d = devGet(sid, S(x, 60)); return d ? d.id : ''; })).filter(function (x) { return t && x !== t.id; }).slice(0, 50);
        if (!t || !others.length) return fail(res, 400, 'choose the device to keep and at least one other device to merge into it');
        const r = devMerge(sid, t.id, others, who, 'manual');
        audit(who, 'device.merge', t.id + ' absorbed ' + others.join(', ') + ' (site ' + sid + ')', DB.sites[sid] ? DB.sites[sid].tenant : null);
        return json(res, { ok: true, id: r.id, merged: others.length });
      }
      const d = devGet(sid, S(b.id, 60)); if (!d) return fail(res, 404, 'device not found');
      const r = devSplit(sid, d.id, (Array.isArray(b.macs) ? b.macs : []).slice(0, 64), (Array.isArray(b.ips) ? b.ips : []).slice(0, 64).map(function (x) { return S(x, 64); }), who);
      if (r.error) return fail(res, 400, r.error);
      audit(who, 'device.split', d.id + ' -> new device ' + r.id + ' (site ' + sid + ')', DB.sites[sid] ? DB.sites[sid].tenant : null);
      return json(res, { ok: true, id: r.id });
    }
    if (p === '/api/device/label') {
      if (!canHandle) return fail(res, 403, 'viewers cannot change devices');
      if (!inScope(b.site)) return fail(res, 404, 'site not found');
      const d = devGet(String(b.site), S(b.id, 60)); if (!d) return fail(res, 404, 'device not found');
      d.label = S(b.label, 80).trim(); dirty = true; return json(res, { ok: true });
    }
    if (p === '/api/zones/save') {        // segmentation zones of one site: subnets / IP ranges, a name, a Purdue level and (optionally) the sensor that watches them
      if (!canHandle) return fail(res, 403, 'viewers cannot change zones');
      if (!inScope(b.site)) return fail(res, 404, 'site not found');
      const LV = ['0', '1', '2', '3', '3.5', '4'];
      const zs = (Array.isArray(b.zones) ? b.zones : []).slice(0, 200).map(function (z, i) {
        return { id: S(z.id, 20) || ('z' + (i + 1)), spec: S(z.spec, 400).trim(), vlans: S(z.vlans, 200).trim(), name: S(z.name, 60).trim(), level: LV.indexOf(String(z.level)) !== -1 ? String(z.level) : '4', sensor: S(z.sensor, 80).trim(), fw: S(z.fw, 80).trim() };
      }).filter(function (z) { return (z.spec || z.vlans) && z.name; });
      DB.zones[String(b.site)] = zs; RK_CACHE.delete(String(b.site)); dirty = true; audit(me.name, 'zones.save', 'site ' + b.site + ': ' + zs.length + ' zone(s)');
      return json(res, { ok: true, zones: zs });
    }
    if (p === '/api/fwrules/save') {      // firewall rule status of the zone-to-zone conduits of one site: key "from zone|to zone|port" -> { st, note }
      if (!canHandle) return fail(res, 403, 'viewers cannot change firewall rules');
      if (!inScope(b.site)) return fail(res, 404, 'site not found');
      const ST = ['allowed', 'blocked', 'change'], out = {};
      Object.keys(b.rules && typeof b.rules === 'object' ? b.rules : {}).slice(0, 3000).forEach(function (k) {
        const r = b.rules[k] || {}, st = ST.indexOf(r.st) !== -1 ? r.st : '', note = S(r.note, 200).trim();
        if (st || note) out[S(k, 240)] = { st: st, note: note };
      });
      DB.fwrules[String(b.site)] = out; RK_CACHE.delete(String(b.site)); dirty = true; audit(me.name, 'fwrules.save', 'site ' + b.site + ': ' + Object.keys(out).length + ' conduit rule(s)');
      return json(res, { ok: true, rules: out });
    }
    if (p === '/api/risk/save') {        // answers, zone targets, risk treatment and hand-written risks for one site (send only what changed)
      if (!canHandle) return fail(res, 403, 'viewers cannot change the risk assessment');
      if (!inScope(b.site)) return fail(res, 404, 'site not found');
      const sid = String(b.site), R = rkState(sid, true), nowS = Date.now() / 1000, logged = [];
      if (b.answers && typeof b.answers === 'object') {
        let ch = 0;
        Object.keys(b.answers).slice(0, 80).forEach(function (k) {
          const q = RK_QBY[k]; if (!q) return;
          const x = b.answers[k] || {}, cur = R.answers[k] || {};
          const resp = x.resp !== undefined ? (['', 'Compliant', 'Partial', 'Non-Compliant', 'N/A'].indexOf(x.resp) !== -1 ? x.resp : (cur.resp || '')) : (cur.resp || '');
          const next = { resp: resp, note: x.note !== undefined ? S(x.note, 1500) : (cur.note || ''), owner: x.owner !== undefined ? S(x.owner, 80) : (cur.owner || ''), by: me.name, at: nowS };
          if (!next.resp && !next.note && !next.owner) delete R.answers[k]; else R.answers[k] = next;
          if (resp !== (cur.resp || '')) ch++;
        });
        if (ch) logged.push(ch + ' answer(s)');
      }
      if (b.auto !== undefined) { R.auto = !!b.auto; logged.push('automatic answers ' + (R.auto ? 'on' : 'off')); }
      if (b.meta && typeof b.meta === 'object') { ['org', 'site', 'assessor', 'ref', 'date'].forEach(function (k) { if (b.meta[k] !== undefined) R.meta[k] = S(b.meta[k], 100); }); }
      if (b.zt && typeof b.zt === 'object') {
        Object.keys(b.zt).slice(0, 200).forEach(function (zn) {
          const x = b.zt[zn] || {}, cur = R.zt[zn] || {}, im = x.impact === '' ? 0 : (x.impact !== undefined ? Math.floor(+x.impact) : cur.impact || 0), sl = x.slt === '' ? 0 : (x.slt !== undefined ? Math.floor(+x.slt) : cur.slt || 0);
          const o = { impact: im >= 1 && im <= 5 ? im : 0, slt: sl >= 1 && sl <= 4 ? sl : 0 };
          if (!o.impact && !o.slt) delete R.zt[S(zn, 80)]; else R.zt[S(zn, 80)] = o;
        });
        logged.push('zone targets');
      }
      if (b.treat && typeof b.treat === 'object') {
        for (const id of Object.keys(b.treat).slice(0, 200)) {
          const x = b.treat[id] || {}, tr = RK_TREAT.indexOf(x.tr) !== -1 ? x.tr : '', stt = RK_TSTAT.indexOf(x.st) !== -1 ? x.st : 'open', note = S(x.note, 400).trim();
          if ((stt === 'accepted' || tr === 'accept') && !note) return fail(res, 400, 'please give a short reason for accepting a risk');
          if (!tr && stt === 'open' && !x.owner && !x.due && !note) delete R.treat[S(id, 120)];
          else R.treat[S(id, 120)] = { tr: tr, st: stt, owner: S(x.owner, 80).trim(), due: /^\d{4}-\d\d-\d\d$/.test(String(x.due || '')) ? x.due : '', note: note, by: me.name, at: nowS };
        }
        logged.push('risk treatment');
      }
      if (Array.isArray(b.manual)) {
        const old = {}; R.manual.forEach(function (m) { old[m.id] = m; });
        R.manual = b.manual.slice(0, 200).map(function (m) {
          let id = S(m.id, 20); if (!/^M\d+$/.test(id) || !old[id]) { id = 'M' + (R.seq++); }
          const L = Math.floor(+m.L), I = Math.floor(+m.I), rL = Math.floor(+m.rL);
          return { id: id, title: S(m.title, 160).trim() || 'Untitled risk', zone: S(m.zone, 80).trim(), desc: S(m.desc, 600), L: L >= 1 && L <= 5 ? L : 3, I: I >= 1 && I <= 5 ? I : 3, rL: rL >= 1 && rL <= 5 ? rL : 0, fr: (Array.isArray(m.fr) ? m.fr : []).map(Number).filter(function (x) { return x >= 1 && x <= 7; }).slice(0, 7), csf: S(m.csf, 80), by: (old[id] && old[id].by) || me.name };
        });
        Object.keys(R.treat).forEach(function (k) { if (/^M\d+$/.test(k) && !R.manual.some(function (m) { return m.id === k; })) delete R.treat[k]; });
        logged.push('own risks');
      }
      R.updated = nowS; dirty = true;
      if (logged.length) audit(me.name, 'risk.save', 'site ' + sid + ': ' + logged.join(', '));
      return json(res, rkResponse(sid, false));
    }
    if (!isAdmin) return fail(res, 403, 'admin only');

    /* ---- organisations (platform staff only) ---- */
    if (p === '/api/vulns/rules/save') {
      const tk = me.tenant || S(b.tenant, 60) || 'default';
      if (!DB.tenants[tk]) return fail(res, 400, 'unknown organisation');
      if (!Array.isArray(b.rules)) return fail(res, 400, 'rules must be a list');
      if (JSON.stringify(b.rules).length > 200000) return fail(res, 400, 'too many rules');
      const ok = vcompileCustom(b.rules);
      if (ok.length !== b.rules.length) return fail(res, 400, 'every rule needs at least one match condition (vendor, model, os, firmware, banner, protocol, device_type or port); ' + (b.rules.length - ok.length) + ' of your rules have none or are not objects');
      DB.vrules = DB.vrules || {}; DB.vrules[tk] = b.rules; dirty = true; VCACHE.clear();
      audit(me.name, 'vuln.rules', ok.length + ' custom rule(s)');
      return json(res, { ok: true, rules: ok.length });
    }
    if (p === '/api/tenants/add') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const name = S(b.name, 80).trim(), id = slugify(b.slug || name);
      if (name.length < 2 || !id) return fail(res, 400, 'organisation name must be 2-80 characters');
      if (DB.tenants[id]) return fail(res, 400, 'an organisation with this id already exists');
      const an = S(b.admin_name, 80).trim();
      if (!/^[A-Za-z0-9._@+-]{2,80}$/.test(an) || /^(__proto__|constructor|prototype)$/i.test(an)) return fail(res, 400, 'first admin user name: 2-80 letters, digits, . _ @ + -');
      if (userKey(an)) return fail(res, 400, 'that user name is already taken');
      let pw = String(b.admin_password || ''), temp = '';
      const aem = S(b.admin_email, 120).trim();
      if (aem && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(aem)) return fail(res, 400, 'that email address does not look right');
      if (b.invite && (!smtpConf() || !(aem || an.indexOf('@') > 0))) return fail(res, 400, 'to send an invite, mail must be set up and the admin needs an email address');
      if (!pw) { pw = tempPassword(); temp = pw; } else { const pr = pwProblem(pw, an); if (pr) return fail(res, 400, pr); }
      DB.tenants[id] = { id: id, name: name, slug: id, status: 'active', created: Date.now() / 1000, limits: cleanLimits(b.limits) };
      DB.users[an] = { pw: hashPw(pw), role: 'admin', tenant: id, sites: [], email: aem, must_change: true, pv: 0, created: Date.now() / 1000 };
      dirty = true; audit(me.name, 'tenant.add', name + ' (first admin ' + an + ')', id);
      if (b.invite) { const er = await mailLink(req, an, 'invite'); return json(res, er ? { ok: true, id: id, admin: an, emailed: false, mail_error: er, temp_password: temp } : { ok: true, id: id, admin: an, emailed: true }); }
      return json(res, { ok: true, id: id, admin: an, temp_password: temp });
    }
    if (p === '/api/tenants/update') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const t = DB.tenants[S(b.id, 60)]; if (!t) return fail(res, 404, 'no such organisation');
      if (b.name !== undefined) { const nm = S(b.name, 80).trim(); if (nm.length < 2) return fail(res, 400, 'organisation name must be 2-80 characters'); t.name = nm; }
      if (b.status !== undefined) { if (['active', 'suspended'].indexOf(b.status) === -1) return fail(res, 400, 'status must be active or suspended'); t.status = b.status; }
      if (b.limits !== undefined) t.limits = cleanLimits(b.limits, t.limits);
      dirty = true; audit(me.name, 'tenant.update', t.name + ' (' + t.status + ')', t.id);
      return json(res, { ok: true });
    }
    if (p === '/api/tenants/delete') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const id = S(b.id, 60), t = DB.tenants[id]; if (!t) return fail(res, 404, 'no such organisation');
      if (id === 'default') return fail(res, 400, 'the default organisation cannot be deleted');
      if (S(b.confirm, 60) !== id) return fail(res, 400, 'type the organisation id to confirm');
      Object.keys(DB.sites).forEach(function (sid) { if (DB.sites[sid].tenant === id) deleteSiteData(sid); });
      Object.keys(DB.users).forEach(function (n) { if (DB.users[n].tenant === id) delete DB.users[n]; });
      delete DB.tenants[id]; compactActivities(); delete lastWritten[id];
      try { fs.rmSync(tenantDir(id), { recursive: true, force: true }); } catch (e) { console.error('Could not remove the organisation folder: ' + e.message); }
      dirty = true; audit(me.name, 'tenant.delete', t.name, id);
      return json(res, { ok: true });
    }

    if (me.api) return fail(res, 403, 'API keys are read-only');
    if (p === '/api/snmp/target/save' || p === '/api/snmp/target/delete' || p === '/api/snmp/settings' || p === '/api/snmp/poll') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const site = DB.sites[S(b.site, 40)]; if (!site || !inScope(site.id)) return fail(res, 404, 'site not found');
      const cfg = snmpCfg(site);
      if (p === '/api/snmp/poll') { cfg.now = crypto.randomBytes(6).toString('hex'); dirty = true; audit(me.name, 'snmp.poll', site.name, site.tenant); return json(res, { ok: true }); }
      if (p === '/api/snmp/settings') { const ev = parseInt(b.every, 10); cfg.every = ev >= 60 && ev <= 86400 ? ev : 300; dirty = true; audit(me.name, 'snmp.settings', site.name + ' every ' + cfg.every + 's', site.tenant); return json(res, { ok: true }); }
      if (p === '/api/snmp/target/delete') {
        const n = cfg.targets.length; cfg.targets = cfg.targets.filter(function (t) { return t.id !== S(b.id, 20); });
        if (cfg.targets.length === n) return fail(res, 404, 'not found');
        const cur = (DB.snmp || {})[String(site.id)]; if (cur) delete cur.results[S(b.id, 20)];
        dirty = true; audit(me.name, 'snmp.target.delete', site.name, site.tenant); return json(res, { ok: true });
      }
      const ip = S(b.ip, 200).trim(); if (!/^[A-Za-z0-9.\-:]{1,200}$/.test(ip)) return fail(res, 400, 'enter the switch IP address or name');
      const old = b.id ? cfg.targets.filter(function (t) { return t.id === S(b.id, 20); })[0] : null; if (b.id && !old) return fail(res, 404, 'not found');
      if (!old && cfg.targets.length >= 50) return fail(res, 400, 'at most 50 devices per site');
      const port = parseInt(b.port, 10), ver = b.ver === '3' ? '3' : '2c';
      const t = { id: old ? old.id : crypto.randomBytes(4).toString('hex'), name: S(b.name, 60).trim(), ip: ip, port: port >= 1 && port <= 65535 ? port : 161, ver: ver };
      if (ver === '2c') {
        const cm = b.community ? S(b.community, 100) : (old && old.ver === '2c' ? intOpen(old.community) : '');
        if (!cm) return fail(res, 400, 'enter the SNMP community string'); t.community = intSealed(cm);
      } else {
        t.user = S(b.user, 60).trim(); if (!t.user) return fail(res, 400, 'enter the SNMPv3 user name');
        t.level = SNMP_LVL.filter(function (x) { return x.toLowerCase() === String(b.level || '').toLowerCase(); })[0] || 'authPriv';
        const oldv3 = old && old.ver === '3' ? old : null;
        if (t.level !== 'noAuthNoPriv') {
          t.auth_proto = SNMP_AUTH.indexOf(b.auth_proto) !== -1 ? b.auth_proto : 'sha';
          const ap = b.auth_pass ? S(b.auth_pass, 100) : (oldv3 ? intOpen(oldv3.auth_pass) : '');
          if (ap.length < 8) return fail(res, 400, 'the authentication password must be at least 8 characters'); t.auth_pass = intSealed(ap);
        }
        if (t.level === 'authPriv') {
          const pp = b.priv_pass ? S(b.priv_pass, 100) : (oldv3 ? intOpen(oldv3.priv_pass) : '');
          if (pp.length < 8) return fail(res, 400, 'the privacy (encryption) password must be at least 8 characters'); t.priv_pass = intSealed(pp);
        }
      }
      if (old) cfg.targets[cfg.targets.indexOf(old)] = t; else cfg.targets.push(t);
      cfg.now = crypto.randomBytes(6).toString('hex');                                  // read it right away
      dirty = true; audit(me.name, 'snmp.target.save', site.name + ': ' + ip + ' v' + ver, site.tenant);
      return json(res, { ok: true, id: t.id });
    }
    if (p === '/api/integrations/mail/save' || p === '/api/integrations/mail/test') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = DB.tenants[me.tenant || (me.isSuper ? S(b.tenant, 60) : '')]; if (!t) return fail(res, 404, 'choose an organisation first');
      if (p === '/api/integrations/mail/test') {
        if (!smtpConf(t.id)) return fail(res, 400, 'mail is not set up yet');
        try { await sendMail(S(b.to, 200), 'OTSuraksha test message', 'This is a test message from OTSuraksha Central. Mail is working.\n', t.id); audit(me.name, 'smtp.test', S(b.to, 200), t.id); return json(res, { ok: true }); }
        catch (e) { return fail(res, 400, e.message); }
      }
      if (b.clear) { delete t.smtp; dirty = true; audit(me.name, 'smtp.clear', 'organisation', t.id); return json(res, { ok: true }); }
      const host = S(b.host, 200).trim(), port = parseInt(b.port, 10), old = t.smtp || {};
      if (!host || !/^[A-Za-z0-9.:\-\[\]]+$/.test(host)) return fail(res, 400, 'enter the mail server name, e.g. smtp.office365.com');
      if (intBlocked(host) || /^localhost$/i.test(host) && !process.env.ALLOW_LOCAL_INTEGRATIONS) return fail(res, 400, 'that address is not allowed');
      const rec = { host: host, port: port >= 1 && port <= 65535 ? port : 587, mode: ['starttls', 'tls', 'none'].indexOf(b.mode) !== -1 ? b.mode : 'starttls', user: S(b.user, 200).trim(), from: S(b.from, 200).replace(/[\r\n]+/g, ' ').trim(), pass: b.pass ? pendSeal({ s: S(b.pass, 500) }) : (old.pass || '') };
      t.smtp = rec; dirty = true; audit(me.name, 'smtp.save', 'organisation ' + host + ':' + rec.port, t.id);
      return json(res, { ok: true });
    }
    if (p === '/api/integrations/save' || p === '/api/integrations/test') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = DB.tenants[me.tenant || (me.isSuper ? S(b.tenant, 60) : '')]; if (!t) return fail(res, 404, 'choose an organisation first');
      const ch = S(b.channel, 12); if (INT_CH.indexOf(ch) === -1) return fail(res, 400, 'unknown integration');
      t.siem = t.siem || {};
      if (p === '/api/integrations/test') {
        const cfg = t.siem[ch]; if (!cfg || !(cfg.host || cfg.url)) return fail(res, 400, 'save the settings first');
        const ev = { time: new Date().toISOString(), first_seen: '', organisation: t.name, site: 'test', severity: 'low', title: 'Test message from OTSuraksha Central', kind: 'test', source: '', destination: '', protocol: '', detail: 'If you can read this, the connection works.', status: 'new', mitre: '', policy_id: '', count: 1 };
        try { await INT_SEND[ch](cfg, [ev]); audit(me.name, 'integration.test', ch, t.id); return json(res, { ok: true }); }
        catch (er) { return fail(res, 400, 'could not send: ' + er.message); }
      }
      const old = t.siem[ch] || {}, c = { enabled: !!b.enabled, min: INT_MIN.indexOf(b.min) !== -1 ? b.min : 'medium', last: old.last || null };
      if (ch === 'webhook') {
        const url = S(b.url, 500).trim();
        if (url) { let u; try { u = new URL(url); } catch (e) { return fail(res, 400, 'that web address does not look right'); } if (!/^https?:$/.test(u.protocol) || u.username || u.password) return fail(res, 400, 'use an http:// or https:// address without a password in it'); if (intBlocked(u.hostname) || /^localhost$/i.test(u.hostname) && !process.env.ALLOW_LOCAL_INTEGRATIONS) return fail(res, 400, 'that address is not allowed'); }
        else if (c.enabled) return fail(res, 400, 'enter the web address to send alerts to');
        c.url = url; c.format = b.format === 'splunk' ? 'splunk' : 'json';
        c.auth = b.clear_secret ? '' : (b.secret ? intSealed(S(b.secret, 400)) : (old.auth || ''));
      } else {
        const host = S(b.host, 200).trim(), port = parseInt(b.port, 10);
        if (host && !/^[A-Za-z0-9.:\-\[\]]+$/.test(host)) return fail(res, 400, 'enter a server name or IP address');
        if (!host && c.enabled) return fail(res, 400, 'enter the server name or IP address');
        if (host && (intBlocked(host) || /^localhost$/i.test(host) && !process.env.ALLOW_LOCAL_INTEGRATIONS)) return fail(res, 400, 'that address is not allowed');
        c.host = host; c.port = port >= 1 && port <= 65535 ? port : (ch === 'snmp' ? 162 : 514);
        if (ch === 'syslog') { c.proto = ['udp', 'tcp', 'tls'].indexOf(b.proto) !== -1 ? b.proto : 'udp'; c.format = b.format === 'json' ? 'json' : 'cef'; }
        else {
          c.community = b.clear_secret ? '' : (b.secret ? intSealed(S(b.secret, 100)) : (old.community || ''));
          if (c.enabled && !c.community) return fail(res, 400, 'enter the SNMP community string');
        }
      }
      if (c.enabled && !old.enabled && !b.send_existing) intMarkExisting(t.id, ch);       // only new alerts are sent, unless asked otherwise
      t.siem[ch] = c; dirty = true; audit(me.name, 'integration.save', ch + (c.enabled ? ' on' : ' off'), t.id);
      return json(res, { ok: true, feeds: intView(t) });
    }
    if (p === '/api/smtp/save') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const c = DB.smtp = DB.smtp || {};
      if (b.clear) { DB.smtp = {}; dirty = true; audit(me.name, 'smtp.clear', ''); return json(res, { ok: true }); }
      const host = S(b.host, 200).trim(); if (!/^[A-Za-z0-9.-]+$/.test(host)) return fail(res, 400, 'enter the mail server name, e.g. smtp.example.com');
      const port = parseInt(b.port, 10); if (!(port > 0 && port < 65536)) return fail(res, 400, 'port must be 1-65535');
      if (['starttls', 'tls', 'none'].indexOf(b.mode) === -1) return fail(res, 400, 'security must be starttls, tls or none');
      c.host = host; c.port = port; c.mode = b.mode; c.user = S(b.user, 200); c.from = S(b.from, 200).trim();
      if (!c.from) return fail(res, 400, 'enter the From address, e.g. OTSuraksha <alerts@example.com>');
      if (b.pass) c.pass = pendSeal({ s: S(b.pass, 500) });
      dirty = true; audit(me.name, 'smtp.save', host + ':' + port); return json(res, { ok: true });
    }
    if (p === '/api/smtp/test') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      try { await sendMail(S(b.to, 200), 'OTSuraksha test message', 'This is a test message from OTSuraksha Central. Mail is working.\n'); audit(me.name, 'smtp.test', S(b.to, 200)); return json(res, { ok: true }); }
      catch (e) { return fail(res, 400, e.message); }
    }
    /* ---- two-factor ---- */
    if (p === '/api/me/totp/setup') {
      const us = DB.users[me.name], sec = b32enc(crypto.randomBytes(20));
      us.totp_pending = pendSeal({ s: sec }); dirty = true;
      return json(res, { ok: true, secret: sec, uri: 'otpauth://totp/OT%20Sense:' + encodeURIComponent(me.name) + '?secret=' + sec + '&issuer=OT%20Sense' });
    }
    if (p === '/api/me/totp/enable') {
      const us = DB.users[me.name], o = us.totp_pending ? pendOpen(us.totp_pending) : null;
      if (!o || !totpVerify(o.s, b.code, us)) return fail(res, 400, 'that code is not right - check the clock on your phone and try again');
      us.totp = pendSeal({ s: o.s }); us.totp_on = true; delete us.totp_pending; dirty = true; audit(me.name, 'totp.enable', '');
      return json(res, { ok: true });
    }
    if (p === '/api/me/totp/disable') {
      const us = DB.users[me.name]; if (!us.totp_on) return json(res, { ok: true });
      if (!checkPw(b.password, us.pw) || !userTotpOk(us, b.code)) return fail(res, 400, 'password or code is wrong');
      delete us.totp; us.totp_on = false; dirty = true; audit(me.name, 'totp.disable', '');
      return json(res, { ok: true });
    }
    /* ---- view-as, organisation settings, API keys, SSO ---- */
    if (p === '/api/tenants/viewas') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const t = DB.tenants[S(b.id, 60)]; if (!t) return fail(res, 404, 'no such organisation');
      audit(me.name, 'tenant.viewas', t.name, t.id); return json(res, { ok: true });
    }
    const orgOf = function () { return DB.tenants[me.tenant || S(b.tenant, 60)] || null; };
    if (p === '/api/org/brand') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = DB.tenants[me.tenant || S(b.tenant, 60)]; if (!t) return fail(res, 404, 'choose an organisation first');
      const br = t.brand = t.brand || {};
      if (b.title !== undefined) br.title = S(b.title, 40).trim();
      if (b.color !== undefined) { if (b.color && !/^#[0-9a-fA-F]{6}$/.test(b.color)) return fail(res, 400, 'colour must look like #1a73e8'); br.color = b.color; }
      if (b.logo !== undefined) {
        if (b.logo === '') { delete br.logo; }
        else { if (typeof b.logo !== 'string' || b.logo.length > 140000 || !LOGO_RE.test(b.logo)) return fail(res, 400, 'logo must be a PNG, JPEG, WebP or SVG image under 100 KB'); br.logo = b.logo; }
        br.v = (br.v || 0) + 1;
      }
      dirty = true; audit(me.name, 'org.brand', t.name, t.id); return json(res, { ok: true });
    }
    if (p === '/api/org/hosts') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const t = DB.tenants[S(b.tenant, 60)]; if (!t) return fail(res, 404, 'choose an organisation first');
      const hs = (Array.isArray(b.hosts) ? b.hosts : String(b.hosts || '').split(/[\s,]+/)).map(function (x) { return String(x).trim().toLowerCase(); }).filter(Boolean);
      for (const h of hs) { if (!/^([a-z0-9-]+\.)+[a-z]{2,}$/.test(h)) return fail(res, 400, h + ' is not a valid host name'); if (Object.values(DB.tenants).some(function (x) { return x.id !== t.id && (x.hosts || []).indexOf(h) !== -1; })) return fail(res, 400, h + ' is already used by another organisation'); }
      t.hosts = hs.filter(function (h, i, a) { return a.indexOf(h) === i; }).slice(0, 10); dirty = true; audit(me.name, 'org.hosts', t.name + ': ' + t.hosts.join(', '), t.id); return json(res, { ok: true });
    }
    if (p === '/api/org/settings') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = orgOf(); if (!t) return fail(res, 404, 'choose an organisation first');
      if (b.theme !== undefined) { if (['', 'light', 'dark'].indexOf(b.theme) === -1) return fail(res, 400, 'theme must be light, dark or empty'); t.theme = b.theme; }
      if (me.isSuper && b.slug !== undefined) {
        const sl = slugify(b.slug); if (!sl) return fail(res, 400, 'login name must be letters and digits');
        if (Object.values(DB.tenants).some(function (x) { return x.id !== t.id && (x.slug === sl || x.id === sl); })) return fail(res, 400, 'that login name is already used');
        t.slug = sl;
      }
      dirty = true; audit(me.name, 'org.settings', t.name, t.id); return json(res, { ok: true });
    }
    if (p === '/api/keys/add') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = orgOf(); if (!t) return fail(res, 404, 'choose an organisation first');
      const nm = S(b.name, 60).trim(); if (!nm) return fail(res, 400, 'give the key a name');
      t.keys = t.keys || []; if (t.keys.length >= 20) return fail(res, 400, 'at most 20 keys per organisation');
      const tok = 'otsk_' + crypto.randomBytes(24).toString('base64url');
      t.keys.push({ id: crypto.randomBytes(6).toString('hex'), name: nm, hash: sha(tok), prefix: tok.slice(0, 9), created: Date.now() / 1000, last: 0 });
      dirty = true; audit(me.name, 'apikey.add', nm, t.id); return json(res, { ok: true, key: tok });
    }
    if (p === '/api/keys/delete') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = orgOf(); if (!t) return fail(res, 404, 'choose an organisation first');
      t.keys = (t.keys || []).filter(function (k) { return k.id !== S(b.id, 40); }); dirty = true; audit(me.name, 'apikey.delete', S(b.id, 40), t.id); return json(res, { ok: true });
    }
    if (p === '/api/sso/save') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = orgOf(); if (!t) return fail(res, 404, 'choose an organisation first');
      const c = t.sso = t.sso || { domains: [] };
      if (b.issuer !== undefined) {
        const iss = S(b.issuer, 300).trim();
        try { const u2 = new URL(iss); if (u2.protocol !== 'https:' && !(process.env.SSO_ALLOW_HTTP === '1' && u2.protocol === 'http:')) throw 0; } catch (e) { if (iss) return fail(res, 400, 'issuer must be an https address'); }
        c.issuer = iss;
      }
      if (b.client_id !== undefined) c.client_id = S(b.client_id, 200).trim();
      if (b.client_secret) c.secret = pendSeal({ s: S(b.client_secret, 500) });
      if (b.group_claim !== undefined) c.group_claim = S(b.group_claim, 60).trim();
      if (b.default_role !== undefined) { if (b.default_role && SSO_ROLES.indexOf(b.default_role) === -1) return fail(res, 400, 'bad default role'); c.default_role = b.default_role; }
      if (b.group_map !== undefined) {
        const gm = {}; if (b.group_map && typeof b.group_map === 'object') Object.keys(b.group_map).slice(0, 50).forEach(function (g) { if (SSO_ROLES.indexOf(b.group_map[g]) !== -1) gm[S(g, 200)] = b.group_map[g]; });
        c.group_map = gm;
      }
      if (b.enabled !== undefined || b.enforce !== undefined) {
        const en = b.enabled !== undefined ? !!b.enabled : !!c.enabled, enf = b.enforce !== undefined ? !!b.enforce : !!c.enforce;
        if (en && (!c.issuer || !c.client_id || !verifiedDomains(t).length)) return fail(res, 400, 'set the issuer, client id and verify at least one email domain first');
        if (enf && !en) return fail(res, 400, 'turn SSO on to enforce it');
        if (enf && !Object.values(DB.users).some(function (u) { return u.tenant === t.id && u.role === 'admin' && u.breakglass && !u.disabled; })) return fail(res, 400, 'mark at least one local admin as break-glass before enforcing SSO');
        c.enabled = en; c.enforce = enf;
      }
      dirty = true; audit(me.name, 'sso.save', t.name + (c.enabled ? ' (on' + (c.enforce ? ', enforced' : '') + ')' : ' (off)'), t.id);
      return json(res, { ok: true });
    }
    if (p === '/api/sso/domain/add') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = orgOf(); if (!t) return fail(res, 404, 'choose an organisation first');
      const d = S(b.domain, 120).trim().toLowerCase();
      if (!/^([a-z0-9-]+\.)+[a-z]{2,}$/.test(d)) return fail(res, 400, 'enter a domain like example.com');
      t.sso = t.sso || { domains: [] }; t.sso.domains = t.sso.domains || [];
      if (t.sso.domains.some(function (x) { return x.domain === d; })) return fail(res, 400, 'already added');
      if (Object.values(DB.tenants).some(function (x) { return x.id !== t.id && ((x.sso || {}).domains || []).some(function (y) { return y.domain === d && y.verified; }); })) return fail(res, 400, 'that domain is already verified by another organisation');
      t.sso.domains.push({ domain: d, verified: false, token: 'otsense-verify=' + crypto.randomBytes(16).toString('hex') }); dirty = true; audit(me.name, 'sso.domain.add', d, t.id);
      return json(res, { ok: true });
    }
    if (p === '/api/sso/domain/verify') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = orgOf(); if (!t) return fail(res, 404, 'choose an organisation first');
      const d = ((t.sso || {}).domains || []).find(function (x) { return x.domain === S(b.domain, 120).toLowerCase(); }); if (!d) return fail(res, 404, 'unknown domain');
      let recs = []; try { recs = (await dns.promises.resolveTxt('_otsense-challenge.' + d.domain)).map(function (x) { return x.join(''); }); } catch (e) {}
      if (process.env.SSO_TEST_DNS === '1') recs = [d.token];
      if (recs.indexOf(d.token) === -1) return fail(res, 400, 'the DNS TXT record was not found yet (it can take a few minutes) - expected ' + d.token);
      if (Object.values(DB.tenants).some(function (x) { return x.id !== t.id && ((x.sso || {}).domains || []).some(function (y) { return y.domain === d.domain && y.verified; }); })) return fail(res, 400, 'that domain is already verified by another organisation');
      d.verified = true; dirty = true; audit(me.name, 'sso.domain.verify', d.domain, t.id); return json(res, { ok: true });
    }
    if (p === '/api/sso/domain/remove') {
      if (!isAdmin) return fail(res, 403, 'admin only');
      const t = orgOf(); if (!t || !t.sso) return fail(res, 404, 'nothing to remove');
      t.sso.domains = (t.sso.domains || []).filter(function (x) { return x.domain !== S(b.domain, 120).toLowerCase(); });
      if (!verifiedDomains(t).length) { t.sso.enabled = false; t.sso.enforce = false; }
      dirty = true; audit(me.name, 'sso.domain.remove', S(b.domain, 120), t.id); return json(res, { ok: true });
    }

    /* ---- users ---- */
    if (p === '/api/users/add') {
      const name = S(b.name, 80).trim();
      if (!/^[A-Za-z0-9._@+-]{2,80}$/.test(name) || /^(__proto__|constructor|prototype)$/i.test(name)) return fail(res, 400, 'user name: 2-80 letters, digits, . _ @ + -');
      if (userKey(name)) return fail(res, 400, 'that user name is already taken');
      const roles = me.isSuper ? ['superadmin', 'admin', 'analyst', 'viewer'] : ['admin', 'analyst', 'viewer'];
      const role = String(b.role || 'viewer');
      if (roles.indexOf(role) === -1) return fail(res, 400, 'role must be ' + roles.join(', '));
      let tid = null;
      if (role !== 'superadmin') { tid = me.isSuper ? S(b.tenant, 60) : me.tenant; if (!tid || !DB.tenants[tid]) return fail(res, 400, 'choose the organisation for this user'); }
      let pw = String(b.password || ''), temp = '';
      const email = S(b.email, 120).trim();
      if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return fail(res, 400, 'that email address does not look right');
      if (b.invite && (!smtpConf(tid) || !(email || name.indexOf('@') > 0))) return fail(res, 400, 'to send an invite, mail must be set up and the user needs an email address');
      if (!pw) { pw = tempPassword(); temp = pw; } else { const pr = pwProblem(pw, name); if (pr) return fail(res, 400, pr); }
      DB.users[name] = { pw: hashPw(pw), role: role, tenant: tid, sites: role === 'viewer' || role === 'analyst' ? cleanSites(b.sites, tid) : [], email: email,
        must_change: true, pv: 0, created: Date.now() / 1000 };
      dirty = true; audit(me.name, 'user.add', name + ' (' + role + (tid ? ', ' + tid : '') + ')', tid);
      if (b.invite) { const er = await mailLink(req, name, 'invite'); audit(me.name, er ? 'invite.fail' : 'invite.send', name + (er ? ': ' + er : ''), tid);
        return json(res, er ? { ok: true, name: name, emailed: false, mail_error: er, temp_password: temp } : { ok: true, name: name, emailed: true }); }
      return json(res, { ok: true, name: name, temp_password: temp });
    }
    if (p === '/api/users/update') {
      const k = userKey(b.name);
      if (!k || !canManageUser(me, k)) return fail(res, 404, 'no such user');
      const u = DB.users[k], self = k === me.name;
      let role = u.role;
      if (b.role !== undefined && b.role !== u.role) {
        if (u.role === 'superadmin') return fail(res, 400, 'a platform user keeps the superadmin role');
        if (['admin', 'analyst', 'viewer'].indexOf(b.role) === -1) return fail(res, 400, 'role must be admin, analyst or viewer');
        if (self) return fail(res, 400, 'you cannot change your own role');
        role = b.role;
      }
      const dis = b.disabled === undefined ? !!u.disabled : !!b.disabled;
      if (self && dis) return fail(res, 400, 'you cannot disable your own account');
      const wasActive = !u.disabled && (u.role === 'admin' || u.role === 'superadmin'), willBe = !dis && (role === 'admin' || role === 'superadmin');
      if (wasActive && !willBe && adminCount(u.role === 'superadmin' ? null : u.tenant, k) === 0) return fail(res, 400, 'there must always be at least one active admin');
      u.role = role;
      if (role === 'admin' || role === 'superadmin') u.sites = []; else if (b.sites !== undefined) u.sites = cleanSites(b.sites, u.tenant);
      if (dis && !u.disabled) u.pv = (u.pv || 0) + 1;
      u.disabled = dis;
      if (b.unlock) { u.lock_until = 0; u.fails = 0; }
      if (b.reset_totp && u.totp_on) { delete u.totp; u.totp_on = false; audit(me.name, 'totp.reset', k, u.tenant || null); }
      if (b.email !== undefined) { const em = S(b.email, 120).trim(); if (em && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return fail(res, 400, 'that email address does not look right'); u.email = em; }
      if (b.breakglass !== undefined) u.breakglass = role === 'admin' && !!b.breakglass;
      if (b.orgs !== undefined) {                              // extra organisations this user may also sign in to (platform admin only)
        if (!me.isSuper) return fail(res, 403, 'only a platform administrator can give a user access to more organisations');
        if (u.role === 'superadmin') return fail(res, 400, 'platform administrators already see every organisation');
        const orgs = [], roles = {};
        for (const o of (Array.isArray(b.orgs) ? b.orgs : []).slice(0, 20)) {
          const t = tenantBySlug(S(o && o.org, 60).trim());
          if (!t) return fail(res, 400, 'no organisation with the login name "' + S(o && o.org, 60) + '"');
          if (t.id === u.tenant || orgs.indexOf(t.id) !== -1) continue;
          orgs.push(t.id); roles[t.id] = ['viewer', 'analyst', 'admin'].indexOf(o.role) !== -1 ? o.role : 'viewer';
        }
        u.orgs = orgs; u.org_roles = roles; u.org_sites = {};
        audit(me.name, 'user.orgs', k + ': ' + orgs.join(','), u.tenant || null);
      }
      dirty = true; audit(me.name, 'user.update', k + ' (' + role + (dis ? ', disabled' : '') + ')', u.tenant || null);
      return json(res, { ok: true, user: userView(k) });
    }
    if (p === '/api/users/reset') {
      const k = userKey(b.name);
      if (!k || !canManageUser(me, k)) return fail(res, 404, 'no such user');
      if (k === me.name) return fail(res, 400, 'use Change password for your own account');
      const u = DB.users[k], tp = tempPassword();
      u.pw = hashPw(tp); u.must_change = true; u.pv = (u.pv || 0) + 1; u.fails = 0; u.lock_until = 0; dirty = true;
      audit(me.name, 'user.reset', k, u.tenant || null);
      if (b.email) { if (!smtpConf(u.tenant)) return fail(res, 400, 'mail is not set up yet'); const er = await mailLink(req, k, 'reset');
        return json(res, er ? { ok: true, name: k, emailed: false, mail_error: er, temp_password: tp } : { ok: true, name: k, emailed: true }); }
      return json(res, { ok: true, name: k, temp_password: tp });
    }
    if (p === '/api/users/delete') {
      const k = userKey(b.name);
      if (!k || !canManageUser(me, k)) return fail(res, 404, 'no such user');
      if (k === me.name) return fail(res, 400, 'you cannot delete your own account');
      const u = DB.users[k];
      if (!u.disabled && (u.role === 'admin' || u.role === 'superadmin') && adminCount(u.role === 'superadmin' ? null : u.tenant, k) === 0) return fail(res, 400, 'there must always be at least one active admin');
      delete DB.users[k]; dirty = true; audit(me.name, 'user.delete', k, u.tenant || null);
      return json(res, { ok: true });
    }

    /* ---- sites and sensors ---- */
    if (p === '/api/sites/add') {
      const name = S(b.name, 80).trim();
      if (!name) return fail(res, 400, 'site name must be 1-80 characters');
      const tid = tenantForNew(me, b); if (!tid) return fail(res, 400, 'choose the organisation for this site');
      if (siteQuotaFull(tid)) return fail(res, 403, 'this organisation has reached its limit of sites');
      if (Object.values(DB.sites).some(function (s) { return s.tenant === tid && s.name.toLowerCase() === name.toLowerCase(); })) return fail(res, 400, 'site already exists');
      const tok = newToken(), id = DB.nextSite++;
      DB.sites[id] = { id: id, name: name, tenant: tid, token_hash: sha(tok), created: Date.now() / 1000, last_seen: 0, interval: 30, meta: {} };
      dirty = true; audit(me.name, 'site.add', name, tid);
      return json(res, { ok: true, id: id, token: tok });
    }
    if (p === '/api/image/fetch') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      if (IMG.running) return fail(res, 409, 'a build or download is already running');
      try { imgFetch(me.name, String(b.target || 'iso-amd64'), String(b.url || '')); } catch (e) { return fail(res, 400, e.message); }
      return json(res, { ok: true });
    }
    if (p === '/api/image/build') {
      if (!me.isSuper) return fail(res, 403, 'platform admin only');
      const st = imgStatus(); if (st.running) return fail(res, 409, 'a build is already running');
      if (!st.can_build) return fail(res, 400, st.why);
      const bd = b;
      try { imgStart(me.name, String(bd.target || 'iso-amd64'), String(bd.method || 'docker')); } catch (e) { return fail(res, 400, e.message); }
      audit(me.name, 'image.build.start', String(bd.target || 'iso-amd64')); return json(res, { ok: true });
    }
    if (p === '/api/sensors/build') {
      const name = S(b.name, 80).trim();
      if (!name) return fail(res, 400, 'site name must be 1-80 characters');
      const tid = tenantForNew(me, b); if (!tid) return fail(res, 400, 'choose the organisation for this sensor');
      const bb = Object.assign({}, b); if (!me.isSuper) bb.base = '';        // tenant admins always use the standard base image
      const old = Object.values(DB.sites).find(function (x) { return x.tenant === tid && x.name.toLowerCase() === name.toLowerCase(); });
      if (old && !inScope(old.id)) return fail(res, 404, 'no such site');
      if (!old && siteQuotaFull(tid)) return fail(res, 403, 'this organisation has reached its limit of sites');
      if (b.add_sensor) {              // one more sensor for an existing site: the site and its first sensor keep working
        if (!old) return fail(res, 404, 'no such site');
        if ((old.sensors2 || []).length >= 9) return fail(res, 400, 'a site can have up to 10 sensors');
        const tok2 = newToken(), pw2 = crypto.randomBytes(9).toString('base64url'); let r2;
        try { r2 = sensorBuild.build(name, tok2, bb, Object.assign(buildCtx(String(bb.base || '')), { pw: pw2 })); } catch (e) { return fail(res, 400, e.message); }
        const opts2 = {}; PEND_KEYS.forEach(function (k) { if (bb[k] !== undefined) opts2[k] = bb[k]; });
        const sid2 = 'x' + crypto.randomBytes(4).toString('hex'), lab = S(b.label, 60).trim() || ('Sensor ' + ((old.sensors2 || []).length + 2));
        (old.sensors2 = old.sensors2 || []).push({ id: sid2, label: lab, token_hash: sha(tok2), created: Date.now() / 1000, by: me.name, last_seen: 0, meta: {},
          build: { platform: r2.options.platform, mode: r2.options.mode, ip: r2.options.ip, at: Date.now() / 1000, by: me.name }, pending: { blob: pendSeal({ token: tok2, pw: pw2, opts: opts2 }), at: Date.now() / 1000, files: r2.files.map(function (f) { return { name: f.name, size: f.data ? f.data.length : f.size }; }) } });
        dirty = true; audit(me.name, 'sensor.add', name + ' / ' + lab + ' (' + r2.options.platform + ')', tid);
        const x2 = old.sensors2[old.sensors2.length - 1];
        return json(res, { ok: true, id: old.id, sensor: sid2, name: old.name, image: r2.image, label: r2.label, hint: r2.hint || '', console_password: r2.console_password, files: x2.pending.files });
      }
      const prev = old && b.edit && old.pending ? pendOpen(old.pending.blob) : null;      // EDIT: same site, same token - the sensor files are rebuilt with the new settings
      if (old && b.edit && !prev) return fail(res, 400, 'this sensor has already connected (or was never built), so its files are no longer stored - use "re-issue token" to build a new one');
      if (old && !b.reissue && !prev) return fail(res, 400, 'site already exists - pick another name, or tick "re-issue token" (the current sensor of that site stops working)');
      const tok = prev ? prev.token : newToken(), pw = prev ? prev.pw : crypto.randomBytes(9).toString('base64url'); let r;
      try { r = sensorBuild.build(name, tok, bb, Object.assign(buildCtx(String(bb.base || '')), { pw: pw })); } catch (e) { return fail(res, 400, e.message); }   // nothing is created if the options are wrong
      let st = old; if (!st) { const id = DB.nextSite++; st = DB.sites[id] = { id: id, name: name, tenant: tid, created: Date.now() / 1000, last_seen: 0, interval: 30, meta: {} }; }
      const opts = {}; PEND_KEYS.forEach(function (k) { if (bb[k] !== undefined) opts[k] = bb[k]; });
      st.token_hash = sha(tok); st.build = { platform: r.options.platform, mode: r.options.mode, ip: r.options.ip, at: Date.now() / 1000, by: me.name };
      st.pending = { blob: pendSeal({ token: tok, pw: pw, opts: opts }), at: Date.now() / 1000, files: r.files.map(function (f) { return { name: f.name, size: f.data ? f.data.length : f.size }; }) };
      dirty = true; audit(me.name, prev ? 'sensor.edit' : old ? 'sensor.rebuild' : 'sensor.build', name + ' (' + r.options.platform + ')', tid);
      return json(res, { ok: true, id: st.id, name: st.name, image: r.image, label: r.label, hint: r.hint || '', console_password: r.console_password, files: st.pending.files });
    }
    if (p === '/api/sites/scan') {          // central decides Passive / Active for a whole site ('' = give the decision back to the sensor)
      const s = DB.sites[b.id]; if (!s || !inScope(s.id)) return fail(res, 404, 'no such site');
      const m = String(b.mode || ''); if (m !== '' && m !== 'passive' && m !== 'active') return fail(res, 400, 'mode must be passive, active or empty');
      s.scan_mode = m; dirty = true; audit(me.name, 'site.scan', s.name + ' -> ' + (m || 'sensor decides'), s.tenant);
      return json(res, { ok: true, scan_mode: m });
    }
    if (p === '/api/sites/sensor/remove') {
      const s = DB.sites[b.id]; if (!s || !inScope(s.id)) return fail(res, 404, 'no such site');
      const n0 = (s.sensors2 || []).length; s.sensors2 = (s.sensors2 || []).filter(function (x) { return x.id !== b.sensor; });
      if (s.sensors2.length === n0) return fail(res, 404, 'no such sensor');
      dirty = true; audit(me.name, 'sensor.remove', s.name + ' / ' + S(b.sensor, 20), s.tenant); return json(res, { ok: true });
    }
    if (p === '/api/sites/rotate') {
      const s = DB.sites[b.id]; if (!s || !inScope(s.id)) return fail(res, 404, 'no such site');
      const tok = newToken(); s.token_hash = sha(tok); delete s.pending; dirty = true; audit(me.name, 'site.rotate', s.name, s.tenant);
      return json(res, { ok: true, token: tok });
    }
    if (p === '/api/sites/delete') {
      const s = DB.sites[b.id]; if (!s || !inScope(s.id)) return fail(res, 404, 'no such site');
      const tid = s.tenant; deleteSiteData(b.id); compactActivities();
      for (const n in DB.users) { const u = DB.users[n]; if (Array.isArray(u.sites) && u.sites.indexOf(String(b.id)) !== -1) u.sites = u.sites.filter(function (x) { return x !== String(b.id); }); }
      dirty = true; audit(me.name, 'site.delete', s.name, tid);
      return json(res, { ok: true });
    }
  }
  return fail(res, 404, 'not found');
}

const server = http.createServer(function (req, res) {
  handle(req, res).catch(function (e) {
    if (e && e.code && e.msg) return fail(res, e.code, e.msg);
    console.error(e);
    if (!res.headersSent) fail(res, 500, 'server error');
  });
});
server.headersTimeout = 30000;
server.requestTimeout = 60000;

/* ------------------------------------------------------------------ */
/* Start                                                               */
/* ------------------------------------------------------------------ */
loadDb();
loadActivities();
(function ensureAdmin() {
  const fromEnv = process.env.ADMIN_PASSWORD;
  if (!fromEnv && Object.values(DB.users).some(function (u) { return u.role === 'superadmin'; })) return;
  let pw = fromEnv, generated = false;
  if (!pw) {
    pw = crypto.randomBytes(12).toString('base64url') + crypto.randomInt(10); generated = true;
    try { fs.writeFileSync(path.join(DATA_DIR, 'admin-password.txt'), 'User: admin\r\nPassword: ' + pw + '\r\nYou must change it at first sign-in, then delete this file.\r\n'); } catch (e) {}
    console.log('First start. Platform admin login: admin / ' + pw + '   (also saved in ' + path.join(DATA_DIR, 'admin-password.txt') + ')');
  }
  const old = DB.users.admin || {};
  DB.users.admin = Object.assign(old, { pw: hashPw(pw), role: 'superadmin', tenant: null, sites: [], created: old.created || Date.now() / 1000, must_change: generated, pv: (old.pv || 0) + 1 });
  dirty = true;
})();
setInterval(saveDb, 5000);
setInterval(function () { intTick(); }, 15000).unref();
setInterval(flushActivities, 5000);
setInterval(function () { purge(); }, 6 * 3600e3);
setInterval(vulnSnapshot, 3600e3).unref();
setTimeout(vulnSnapshot, 60000).unref();
['SIGINT', 'SIGTERM'].forEach(function (s) { process.on(s, function () { dirty = true; saveDb(); flushActivities(); process.exit(0); }); });
process.on('exit', function () { saveDb(); flushActivities(); });

const listenArgs = /^\d+$/.test(String(PORT)) ? [Number(PORT), process.env.HOST || '0.0.0.0'] : [PORT];
server.listen.apply(server, listenArgs.concat([function () {
  console.log('OTSuraksha Central is running on port ' + PORT + '. Data file: ' + DB_FILE);
}]));

/* ------------------------------------------------------------------ */
/* Console page: public/index.html (single page, mobile first)        */
/* ------------------------------------------------------------------ */
const INDEX_FILE = path.join(__dirname, 'public', 'index.html');
const LOGIN_FILE = path.join(__dirname, 'public', 'login.html');
function loadLoginPage() {
  try { return fs.readFileSync(LOGIN_FILE, 'utf8'); }
  catch (e) { return '<!doctype html><meta charset="utf-8"><title>OTSuraksha Central</title><body style="font-family:sans-serif;padding:20px"><h2>Sign-in page not found</h2><p>Put <b>login.html</b> in the <b>public</b> folder next to central.js.</p><p><a href="/">Open the console</a></p>'; }
}
function loadPage() {          // read on each request, so edits to index.html show up without a restart
  try { return fs.readFileSync(INDEX_FILE, 'utf8'); }
  catch (e) {
    return '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OTSuraksha Central</title>' +
      '<body style="font-family:sans-serif;padding:20px;background:#07111f;color:#edf5ff"><h2>Console page not found</h2>' +
      '<p>Put <b>index.html</b> in a folder named <b>public</b> next to central.js, then reload this page.</p>';
  }
}
