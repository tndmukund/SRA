#!/usr/bin/env bash
# Run on the SERVER. Makes a ready-to-install pack for one site:   ./make-sensor-pack.sh "Plant-Pune" [--sensor-ip 10.0.0.9]
# Give the resulting file to the site; they run ONE command. Contains the site token - treat as secret.
set -euo pipefail
cd "$(dirname "$0")"
SITE="${1:-}"; shift || true; SIP=""; PORT=8443
[ -n "$SITE" ] || { sed -n '2,3p' "$0" | sed 's/^# \{0,1\}//'; exit 1; }
while [ $# -gt 0 ]; do case "$1" in --sensor-ip) SIP="$2"; shift 2;; --port) PORT="$2"; shift 2;; *) echo "unknown option $1"; exit 1;; esac; done
case "$SITE" in *[!A-Za-z0-9._-]*) echo "Site name: use only letters, numbers, dot, dash, underscore (e.g. Plant-Pune)"; exit 1;; esac
D="docker"; [ "$(id -u)" -eq 0 ] || D="sudo docker"
$D ps --format '{{.Names}}' | grep -qx otsense-central || { echo "Central is not running here. Install it first:  sudo ./install.sh central"; exit 1; }
OUT="$($D exec otsense-central python3 otsense_central.py --db /data/otsense.db add-site "$SITE" 2>&1)" || { echo "$OUT"; echo "If the site already exists, choose another name."; exit 1; }
TOKEN="$(echo "$OUT" | sed -n 's/.*Sensor token[^:]*: *//p')"; [ -n "$TOKEN" ] || { echo "$OUT"; exit 1; }
NAMEFIRST="$($D exec otsense-central cat /data/certs/server.names | tr ',' '\n' | grep -vE '^(localhost|127\.0\.0\.1)$' | head -1)"
P="sensor-packs/otsense-sensor-$SITE"; rm -rf "$P"; mkdir -p "$P"
cp sensor-pack-install.sh "$P/install.sh"; chmod +x "$P/install.sh"
printf 'SITE="%s"\nCENTRAL="https://%s:%s"\nTOKEN="%s"\nSENSOR_IP="%s"\n' "$SITE" "$NAMEFIRST" "$PORT" "$TOKEN" "$SIP" > "$P/sensor.conf"
$D cp otsense-central:/data/pki/ca.crt "$P/ca.crt"
if [ -n "$SIP" ]; then   # certificate for the sensor's own web page, signed by the same CA -> no browser warning
  $D exec otsense-central /usr/local/bin/entrypoint.sh issue /tmp/ui "localhost,127.0.0.1,$SIP"
  $D cp otsense-central:/tmp/ui.crt "$P/ui.crt"; $D cp otsense-central:/tmp/ui.key "$P/ui.key"
fi
$D save otsense:1.3 | gzip > "$P/otsense-image.tar.gz"
cat > "$P/READ-ME.txt" <<EOT
Site: $SITE.  On the sensor computer (Linux, 2 network ports; 2nd port on the switch's SPAN/mirror port), open a terminal in this folder and run:

    sudo ./install.sh

That's all. The site appears in the central console by itself.
EOT
chmod -R go-rwx "$P"; tar czf "$P.tar.gz" -C sensor-packs "otsense-sensor-$SITE"
echo; echo "READY:  $PWD/$P.tar.gz   (contains the site token: keep it private)"
echo "On the sensor computer:   tar xzf otsense-sensor-$SITE.tar.gz && cd otsense-sensor-$SITE && sudo ./install.sh"
