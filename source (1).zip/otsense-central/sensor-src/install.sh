#!/usr/bin/env bash
# OTSense one-command installer (Linux/macOS with Docker). No Python needed. Always HTTPS.
#   sudo ./install.sh central --name 10.0.0.5            server (once). Creates a private CA + certificate for that address
#   sudo ./install.sh sensor  --name 10.0.0.9 --pki ./otsense-pki      per site; --name = THIS sensor's address
#   options: --cert F --key F   use your own CA-signed certificate instead (central or sensor)
#   sudo ./install.sh trust                              make THIS computer trust the OTSense CA (no browser warning)
#   sudo ./install.sh uninstall central|sensor
set -euo pipefail
cd "$(dirname "$0")"
[ "$(id -u)" -eq 0 ] || { echo "Please run with sudo:  sudo ./install.sh $*"; exit 1; }
ROLE="${1:-}"; shift || true
trust_ca() {
  f="${1:-otsense-ca.crt}"; [ -f "$f" ] || { echo "CA file $f not found"; exit 1; }
  if [ "$(uname)" = Darwin ]; then security add-trusted-cert -d -r trustRoot -k /Library/Keychains/System.keychain "$f"
  elif [ -d /usr/local/share/ca-certificates ] || command -v update-ca-certificates >/dev/null; then
    mkdir -p /usr/local/share/ca-certificates; cp "$f" /usr/local/share/ca-certificates/otsense-ca.crt; update-ca-certificates >/dev/null
  elif command -v update-ca-trust >/dev/null; then cp "$f" /etc/pki/ca-trust/source/anchors/otsense-ca.crt; update-ca-trust
  else echo "Import $f into your browser/OS manually."; return; fi
  echo "This computer now trusts the OTSense CA. (Firefox keeps its own list: Settings > Certificates > Import $f)"
}
case "$ROLE" in
  central|sensor) ;;
  trust) trust_ca "${1:-otsense-ca.crt}"; exit 0;;
  uninstall) docker rm -f "otsense-${1:-x}" 2>/dev/null || true; echo "Removed. Data kept in Docker volume otsense-${1:-x} (docker volume rm to erase)."; exit 0;;
  *) sed -n '2,9p' "$0" | sed 's/^# \{0,1\}//'; exit 1;;
esac
NAME=""; PKI=""; CERT=""; KEY=""
while [ $# -gt 0 ]; do case "$1" in --name) NAME="$2"; shift 2;; --pki) PKI="$2"; shift 2;; --cert) CERT="$2"; shift 2;; --key) KEY="$2"; shift 2;; *) echo "unknown option $1"; exit 1;; esac; done
if ! command -v docker >/dev/null; then
  echo "Docker not found - installing it (one time)..."
  if [ -f docker-install.sh ]; then sh docker-install.sh; else curl -fsSL https://get.docker.com | sh; fi
  systemctl enable --now docker 2>/dev/null || true
fi
if [ -f otsense-image.tar.gz ]; then echo "Loading bundled image (offline)..."; docker load -i otsense-image.tar.gz >/dev/null
else echo "Building image..."; docker build -q -t otsense:1.3 . >/dev/null; fi
docker rm -f "otsense-$ROLE" >/dev/null 2>&1 || true
MOUNTS=()
if [ -n "$CERT" ]; then
  [ -f "$CERT" ] && [ -f "$KEY" ] || { echo "--cert and --key must both exist"; exit 1; }
  mkdir -p own-cert && cp "$CERT" own-cert/cert.pem && cp "$KEY" own-cert/key.pem && chmod 600 own-cert/key.pem
  MOUNTS+=(-v "$PWD/own-cert:/certs:ro")
fi
DEFIP="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [ "$ROLE" = central ]; then
  [ -n "$NAME" ] || NAME="$DEFIP"
  docker run -d --name otsense-central --restart unless-stopped -p 8443:8443 -e OTSENSE_NAME="$NAME" \
    -v otsense-central:/data "${MOUNTS[@]}" otsense:1.3 central >/dev/null
  sleep 5
  rm -rf otsense-pki; docker cp otsense-central:/data/pki ./otsense-pki 2>/dev/null && chmod -R go-rwx otsense-pki && cp otsense-pki/ca.crt otsense-ca.crt || true
  echo; docker logs otsense-central 2>&1 | grep -A3 "first start" || echo "(already set up - existing admin login unchanged)"
  echo; echo "Open:  https://${NAME%%,*}:8443"
  if [ -f otsense-ca.crt ] && [ -z "$CERT" ]; then
    echo; echo "To remove the browser certificate warning, trust the CA ONCE on each analyst PC:"
    echo "  Windows : double-click otsense-ca.crt > Install Certificate > Local Machine > 'Trusted Root Certification Authorities'"
    echo "  Linux/Mac: sudo ./install.sh trust            (this machine)"
    echo "  File to give them: $PWD/otsense-ca.crt   (safe to share; do NOT share the otsense-pki folder, it holds the CA's private key)"
    echo "For SENSORS: copy the whole otsense-pki folder to each sensor box (keep it private) and use --pki."
  fi
else
  [ -n "$PKI" ] && { [ -f "$PKI/ca.crt" ] && [ -f "$PKI/ca.key" ] || { echo "--pki folder must contain ca.crt and ca.key"; exit 1; }; MOUNTS+=(-v "$(cd "$PKI" && pwd):/pki:ro" -e OTSENSE_NAME="${NAME:-$DEFIP}"); }
  docker run -d --name otsense-sensor --restart unless-stopped --network host --cap-add NET_RAW --cap-add NET_ADMIN \
    -v otsense-sensor:/data "${MOUNTS[@]}" otsense:1.3 sensor >/dev/null
  sleep 6
  echo; docker logs otsense-sensor 2>&1 | grep -B1 -A1 "password" || echo "(already set up)"
  echo; echo "Open:  http://${NAME:-$DEFIP}  and follow the Setup page."
  [ -z "$PKI$CERT" ] && echo "(Self-signed certificate: browser warning expected. Re-run with --pki <otsense-pki> --name <this-ip> to remove it.)"
  echo "In Setup: central address https://<central-ip>:8443, and as the certificate paste/choose otsense-ca.crt."
fi
