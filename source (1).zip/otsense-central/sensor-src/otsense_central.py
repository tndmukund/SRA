#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OTSense Central - one database + one management console for all OTSense sensors.

  sensors (one per site, SPAN/TAP fed)  --HTTPS push (token)-->  OTSense Central (SQLite + web console)

  python otsense_central.py add-site "Plant-Pune"                 # creates the site, prints its token
  python otsense_central.py user add alice --role analyst         # roles: admin | analyst | viewer
  python otsense_central.py selfcert --san 10.0.0.5 --out certs   # self-signed TLS cert for the lab
  python otsense_central.py serve --cert certs/cert.pem --key certs/key.pem --port 8443

Pure Python 3.8+ standard library. Data: a single SQLite file (WAL mode).
"""
import argparse
import base64
import csv
import getpass
import gzip
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import shlex
import sqlite3
import socket
import ssl
import subprocess
import sys
import threading
import time
import traceback
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

VERSION = "1.0"
MAX_BODY = 32 * 1024 * 1024      # compressed ingest body
MAX_JSON = 128 * 1024 * 1024     # after decompression
SEV = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
ROLES = ("admin", "analyst", "viewer")

SCHEMA = """
CREATE TABLE IF NOT EXISTS sites(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, token_hash TEXT NOT NULL,
  created REAL, last_seen REAL, interval INTEGER DEFAULT 30, meta TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS assets(site_id INTEGER NOT NULL, id TEXT NOT NULL, ip TEXT, ipn INTEGER, mac TEXT, vendor TEXT,
  device_type TEXT, model TEXT, firmware TEXT, os TEXT, zone TEXT, hostnames TEXT, ot INTEGER, risk INTEGER,
  protocols TEXT, first_seen TEXT, last_seen TEXT, central_first REAL, updated REAL, search TEXT, data TEXT,
  PRIMARY KEY(site_id, id));
CREATE INDEX IF NOT EXISTS ix_assets_mac ON assets(mac);
CREATE INDEX IF NOT EXISTS ix_assets_type ON assets(device_type);
CREATE TABLE IF NOT EXISTS flows(site_id INTEGER NOT NULL, fid TEXT NOT NULL, client TEXT, server TEXT, proto TEXT, l4 TEXT,
  port INTEGER, ot INTEGER, packets INTEGER, bytes INTEGER, first_seen TEXT, last_seen TEXT, funcs TEXT, updated REAL,
  search TEXT, PRIMARY KEY(site_id, fid));
CREATE INDEX IF NOT EXISTS ix_flows_client ON flows(site_id, client);
CREATE INDEX IF NOT EXISTS ix_flows_server ON flows(site_id, server);
CREATE TABLE IF NOT EXISTS alerts(site_id INTEGER NOT NULL, uid TEXT NOT NULL, severity TEXT, sev INTEGER, kind TEXT,
  title TEXT, src TEXT, dst TEXT, proto TEXT, detail TEXT, count INTEGER, first_seen TEXT, last_seen TEXT, mitre TEXT,
  status TEXT DEFAULT 'new', note TEXT DEFAULT '', handled_by TEXT, handled_at REAL, updated REAL, search TEXT,
  PRIMARY KEY(site_id, uid));
CREATE INDEX IF NOT EXISTS ix_alerts_status ON alerts(status, sev);
CREATE TABLE IF NOT EXISTS users(name TEXT PRIMARY KEY, pw TEXT NOT NULL, role TEXT NOT NULL, created REAL);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS audit(ts REAL, who TEXT, action TEXT, detail TEXT);
"""


def iso(ts):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts)) if ts else None


def sha(x):
    return hashlib.sha256(x.encode()).hexdigest()


def hash_pw(pw, salt=None, it=200000):
    salt = salt or os.urandom(16)
    return "pbkdf2$%d$%s$%s" % (it, salt.hex(), hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, it).hex())


def check_pw(pw, stored):
    try:
        _, it, salt, h = stored.split("$")
        got = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), int(it)).hex()
        return hmac.compare_digest(got, h)
    except Exception:
        return False


def ipn(ip):
    try:
        p = [int(x) for x in ip.split(".")]
        if len(p) == 4 and all(0 <= x < 256 for x in p):
            return ((p[0] * 256 + p[1]) * 256 + p[2]) * 256 + p[3]
    except Exception:
        pass
    return None


def likeesc(s):
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def S(x, n=500):
    return None if x is None else str(x)[:n]


class DB:
    def __init__(self, path):
        self.lock = threading.RLock()
        self.c = sqlite3.connect(path, check_same_thread=False, isolation_level=None, timeout=30)
        self.c.row_factory = sqlite3.Row
        with self.lock:
            for pragma in ("journal_mode=WAL", "synchronous=NORMAL", "foreign_keys=OFF"):
                self.c.execute("PRAGMA " + pragma)
            self.c.executescript(SCHEMA)

    def q(self, sql, args=()):
        with self.lock:
            return [dict(r) for r in self.c.execute(sql, args).fetchall()]

    def one(self, sql, args=()):
        r = self.q(sql, args)
        return r[0] if r else None

    def x(self, sql, args=()):
        with self.lock:
            return self.c.execute(sql, args)


class App:
    def __init__(self, dbpath, retention=90):
        self.db = DB(dbpath)
        self.retention = retention
        self.tls = False
        self.fails = {}
        r = self.db.one("SELECT v FROM settings WHERE k='secret'")
        if not r:
            self.db.x("INSERT INTO settings(k,v) VALUES('secret',?)", (secrets.token_hex(32),))
            r = self.db.one("SELECT v FROM settings WHERE k='secret'")
        self.secret = bytes.fromhex(r["v"])

    # ------------------------------------------------------------ audit / users / sessions
    def audit(self, who, action, detail=""):
        self.db.x("INSERT INTO audit(ts,who,action,detail) VALUES(?,?,?,?)", (time.time(), who, action, detail[:500]))

    def add_user(self, name, pw, role):
        if role not in ROLES:
            raise ValueError("role must be one of %s" % ", ".join(ROLES))
        self.db.x("INSERT OR REPLACE INTO users(name,pw,role,created) VALUES(?,?,?,?)", (name, hash_pw(pw), role, time.time()))

    def cookie(self, user, role, ttl=12 * 3600):
        p = base64.urlsafe_b64encode(json.dumps({"u": user, "r": role, "e": int(time.time() + ttl)}).encode()).decode().rstrip("=")
        return p + "." + hmac.new(self.secret, p.encode(), hashlib.sha256).hexdigest()

    def read_cookie(self, val):
        try:
            p, sig = val.split(".")
            if not hmac.compare_digest(sig, hmac.new(self.secret, p.encode(), hashlib.sha256).hexdigest()):
                return None
            d = json.loads(base64.urlsafe_b64decode(p + "=" * (-len(p) % 4)))
            if d["e"] < time.time():
                return None
            u = self.db.one("SELECT name, role FROM users WHERE name=?", (d["u"],))
            return {"user": u["name"], "role": u["role"]} if u else None
        except Exception:
            return None

    # ------------------------------------------------------------ sites
    def new_token(self):
        return "otsc_" + secrets.token_urlsafe(32)

    def add_site(self, name, who="cli"):
        name = name.strip()
        if not name or len(name) > 80:
            raise ValueError("site name must be 1-80 characters")
        tok = self.new_token()
        try:
            self.db.x("INSERT INTO sites(name,token_hash,created,interval) VALUES(?,?,?,30)", (name, sha(tok), time.time()))
        except sqlite3.IntegrityError:
            raise ValueError("site '%s' already exists" % name)
        self.audit(who, "site.add", name)
        return tok

    def site_by_token(self, tok):
        return self.db.one("SELECT * FROM sites WHERE token_hash=?", (sha(tok),)) if tok else None

    # ------------------------------------------------------------ ingest
    def ingest(self, site, body):
        now, sid = time.time(), site["id"]
        n = {"assets": 0, "flows": 0, "alerts": 0, "rejected": 0}
        with self.db.lock:
            c = self.db.c
            c.execute("BEGIN")
            try:
                for a in body.get("assets") or []:
                    try:
                        self._asset(c, sid, a, now)
                        n["assets"] += 1
                    except Exception:
                        n["rejected"] += 1
                for f in body.get("flows") or []:
                    try:
                        self._flow(c, sid, f, now)
                        n["flows"] += 1
                    except Exception:
                        n["rejected"] += 1
                for al in body.get("alerts") or []:
                    try:
                        self._alert(c, sid, al, now)
                        n["alerts"] += 1
                    except Exception:
                        n["rejected"] += 1
                meta = body.get("sensor") if isinstance(body.get("sensor"), dict) else {}
                iv = meta.get("interval") if isinstance(meta.get("interval"), int) else 30
                c.execute("UPDATE sites SET last_seen=?, interval=?, meta=? WHERE id=?",
                          (now, max(5, min(iv, 3600)), json.dumps(meta)[:20000], sid))
                c.execute("COMMIT")
            except Exception:
                c.execute("ROLLBACK")
                raise
        return n

    @staticmethod
    def _asset(c, sid, a, now):
        ip, props = a.get("ip"), a.get("properties") or {}
        otp = a.get("ot_protocols") or []
        protos = sorted(set(otp) | set((a.get("serves") or {}).keys()) | set((a.get("uses") or {}).keys()))
        hn = a.get("hostnames") or []
        tags = a.get("tags") or {}
        search = " ".join(str(x) for x in [
            ip, a.get("mac"), a.get("vendor"), a.get("mac_vendor"), a.get("device_type"), a.get("subtype"), a.get("model"),
            a.get("firmware"), a.get("serial"), a.get("os_guess"), a.get("zone"), a.get("purdue_guess"), " ".join(protos),
            " ".join(hn), " ".join(a.get("listening_ports") or []), " ".join(a.get("flags") or []),
            " ".join(str(v) for v in props.values()), " ".join(" ".join(map(str, v)) for v in tags.values())] if x).lower()[:6000]
        c.execute("""INSERT INTO assets(site_id,id,ip,ipn,mac,vendor,device_type,model,firmware,os,zone,hostnames,ot,risk,
                     protocols,first_seen,last_seen,central_first,updated,search,data)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                     ON CONFLICT(site_id,id) DO UPDATE SET ip=excluded.ip, ipn=excluded.ipn, mac=excluded.mac,
                     vendor=excluded.vendor, device_type=excluded.device_type, model=excluded.model,
                     firmware=excluded.firmware, os=excluded.os, zone=excluded.zone, hostnames=excluded.hostnames,
                     ot=excluded.ot, risk=excluded.risk, protocols=excluded.protocols,
                     first_seen=MIN(assets.first_seen, excluded.first_seen), last_seen=excluded.last_seen,
                     updated=excluded.updated, search=excluded.search, data=excluded.data""",
                  (sid, S(a["id"], 200), S(ip, 64), ipn(ip or ""), S(a.get("mac"), 32), S(a.get("vendor"), 120),
                   S(a.get("device_type"), 80), S(a.get("model"), 200), S(a.get("firmware"), 80), S(a.get("os_guess"), 120),
                   S(a.get("zone"), 80), S(", ".join(hn), 300), 1 if a.get("is_ot") else 0, int(a.get("risk") or 0),
                   ",".join(protos)[:800], S(a.get("first_seen"), 24), S(a.get("last_seen"), 24), now, now, search,
                   json.dumps(a, separators=(",", ":"))[:200000]))

    @staticmethod
    def _flow(c, sid, f, now):
        funcs = f.get("functions") or {}
        search = " ".join(str(x) for x in [f.get("client"), f.get("server"), f.get("proto"), f.get("l4"), f.get("port"),
                                           " ".join(funcs.keys())]).lower()[:1500]
        c.execute("""INSERT INTO flows(site_id,fid,client,server,proto,l4,port,ot,packets,bytes,first_seen,last_seen,funcs,updated,search)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                     ON CONFLICT(site_id,fid) DO UPDATE SET proto=excluded.proto, ot=excluded.ot, packets=excluded.packets,
                     bytes=excluded.bytes, first_seen=MIN(flows.first_seen, excluded.first_seen), last_seen=excluded.last_seen,
                     funcs=excluded.funcs, updated=excluded.updated, search=excluded.search""",
                  (sid, S(f["fid"], 300), S(f.get("client"), 80), S(f.get("server"), 80), S(f.get("proto"), 60), S(f.get("l4"), 8),
                   int(f.get("port") or 0), 1 if f.get("ot") else 0, int(f.get("packets") or 0), int(f.get("bytes") or 0),
                   S(f.get("first"), 24), S(f.get("last"), 24), json.dumps(funcs)[:3000], now, search))

    @staticmethod
    def _alert(c, sid, a, now):
        sev = a.get("severity") if a.get("severity") in SEV else "info"
        search = " ".join(str(x) for x in [a.get("kind"), a.get("title"), a.get("src"), a.get("dst"), a.get("proto"),
                                           a.get("detail"), a.get("mitre"), sev]).lower()[:1500]
        c.execute("""INSERT INTO alerts(site_id,uid,severity,sev,kind,title,src,dst,proto,detail,count,first_seen,last_seen,mitre,
                     status,note,updated,search) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'new','',?,?)
                     ON CONFLICT(site_id,uid) DO UPDATE SET severity=excluded.severity, sev=excluded.sev, title=excluded.title,
                     detail=excluded.detail, count=excluded.count, last_seen=excluded.last_seen, updated=excluded.updated,
                     search=excluded.search, first_seen=MIN(alerts.first_seen, excluded.first_seen),
                     status=CASE WHEN alerts.status='closed' AND excluded.count>alerts.count THEN 'new' ELSE alerts.status END""",
                  (sid, S(a["uid"], 64), sev, SEV[sev], S(a.get("kind"), 40), S(a.get("title"), 300), S(a.get("src"), 120),
                   S(a.get("dst"), 120), S(a.get("proto"), 60), S(a.get("detail"), 300), int(a.get("count") or 1),
                   S(a.get("first"), 24), S(a.get("last"), 24), S(a.get("mitre"), 20), now, search))

    # ------------------------------------------------------------ housekeeping
    def purge(self):
        if self.retention <= 0:
            return
        cut = iso(time.time() - self.retention * 86400)
        self.db.x("DELETE FROM flows WHERE last_seen < ?", (cut,))
        self.db.x("DELETE FROM alerts WHERE status='closed' AND last_seen < ?", (cut,))
        self.db.x("DELETE FROM audit WHERE ts < ?", (time.time() - 365 * 86400,))

    # ------------------------------------------------------------ queries
    def _where(self, kind, p):
        w, a = [], []
        al = {"assets": "a", "alerts": "l", "flows": "f"}[kind]
        if p.get("site"):
            w.append("%s.site_id=?" % al)
            a.append(int(p["site"]))
        if kind == "assets":
            for k, col in (("type", "a.device_type"), ("vendor", "a.vendor"), ("zone", "a.zone")):
                if p.get(k):
                    w.append(col + "=?")
                    a.append(p[k])
            if p.get("proto"):
                w.append("(',' || a.protocols || ',') LIKE ? ESCAPE '\\'")
                a.append("%," + likeesc(p["proto"]) + ",%")
            if p.get("ot") == "1":
                w.append("a.ot=1")
            if p.get("risk"):
                w.append("a.risk>=?")
                a.append(int(p["risk"]))
        elif kind == "alerts":
            for k, col in (("sev", "l.severity"), ("status", "l.status"), ("kind", "l.kind")):
                if p.get(k):
                    w.append(col + "=?")
                    a.append(p[k])
        else:
            if p.get("proto"):
                w.append("f.proto=?")
                a.append(p["proto"])
            if p.get("ot") == "1":
                w.append("f.ot=1")
        self._qterms(kind, p.get("q") or "", w, a)
        return (" WHERE " + " AND ".join(w)) if w else "", a

    @staticmethod
    def _qterms(kind, q, w, a):
        fields = {
            "assets": {"ip": "a.ip", "mac": "a.mac", "vendor": "a.vendor", "type": "a.device_type", "model": "a.model",
                       "fw": "a.firmware", "firmware": "a.firmware", "os": "a.os", "zone": "a.zone", "proto": "a.protocols",
                       "host": "a.hostnames", "site": "s.name", "risk": "#risk"},
            "alerts": {"sev": "l.severity", "severity": "l.severity", "kind": "l.kind", "src": "l.src", "dst": "l.dst",
                       "ip": ("l.src", "l.dst"), "proto": "l.proto", "status": "l.status", "site": "s.name",
                       "mitre": "l.mitre"},
            "flows": {"client": "f.client", "server": "f.server", "ip": ("f.client", "f.server"), "proto": "f.proto",
                      "port": "#port", "site": "s.name", "func": "f.search"}}[kind]
        generic = {"assets": "a.search", "alerts": "l.search", "flows": "f.search"}[kind]
        try:
            toks = shlex.split(q)
        except ValueError:
            toks = q.split()
        for t in toks[:12]:
            neg = len(t) > 1 and t[0] == "-"
            if neg:
                t = t[1:]
            m = re.match(r"^([A-Za-z_]+):(.+)$", t)
            if m and m.group(1).lower() in fields:
                col, val = fields[m.group(1).lower()], m.group(2)
                if col == "#risk":
                    mm = re.match(r"^(>=|<=|>|<|=)?(\d{1,3})$", val)
                    if mm:
                        w.append("a.risk %s ?" % (mm.group(1) or ">="))
                        a.append(int(mm.group(2)))
                    continue
                if col == "#port":
                    if val.isdigit():
                        w.append("f.port %s ?" % ("!=" if neg else "="))
                        a.append(int(val))
                    continue
                cols = col if isinstance(col, tuple) else (col,)
                like = "NOT LIKE" if neg else "LIKE"
                join = " AND " if neg else " OR "
                w.append("(" + join.join("COALESCE(%s,'') %s ? ESCAPE '\\'" % (c, like) for c in cols) + ")")
                a.extend(["%" + likeesc(val) + "%"] * len(cols))
            else:
                w.append("%s %s ? ESCAPE '\\'" % (generic, "NOT LIKE" if neg else "LIKE"))
                a.append("%" + likeesc(t.lower()) + "%")

    SORTS = {
        "assets": {"site": "s.name", "ip": "a.ipn", "mac": "a.mac", "vendor": "a.vendor", "type": "a.device_type",
                   "model": "a.model", "zone": "a.zone", "risk": "a.risk", "last_seen": "a.last_seen",
                   "first_seen": "a.first_seen", "proto": "a.protocols"},
        "alerts": {"sev": "l.sev", "site": "s.name", "kind": "l.kind", "title": "l.title", "src": "l.src", "dst": "l.dst",
                   "proto": "l.proto", "count": "l.count", "last_seen": "l.last_seen", "status": "l.status",
                   "mitre": "l.mitre"},
        "flows": {"site": "s.name", "client": "f.client", "server": "f.server", "proto": "f.proto", "port": "f.port",
                  "packets": "f.packets", "bytes": "f.bytes", "last_seen": "f.last_seen"}}
    SELECT = {
        "assets": "a.site_id, s.name AS site, a.id, a.ip, a.mac, a.vendor, a.device_type, a.model, a.firmware, a.os, a.zone, "
                  "a.hostnames, a.ot, a.risk, a.protocols, a.first_seen, a.last_seen",
        "alerts": "l.site_id, s.name AS site, l.uid, l.severity, l.kind, l.title, l.src, l.dst, l.proto, l.detail, l.count, "
                  "l.first_seen, l.last_seen, l.mitre, l.status, l.note, l.handled_by",
        "flows": "f.site_id, s.name AS site, f.fid, f.client, f.server, f.proto, f.l4, f.port, f.ot, f.packets, f.bytes, "
                 "f.first_seen, f.last_seen, f.funcs"}
    TABLE = {"assets": "assets a", "alerts": "alerts l", "flows": "flows f"}
    ALIAS = {"assets": "a", "alerts": "l", "flows": "f"}

    def list(self, kind, p, limit=None):
        where, args = self._where(kind, p)
        frm = "%s JOIN sites s ON s.id=%s.site_id" % (self.TABLE[kind], self.ALIAS[kind])
        total = self.db.one("SELECT COUNT(*) c FROM " + frm + where, args)["c"]
        col = self.SORTS[kind].get(p.get("sort") or "", list(self.SORTS[kind].values())[0])
        d = "ASC" if p.get("dir") == "asc" else "DESC"
        nulls = "(%s IS NULL)" % col
        page = max(1, int(p.get("page") or 1))
        lim = limit or max(1, min(500, int(p.get("limit") or 50)))
        sql = "SELECT %s FROM %s%s ORDER BY %s, %s %s LIMIT ? OFFSET ?" % (
            self.SELECT[kind], frm, where, nulls, col, d)
        rows = self.db.q(sql, args + [lim, (page - 1) * lim])
        return {"total": total, "page": page, "limit": lim, "rows": rows}

    def export(self, kind, p):
        where, args = self._where(kind, p)
        frm = "%s JOIN sites s ON s.id=%s.site_id" % (self.TABLE[kind], self.ALIAS[kind])
        col = self.SORTS[kind].get(p.get("sort") or "", list(self.SORTS[kind].values())[0])
        rows = self.db.q("SELECT %s FROM %s%s ORDER BY %s %s LIMIT 200000" % (
            self.SELECT[kind], frm, where, col, "ASC" if p.get("dir") == "asc" else "DESC"), args)
        out = io.StringIO()
        if rows:
            w = csv.writer(out)
            keys = [k for k in rows[0].keys() if k != "site_id"]
            w.writerow(keys)
            for r in rows:
                w.writerow([r[k] for k in keys])
        return out.getvalue()

    def counts(self, p):
        res = {}
        for kind in ("assets", "alerts", "flows"):
            q = {"site": p.get("site"), "q": p.get("q")}
            where, args = self._where(kind, q)
            res[kind] = self.db.one("SELECT COUNT(*) c FROM %s JOIN sites s ON s.id=%s.site_id%s" % (
                self.TABLE[kind], self.ALIAS[kind], where), args)["c"]
        return res

    def facets(self, p):
        site = int(p["site"]) if p.get("site") else None
        cond, args = (" WHERE site_id=?", [site]) if site else ("", [])
        protos = set()
        for r in self.db.q("SELECT DISTINCT protocols FROM assets" + cond, args):
            protos.update(x for x in (r["protocols"] or "").split(",") if x)
        fprotos = [r["proto"] for r in self.db.q("SELECT DISTINCT proto FROM flows" + cond + " ORDER BY proto", args) if r["proto"]]
        return {"types": [r["device_type"] for r in self.db.q("SELECT DISTINCT device_type FROM assets" + cond + " ORDER BY 1", args) if r["device_type"]],
                "vendors": [r["vendor"] for r in self.db.q("SELECT DISTINCT vendor FROM assets" + cond + " ORDER BY 1", args) if r["vendor"]],
                "zones": [r["zone"] for r in self.db.q("SELECT DISTINCT zone FROM assets" + cond + " ORDER BY 1", args) if r["zone"]],
                "protocols": sorted(protos), "flow_protocols": fprotos,
                "alert_kinds": [r["kind"] for r in self.db.q("SELECT DISTINCT kind FROM alerts" + cond + " ORDER BY 1", args) if r["kind"]]}

    @staticmethod
    def status_of(site, now):
        if not site["last_seen"]:
            return "never"
        return "online" if now - site["last_seen"] <= max(3 * (site["interval"] or 30), 90) else "offline"

    def sites(self):
        now = time.time()
        rows = self.db.q("""SELECT s.id, s.name, s.created, s.last_seen, s.interval, s.meta, s.note,
            (SELECT COUNT(*) FROM assets a WHERE a.site_id=s.id) assets,
            (SELECT COUNT(*) FROM assets a WHERE a.site_id=s.id AND a.ot=1) ot_assets,
            (SELECT COUNT(*) FROM flows f WHERE f.site_id=s.id) flows,
            (SELECT COUNT(*) FROM alerts l WHERE l.site_id=s.id AND l.status='new') new_alerts,
            (SELECT COUNT(*) FROM alerts l WHERE l.site_id=s.id AND l.status='new' AND l.sev=4) critical,
            (SELECT COUNT(*) FROM alerts l WHERE l.site_id=s.id AND l.status='new' AND l.sev=3) high
            FROM sites s ORDER BY s.name""")
        for r in rows:
            r["status"] = self.status_of(r, now)
            r["age"] = int(now - r["last_seen"]) if r["last_seen"] else None
            try:
                r["meta"] = json.loads(r["meta"]) if r["meta"] else {}
            except ValueError:
                r["meta"] = {}
        return rows

    def overview(self, p):
        sites = self.sites()
        site = int(p["site"]) if p.get("site") else None
        cond, args = (" WHERE site_id=?", [site]) if site else ("", [])
        sel = [s for s in sites if not site or s["id"] == site]
        types = self.db.q("SELECT device_type k, COUNT(*) n FROM assets" + cond + " GROUP BY 1 ORDER BY 2 DESC", args)
        vendors = self.db.q("SELECT COALESCE(vendor,'Unknown') k, COUNT(*) n FROM assets" + cond + " GROUP BY 1 ORDER BY 2 DESC LIMIT 10", args)
        protos = {}
        for r in self.db.q("SELECT protocols, ot FROM assets" + cond, args):
            for x in (r["protocols"] or "").split(","):
                if x:
                    protos[x] = protos.get(x, 0) + 1
        sevs = {r["severity"]: r["n"] for r in self.db.q(
            "SELECT severity, COUNT(*) n FROM alerts WHERE status='new'" + (" AND site_id=?" if site else "") + " GROUP BY 1", args)}
        recent = self.list("alerts", {"site": p.get("site"), "status": "new", "sort": "sev", "dir": "desc"}, 8)["rows"]
        risky = self.list("assets", {"site": p.get("site"), "sort": "risk", "dir": "desc", "risk": "1"}, 8)["rows"]
        return {"now": time.time(), "sites": sites,
                "totals": {"sites": len(sel), "online": sum(1 for s in sel if s["status"] == "online"),
                           "assets": sum(s["assets"] for s in sel), "ot_assets": sum(s["ot_assets"] for s in sel),
                           "flows": sum(s["flows"] for s in sel), "new_alerts": sum(s["new_alerts"] for s in sel),
                           "critical": sum(s["critical"] for s in sel), "high": sum(s["high"] for s in sel)},
                "device_types": types, "vendors": vendors, "alert_severity": sevs,
                "protocols": sorted(({"k": k, "n": n} for k, n in protos.items()), key=lambda x: -x["n"])[:14],
                "recent_alerts": recent, "risky_assets": risky}

    def asset_detail(self, site_id, aid):
        r = self.db.one("SELECT a.data, s.name site FROM assets a JOIN sites s ON s.id=a.site_id WHERE a.site_id=? AND a.id=?", (site_id, aid))
        if not r:
            return None
        d = json.loads(r["data"])
        keys = [k for k in (d.get("ip"), d.get("mac")) if k]
        ph = ",".join("?" * len(keys)) or "''"
        flows = self.db.q("SELECT client,server,proto,l4,port,ot,packets,bytes,last_seen,funcs FROM flows WHERE site_id=? AND (client IN (%s) OR server IN (%s)) "
                          "ORDER BY packets DESC LIMIT 60" % (ph, ph), [site_id] + keys + keys)
        alerts = self.db.q("SELECT uid,severity,kind,title,src,dst,proto,count,last_seen,status FROM alerts WHERE site_id=? AND (src IN (%s) OR dst IN (%s)) "
                           "ORDER BY sev DESC, last_seen DESC LIMIT 60" % (ph, ph), [site_id] + keys + keys)
        others = []
        if d.get("mac"):
            others = self.db.q("SELECT s.name site, a.ip, a.device_type, a.last_seen FROM assets a JOIN sites s ON s.id=a.site_id "
                               "WHERE a.mac=? AND a.site_id!=?", (d["mac"], site_id))
        return {"site": r["site"], "site_id": site_id, "asset": d, "flows": flows, "alerts": alerts, "other_sites": others}

    def topo(self, site_id):
        assets = self.db.q("SELECT id, ip, mac, device_type, ot, risk, zone FROM assets WHERE site_id=? ORDER BY risk DESC LIMIT 700", (site_id,))
        flows = self.db.q("SELECT client, server, ot, packets FROM flows WHERE site_id=? ORDER BY ot DESC, packets DESC LIMIT 1800", (site_id,))
        return {"assets": assets, "flows": flows}


# ----------------------------------------------------------------------------------------------
# Web console (single page, served from memory)
# ----------------------------------------------------------------------------------------------

PAGE = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>OTSense Central</title>
<style>
:root{--bg:#0e1319;--card:#161d26;--line:#263142;--txt:#e7edf4;--mut:#8996a8;--acc:#4da3ff;--ot:#ff9f43;
--critical:#ff4d4f;--high:#ff7a45;--medium:#f5b02e;--low:#4ecb71;--info:#69b1ff;--ok:#4ecb71;--bad:#ff4d4f}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);font:14px/1.45 system-ui,Segoe UI,Roboto,sans-serif}
header{display:flex;align-items:center;gap:12px;padding:10px 18px;border-bottom:1px solid var(--line);flex-wrap:wrap}
h1{font-size:18px;margin:0;white-space:nowrap}h1 span{color:var(--acc)}h1 small{color:var(--mut);font-weight:400;font-size:13px}
.mut{color:var(--mut)}
#gq{flex:1;min-width:260px;max-width:760px}
nav{display:flex;gap:4px;padding:0 18px;border-bottom:1px solid var(--line);overflow-x:auto}
nav button{background:none;border:0;color:var(--mut);padding:10px 14px;cursor:pointer;font:inherit;border-bottom:2px solid transparent;white-space:nowrap}
nav button.on{color:var(--txt);border-color:var(--acc)}nav .n{color:var(--mut);font-size:12px}
main{padding:16px 18px;max-width:1700px;margin:auto}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:14px}
.tile{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.tile b{display:block;font-size:24px}.tile small{color:var(--mut)}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px;margin-bottom:14px}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(380px,1fr));gap:14px}
.sites{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px;margin-bottom:14px}
.site{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px;cursor:pointer}
.site:hover{border-color:var(--acc)}.site h4{margin:0 0 6px;font-size:15px}.site .row{display:flex;justify-content:space-between;color:var(--mut);font-size:13px}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px;background:#5b6778}.dot.online{background:var(--ok)}.dot.offline{background:var(--bad)}
h2{font-size:13px;margin:0 0 10px;color:var(--mut);text-transform:uppercase;letter-spacing:.06em}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--mut);font-weight:600;white-space:nowrap;user-select:none;position:sticky;top:0;background:var(--card)}th[data-k]{cursor:pointer}
tr.row:hover{background:#1c2633}tr[data-asset],tr[data-site]{cursor:pointer}
.wrap{overflow:auto;max-height:68vh;padding:0}
.badge{display:inline-block;padding:1px 7px;border-radius:9px;font-size:12px;margin:1px 2px 1px 0;background:#223044;color:#c9d6e6}
.badge.ot{background:#4a3414;color:var(--ot)}
.sev{padding:1px 8px;border-radius:4px;font-size:12px;font-weight:600;color:#0e1319;white-space:nowrap}
.sev.critical{background:var(--critical)}.sev.high{background:var(--high)}.sev.medium{background:var(--medium)}.sev.low{background:var(--low)}.sev.info{background:var(--info)}
.st{font-size:12px;padding:1px 7px;border-radius:9px;border:1px solid var(--line)}.st.new{color:var(--medium);border-color:var(--medium)}.st.ack{color:var(--info)}.st.closed{color:var(--mut)}
.bar{height:8px;background:#223044;border-radius:4px;min-width:50px}.bar i{display:block;height:100%;border-radius:4px;background:var(--acc)}.bar.ot i{background:var(--ot)}
input,select{background:#0e1319;color:var(--txt);border:1px solid var(--line);border-radius:6px;padding:6px 9px;font:inherit}
button,.btn{background:#223044;color:var(--txt);border:0;border-radius:6px;padding:6px 12px;font:inherit;cursor:pointer;text-decoration:none;display:inline-block}
button.pri,.btn.pri{background:var(--acc);color:#04121f;font-weight:600}button:disabled{opacity:.45;cursor:default}button.danger{background:#5a2226}
.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px}.toolbar label{color:var(--mut);display:flex;align-items:center;gap:5px}
.pager{display:flex;gap:10px;align-items:center;margin:-4px 0 10px}
.hint{color:var(--mut);font-size:12px;margin-bottom:8px}.hint code{background:#223044;padding:0 4px;border-radius:3px}
.lnk{cursor:pointer;color:#9cc9ff}.lnk:hover{text-decoration:underline}
.warn{background:#3b2a12;border:1px solid #7a5418;color:#ffd48a;padding:9px 12px;border-radius:8px;margin-bottom:14px}
#drawer{position:fixed;right:0;top:0;bottom:0;width:min(640px,100%);background:#121921;border-left:1px solid var(--line);padding:16px;overflow:auto;transform:translateX(105%);transition:.2s;z-index:5}
#drawer.open{transform:none}#drawer h3{margin:0 0 2px}
.kv{display:grid;grid-template-columns:150px 1fr;gap:3px 10px;margin:10px 0}.kv div:nth-child(odd){color:var(--mut)}
.overlay{position:fixed;inset:0;background:#000b;display:flex;align-items:center;justify-content:center;z-index:20}
.box{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:22px;width:min(520px,94%)}
.box h3{margin:0 0 12px}.box input{width:100%;margin-bottom:10px}pre{background:#0b1016;border:1px solid var(--line);border-radius:8px;padding:10px;overflow:auto;white-space:pre-wrap;word-break:break-all}
canvas{width:100%;height:600px;background:#0b1016;border:1px solid var(--line);border-radius:10px;display:block}
#tip{position:fixed;pointer-events:none;background:#000c;padding:4px 8px;border-radius:5px;font-size:12px;display:none;z-index:9}
.legend span{margin-right:12px;font-size:12px}.legend i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:4px}
</style></head><body>
<div id="login" class="overlay" style="display:none"><form class="box" id="lf"><h3><span style="color:var(--acc)">OT</span>Sense Central</h3>
<input id="lu" placeholder="Username" autocomplete="username" autofocus><input id="lp" type="password" placeholder="Password" autocomplete="current-password">
<div id="le" style="color:var(--bad);min-height:20px"></div><button class="pri" type="submit">Sign in</button></form></div>
<header><h1><span>OT</span>Sense <small>Central</small></h1>
<select id="siteSel" title="Filter by site"></select>
<input id="gq" placeholder="Search all sites: IP, MAC, vendor, model, protocol, hostname, alert text...">
<span style="flex:1"></span><span id="who"></span></header>
<nav id="nav"></nav><main id="main"></main>
<div id="drawer"></div><div id="modal"></div><div id="tip"></div>
<script>
'use strict';
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fb=n=>{if(n<1024)return n+' B';const u=['KB','MB','GB','TB'];let i=-1;do{n/=1024;i++}while(n>=1024&&i<3);return n.toFixed(1)+' '+u[i]};
const ago=s=>s==null?'never':s<90?s+'s ago':s<5400?Math.round(s/60)+' min ago':s<172800?Math.round(s/3600)+' h ago':Math.round(s/86400)+' d ago';
const TYPECOL={'PLC / RTU / Controller':'#ff9f43','HMI / Engineering Workstation':'#4da3ff','SCADA Master / Server':'#9b7bff','IT Server':'#52c7b8','Router / Gateway':'#8996a8','Network Switch':'#8996a8','BACnet Device':'#f5b02e','OPC UA Server':'#e879f9','PROFINET / IEC 61850 Device':'#ff9f43','External Host':'#ff4d4f','Workstation / Endpoint':'#69b1ff','Unclassified':'#5b6778'};
const col=t=>TYPECOL[t]||'#5b6778';
const TABS=[['dashboard','Dashboard'],['assets','Assets'],['alerts','Alerts'],['flows','Communications'],['map','Network map'],['sites','Sites & sensors']];
let S={tab:'dashboard',q:'',site:'',page:{assets:1,alerts:1,flows:1},sort:{assets:['risk','desc'],alerts:['sev','desc'],flows:['packets','desc']},
 f:{assets:{},alerts:{status:'new'},flows:{}},sel:new Set(),me:null,sites:[],counts:{},mapSite:''};
const canAck=()=>S.me&&(S.me.role==='admin'||S.me.role==='analyst'),isAdmin=()=>S.me&&S.me.role==='admin';

async function api(path,params,body){
 let url=path;
 if(params){const u=new URLSearchParams();for(const k in params){const v=params[k];if(v!==''&&v!=null&&v!==false)u.set(k,v===true?'1':v)}const s=u.toString();if(s)url+='?'+s}
 const r=await fetch(url,body!==undefined?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});
 if(r.status===401){showLogin();throw new Error('auth')}
 let j={};try{j=await r.json()}catch(e){}
 if(!r.ok)throw new Error(j.error||r.statusText);return j}
function showLogin(){$('login').style.display='flex'}
$('lf').onsubmit=async e=>{e.preventDefault();$('le').textContent='';
 const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user:$('lu').value,password:$('lp').value})});
 if(r.ok){$('lp').value='';$('login').style.display='none';boot()}else{let j={};try{j=await r.json()}catch(x){}$('le').textContent=j.error||'Login failed'}};

async function boot(){
 try{S.me=await api('/api/me')}catch(e){return}
 if(S.me.anon){showLogin();return}
 $('who').innerHTML=esc(S.me.user)+' <span class="badge">'+esc(S.me.role)+'</span> <a href="#" class="lnk" id="pw">password</a> &middot; <a href="#" class="lnk" id="lo">sign out</a>';
 $('lo').onclick=async e=>{e.preventDefault();await fetch('/api/logout',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});location.reload()};
 $('pw').onclick=e=>{e.preventDefault();changePw()};
 await refreshSites();render()}
async function refreshSites(){
 S.sites=await api('/api/sites');
 const sel=$('siteSel');sel.innerHTML='<option value="">All sites ('+S.sites.length+')</option>'+S.sites.map(s=>'<option value="'+s.id+'"'+(String(s.id)===String(S.site)?' selected':'')+'>'+esc(s.name)+(s.status==='offline'?' (offline)':'')+'</option>').join('')}
$('siteSel').onchange=e=>{S.site=e.target.value;resetPages();render()};
let gqT=null;
$('gq').oninput=e=>{clearTimeout(gqT);gqT=setTimeout(()=>{S.q=e.target.value.trim();resetPages();if(S.q&&['dashboard','sites','map'].includes(S.tab))S.tab='assets';render()},300)};
function resetPages(){S.page={assets:1,alerts:1,flows:1};S.sel.clear()}
function drawNav(){
 $('nav').innerHTML=TABS.map(t=>{const n=S.counts[t[0]];return '<button data-t="'+t[0]+'" class="'+(S.tab===t[0]?'on':'')+'">'+t[1]+(n!=null?' <span class="n">'+n.toLocaleString()+'</span>':'')+'</button>'}).join('')}
$('nav').onclick=e=>{const b=e.target.closest('button[data-t]');if(b){S.tab=b.dataset.t;S.sel.clear();render()}};

async function render(quiet){
 drawNav();const m=$('main');if(!quiet)m.innerHTML='<p class="mut">Loading...</p>';
 try{
  const cp=api('/api/counts',{q:S.q,site:S.site});
  const html=await VIEW[S.tab]();
  S.counts=await cp;drawNav();m.innerHTML=html;if(AFTER[S.tab])AFTER[S.tab]();
 }catch(e){if(e.message!=='auth')m.innerHTML='<div class="card">Error: '+esc(e.message)+'</div>'}}

function opts(list,val,all){return '<option value="">'+all+'</option>'+list.map(x=>'<option'+(x===val?' selected':'')+'>'+esc(x)+'</option>').join('')}
function badges(a,ot){return (a||[]).map(x=>'<span class="badge'+(ot&&ot.includes(x)?' ot':'')+'">'+esc(x)+'</span>').join('')}
function sevb(s){return '<span class="sev '+s+'">'+s+'</span>'}
function table(kind,cols,rows,fn){
 const [sk,sd]=S.sort[kind];
 return '<div class="card wrap"><table><tr>'+cols.map(c=>'<th'+(c[2]===false?'':' data-k="'+kind+'|'+c[0]+'"')+'>'+c[1]+(sk===c[0]?(sd==='asc'?' &#9650;':' &#9660;'):'')+'</th>').join('')+'</tr>'+
  (rows.map(fn).join('')||'<tr><td colspan="'+cols.length+'" class="mut">No results</td></tr>')+'</table></div>'}
function qparams(kind){
 const f=S.f[kind],[sk,sd]=S.sort[kind],p={q:S.q,site:S.site,sort:sk,dir:sd};
 if(kind==='assets'){p.type=f.type;p.vendor=f.vendor;p.proto=f.proto;p.zone=f.zone;p.ot=f.ot?1:'';p.risk=f.risk}
 if(kind==='alerts'){p.sev=f.sev;p.status=f.status;p.kind=f.kind}
 if(kind==='flows'){p.proto=f.proto;p.ot=f.ot?1:''}
 return p}
function pager(kind,d){
 const pages=Math.max(1,Math.ceil(d.total/d.limit)),ex=new URLSearchParams(Object.assign({kind:kind},qparams(kind)));
 [...ex.keys()].forEach(k=>{if(ex.get(k)==='')ex.delete(k)});
 return '<div class="pager"><b>'+d.total.toLocaleString()+'</b><span class="mut">results</span><button data-pg="'+kind+'|-1"'+(d.page<=1?' disabled':'')+'>&laquo; Prev</button><span>Page '+d.page+' / '+pages+'</span><button data-pg="'+kind+'|1"'+(d.page>=pages?' disabled':'')+'>Next &raquo;</button><a class="btn" href="/api/export?'+ex.toString()+'">Export CSV</a></div>'}
const HINT={assets:'Search syntax: <code>192.168.10.</code> <code>vendor:siemens</code> <code>type:plc</code> <code>proto:modbus</code> <code>os:windows</code> <code>risk:50</code> <code>zone:192.168.20.0/24</code> <code>-type:switch</code> <code>site:pune</code> &mdash; combine freely.',
 alerts:'Search syntax: <code>ip:192.168.10.99</code> <code>kind:OT_STOP</code> <code>sev:critical</code> <code>proto:s7comm</code> <code>mitre:T0816</code> <code>site:pune</code> <code>-status:closed</code>',
 flows:'Search syntax: <code>ip:192.168.10.11</code> <code>port:502</code> <code>proto:modbus</code> <code>func:"Write Single Register"</code> <code>site:pune</code>'};

// ------------------------------------------------------------ views
const VIEW={},AFTER={};
VIEW.dashboard=async()=>{
 const d=await api('/api/overview',{site:S.site}),t=d.totals;
 const off=d.sites.filter(s=>(!S.site||String(s.id)===String(S.site))&&s.status!=='online');
 let h='';
 if(!d.sites.length)h+='<div class="warn">No sites yet. Open <b>Sites &amp; sensors</b> to create a site and get the token for its sensor.</div>';
 if(off.length)h+='<div class="warn"><b>'+off.length+' sensor(s) not reporting:</b> '+off.map(s=>esc(s.name)+' ('+(s.status==='never'?'never connected':'last seen '+ago(s.age))+')').join(', ')+'</div>';
 h+='<div class="tiles">'+[['Sites online',t.online+' / '+t.sites,''],['Assets',t.assets.toLocaleString(),''],['OT assets',t.ot_assets.toLocaleString(),'ot'],['Communications',t.flows.toLocaleString(),''],['New critical',t.critical,t.critical?'bad':''],['New high',t.high,t.high?'bad':''],['New alerts',t.new_alerts,'']].map(x=>'<div class="tile"><small>'+x[0]+'</small><b style="'+(x[2]==='ot'?'color:var(--ot)':x[2]==='bad'?'color:var(--critical)':'')+'">'+x[1]+'</b></div>').join('')+'</div>';
 h+='<div class="sites">'+d.sites.filter(s=>!S.site||String(s.id)===String(S.site)).map(s=>'<div class="site" data-site="'+s.id+'"><h4><span class="dot '+s.status+'"></span>'+esc(s.name)+'</h4><div class="row"><span>Assets</span><span>'+s.assets+' ('+s.ot_assets+' OT)</span></div><div class="row"><span>New alerts</span><span>'+(s.critical?'<b style="color:var(--critical)">'+s.critical+' crit</b> ':'')+(s.high?'<b style="color:var(--high)">'+s.high+' high</b> ':'')+s.new_alerts+'</span></div><div class="row"><span>Sensor</span><span>'+(s.status==='never'?'never connected':s.status==='online'?'online &middot; '+ago(s.age):'<b style="color:var(--bad)">offline</b> &middot; '+ago(s.age))+'</span></div></div>').join('')+'</div>';
 const mx=Math.max(1,...d.protocols.map(p=>p.n)),tm=Math.max(1,...d.device_types.map(p=>p.n)),vm=Math.max(1,...d.vendors.map(p=>p.n));
 const bars=(l,m,c)=>l.map(p=>'<tr><td>'+(c?'<i class="dot" style="background:'+col(p.k)+'"></i>':'')+esc(p.k)+'</td><td style="width:45%"><div class="bar"><i style="width:'+Math.max(3,100*p.n/m)+'%"></i></div></td><td>'+p.n+'</td></tr>').join('');
 h+='<div class="grid2"><div class="card"><h2>Newest high-severity alerts</h2><table>'+(d.recent_alerts.map(a=>'<tr><td>'+sevb(a.severity)+'</td><td>'+esc(a.title)+'<br><span class="mut">'+esc(a.site)+' &middot; '+esc(a.src)+' &rarr; '+esc(a.dst)+'</span></td><td class="mut">'+esc(a.last_seen)+'</td></tr>').join('')||'<tr><td class="mut">No new alerts</td></tr>')+'</table></div>'+
 '<div class="card"><h2>Highest-risk assets</h2><table>'+(d.risky_assets.map(a=>'<tr class="row" data-asset="'+a.site_id+'|'+esc(a.id)+'"><td>'+esc(a.ip||a.mac)+'</td><td>'+esc(a.site)+'</td><td>'+esc(a.device_type)+'</td><td><div class="bar"><i style="width:'+a.risk+'%;background:var(--high)"></i></div></td><td>'+a.risk+'</td></tr>').join('')||'<tr><td class="mut">None</td></tr>')+'</table></div>'+
 '<div class="card"><h2>Protocols (assets using)</h2><table>'+bars(d.protocols,mx)+'</table></div><div class="card"><h2>Device types</h2><table>'+bars(d.device_types,tm,true)+'</table></div><div class="card"><h2>Top vendors</h2><table>'+bars(d.vendors,vm)+'</table></div></div>';
 return h};

VIEW.assets=async()=>{
 const f=S.f.assets,[d,fc]=await Promise.all([api('/api/assets',Object.assign(qparams('assets'),{page:S.page.assets})),api('/api/facets',{site:S.site})]);
 const bar='<div class="toolbar"><select data-f="assets.type">'+opts(fc.types,f.type,'All device types')+'</select><select data-f="assets.vendor">'+opts(fc.vendors,f.vendor,'All vendors')+'</select><select data-f="assets.proto">'+opts(fc.protocols,f.proto,'All protocols')+'</select><select data-f="assets.zone">'+opts(fc.zones,f.zone,'All zones')+'</select><select data-f="assets.risk"><option value="">Any risk</option>'+[25,50,75].map(r=>'<option value="'+r+'"'+(String(f.risk)===String(r)?' selected':'')+'>Risk &ge; '+r+'</option>').join('')+'</select><label><input type="checkbox" data-f="assets.ot"'+(f.ot?' checked':'')+'> OT only</label><button data-clear="assets">Clear filters</button></div><div class="hint">'+HINT.assets+'</div>';
 return bar+pager('assets',d)+table('assets',[['site','Site'],['ip','IP'],['mac','MAC'],['vendor','Vendor'],['type','Device type'],['model','Model / firmware'],['proto','Protocols'],['zone','Zone'],['risk','Risk'],['last_seen','Last seen']],d.rows,a=>
  '<tr class="row" data-asset="'+a.site_id+'|'+esc(a.id)+'"><td>'+esc(a.site)+'</td><td>'+esc(a.ip||'-')+'</td><td>'+esc(a.mac||'-')+'</td><td>'+esc(a.vendor||'-')+'</td><td><i class="dot" style="background:'+col(a.device_type)+'"></i>'+esc(a.device_type)+'</td><td>'+esc((a.model||'')+(a.firmware?' fw '+a.firmware:''))+(a.hostnames?'<br><span class="mut">'+esc(a.hostnames)+'</span>':'')+'</td><td>'+badges((a.protocols||'').split(',').filter(Boolean).slice(0,5))+'</td><td>'+esc(a.zone||'')+'</td><td><div class="bar"><i style="width:'+a.risk+'%;background:var(--high)"></i></div></td><td>'+esc(a.last_seen||'')+'</td></tr>')};

VIEW.alerts=async()=>{
 const f=S.f.alerts,[d,fc]=await Promise.all([api('/api/alerts',Object.assign(qparams('alerts'),{page:S.page.alerts})),api('/api/facets',{site:S.site})]);
 const bulk=canAck()?'<span class="mut">'+S.sel.size+' selected</span><button data-bulk="ack"'+(S.sel.size?'':' disabled')+'>Acknowledge</button><button data-bulk="closed"'+(S.sel.size?'':' disabled')+'>Close</button><button data-bulk="new"'+(S.sel.size?'':' disabled')+'>Reopen</button>':'';
 const bar='<div class="toolbar"><select data-f="alerts.status"><option value="">Any status</option>'+['new','ack','closed'].map(x=>'<option'+(f.status===x?' selected':'')+'>'+x+'</option>').join('')+'</select><select data-f="alerts.sev"><option value="">Any severity</option>'+['critical','high','medium','low','info'].map(x=>'<option'+(f.sev===x?' selected':'')+'>'+x+'</option>').join('')+'</select><select data-f="alerts.kind">'+opts(fc.alert_kinds,f.kind,'All types')+'</select><button data-clear="alerts">Clear filters</button><span style="flex:1"></span>'+bulk+'</div><div class="hint">'+HINT.alerts+'</div>';
 const cols=(canAck()?[['sel','<input type="checkbox" data-selall="1">',false]]:[]).concat([['sev','Severity'],['site','Site'],['kind','Type'],['title','Description'],['src','Source'],['dst','Target'],['proto','Protocol'],['count','Count'],['last_seen','Last seen'],['mitre','ATT&amp;CK ICS'],['status','Status']]);
 return bar+pager('alerts',d)+table('alerts',cols,d.rows,a=>{const k=a.site_id+'|'+a.uid;
  return '<tr class="row">'+(canAck()?'<td><input type="checkbox" data-sel="'+esc(k)+'"'+(S.sel.has(k)?' checked':'')+'></td>':'')+'<td>'+sevb(a.severity)+'</td><td>'+esc(a.site)+'</td><td>'+esc(a.kind)+'</td><td>'+esc(a.title)+(a.detail?'<br><span class="mut">'+esc(a.detail)+'</span>':'')+(a.note?'<br><span class="mut">Note: '+esc(a.note)+' ('+esc(a.handled_by||'')+')</span>':'')+'</td><td><span class="lnk" data-q="ip:'+esc(a.src)+'">'+esc(a.src)+'</span></td><td><span class="lnk" data-q="ip:'+esc(a.dst)+'">'+esc(a.dst)+'</span></td><td>'+esc(a.proto)+'</td><td>'+a.count+'</td><td>'+esc(a.last_seen)+'</td><td>'+esc(a.mitre)+'</td><td><span class="st '+a.status+'">'+a.status+'</span></td></tr>'})};

VIEW.flows=async()=>{
 const f=S.f.flows,[d,fc]=await Promise.all([api('/api/flows',Object.assign(qparams('flows'),{page:S.page.flows})),api('/api/facets',{site:S.site})]);
 const bar='<div class="toolbar"><select data-f="flows.proto">'+opts(fc.flow_protocols,f.proto,'All protocols')+'</select><label><input type="checkbox" data-f="flows.ot"'+(f.ot?' checked':'')+'> OT only</label><button data-clear="flows">Clear filters</button></div><div class="hint">'+HINT.flows+'</div>';
 return bar+pager('flows',d)+table('flows',[['site','Site'],['client','Client'],['server','Server'],['proto','Protocol'],['port','Port'],['packets','Packets'],['bytes','Bytes'],['fn','Functions seen',false],['last_seen','Last seen']],d.rows,x=>
  '<tr class="row"><td>'+esc(x.site)+'</td><td><span class="lnk" data-q="ip:'+esc(x.client)+'">'+esc(x.client)+'</span></td><td><span class="lnk" data-q="ip:'+esc(x.server)+'">'+esc(x.server)+'</span></td><td>'+esc(x.proto)+(x.ot?' <span class="badge ot">OT</span>':'')+'</td><td>'+esc(x.l4)+'/'+x.port+'</td><td>'+x.packets.toLocaleString()+'</td><td>'+fb(x.bytes)+'</td><td>'+Object.entries(x.funcs).slice(0,5).map(([k,v])=>'<span class="badge">'+esc(k)+' x'+v+'</span>').join('')+'</td><td>'+esc(x.last_seen)+'</td></tr>')};

let MAPD=null,NODES=[];
VIEW.map=async()=>{
 if(!S.sites.length)return '<div class="card mut">No sites yet.</div>';
 const sid=S.site||S.mapSite||S.sites[0].id;S.mapSite=sid;
 MAPD=await api('/api/map',{site:sid});
 const leg=Object.keys(TYPECOL).map(k=>'<span><i style="background:'+TYPECOL[k]+'"></i>'+k+'</span>').join('');
 return '<div class="toolbar"><label>Site <select id="mapsite">'+S.sites.map(s=>'<option value="'+s.id+'"'+(String(s.id)===String(sid)?' selected':'')+'>'+esc(s.name)+'</option>').join('')+'</select></label><span class="mut">'+MAPD.assets.length+' assets, grouped by zone. Orange lines = OT traffic. Red ring = elevated risk. Click a node for details.</span></div><div class="legend card">'+leg+'</div><canvas id="map"></canvas>'};
AFTER.map=()=>{
 $('mapsite').onchange=e=>{S.mapSite=e.target.value;if(S.site){S.site=e.target.value;$('siteSel').value=S.site}render()};
 const c=$('map'),ctx=c.getContext('2d'),dpr=window.devicePixelRatio||1,W=c.clientWidth,H=c.clientHeight;c.width=W*dpr;c.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);
 const zones={};MAPD.assets.forEach(a=>{(zones[a.zone||'?']=zones[a.zone||'?']||[]).push(a)});
 const zk=Object.keys(zones).sort(),cols=Math.max(1,Math.ceil(Math.sqrt(zk.length*W/H))),rows=Math.ceil(zk.length/cols),pos={},byip={};NODES=[];
 zk.forEach((z,i)=>{const cx=(i%cols+.5)*W/cols,cy=(Math.floor(i/cols)+.5)*H/rows,arr=zones[z],R=Math.min(W/cols,H/rows)/2-28,r=Math.max(20,Math.min(R,14+arr.length*8));
  ctx.strokeStyle='#263142';ctx.setLineDash([4,4]);ctx.beginPath();ctx.arc(cx,cy,r+16,0,7);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#8996a8';ctx.font='11px system-ui';ctx.textAlign='center';ctx.fillText(z,cx,cy-r-22);
  arr.forEach((a,j)=>{const ang=2*Math.PI*j/arr.length-Math.PI/2,x=arr.length===1?cx:cx+r*Math.cos(ang),y=arr.length===1?cy:cy+r*Math.sin(ang);pos[a.id]=[x,y];if(a.ip)byip[a.ip]=a.id;if(a.mac)byip[a.mac]=a.id;NODES.push({a:a,x:x,y:y})})});
 MAPD.flows.forEach(f=>{const p=pos[byip[f.client]],q=pos[byip[f.server]];if(p&&q&&p!==q){ctx.strokeStyle=f.ot?'rgba(255,159,67,.6)':'rgba(130,150,180,.2)';ctx.lineWidth=f.ot?1.4:1;ctx.beginPath();ctx.moveTo(p[0],p[1]);ctx.lineTo(q[0],q[1]);ctx.stroke()}});
 NODES.forEach(n=>{ctx.beginPath();ctx.arc(n.x,n.y,n.a.ot?9:7,0,7);ctx.fillStyle=col(n.a.device_type);ctx.fill();if(n.a.risk>=25){ctx.strokeStyle='#ff4d4f';ctx.lineWidth=2.5;ctx.stroke()}ctx.fillStyle='#c9d6e6';ctx.font='10px system-ui';ctx.textAlign='center';ctx.fillText((n.a.ip||n.a.mac||'').split('.').slice(-1)[0].slice(0,12),n.x,n.y+21)});
 const hit=e=>{const r=c.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;return NODES.find(n=>Math.hypot(n.x-x,n.y-y)<12)};
 c.onmousemove=e=>{const n=hit(e),t=$('tip');if(n){t.style.display='block';t.style.left=e.clientX+12+'px';t.style.top=e.clientY+12+'px';t.textContent=(n.a.ip||n.a.mac)+' - '+n.a.device_type}else t.style.display='none'};
 c.onclick=e=>{const n=hit(e);if(n)openAsset(S.mapSite,n.a.id)}};

VIEW.sites=async()=>{
 await refreshSites();
 const add=isAdmin()?'<div class="card"><h2>Add a site</h2><div class="toolbar"><input id="newsite" placeholder="Site name, e.g. Plant-Pune" size="30"><button class="pri" data-act="addsite">Create site &amp; get token</button></div><div class="mut">Each site gets its own token. Install the sensor appliance there with that token; it pushes to this server.</div></div>':'';
 let h=add+'<div class="card wrap"><table><tr><th>Status</th><th>Site</th><th>Last seen</th><th>Assets</th><th>OT</th><th>Flows</th><th>New alerts</th><th>Sensor</th>'+(isAdmin()?'<th>Actions</th>':'')+'</tr>'+
 S.sites.map(s=>{const m=s.meta||{};return '<tr class="row"><td><span class="dot '+s.status+'"></span>'+s.status+'</td><td><span class="lnk" data-site="'+s.id+'">'+esc(s.name)+'</span></td><td>'+ago(s.age)+'</td><td>'+s.assets+'</td><td>'+s.ot_assets+'</td><td>'+s.flows+'</td><td>'+s.new_alerts+'</td><td class="mut">'+(m.ui_url?'<a href="'+esc(m.ui_url)+'" target="_blank" rel="noopener noreferrer">Open sensor page &#8599;</a> ('+esc(m.ui_url.replace(/^https?:\/\//,''))+')<br>':'')+(m.hostname?esc(m.hostname)+' &middot; v'+esc(m.version)+' &middot; '+esc(m.iface)+' ('+esc(m.mode)+') &middot; '+m.pps+' pkt/s &middot; '+m.packets.toLocaleString()+' pkts &middot; up '+Math.round(m.uptime_s/60)+' min':'-')+'</td>'+(isAdmin()?'<td><button data-act="rotate" data-id="'+s.id+'">New token</button> <button class="danger" data-act="delsite" data-id="'+s.id+'" data-name="'+esc(s.name)+'">Delete</button></td>':'')+'</tr>'}).join('')+'</table></div>';
 if(isAdmin()){const au=await api('/api/audit');h+='<div class="card wrap"><h2>Audit log</h2><table>'+au.map(a=>'<tr><td class="mut">'+esc(a.t)+'</td><td>'+esc(a.who)+'</td><td>'+esc(a.action)+'</td><td class="mut">'+esc(a.detail)+'</td></tr>').join('')+'</table></div>'}
 return h};

// ------------------------------------------------------------ interaction
const main=$('main');
main.addEventListener('click',async e=>{
 const t=e.target;let el;
 if(el=t.closest('th[data-k]')){const [k,c]=el.dataset.k.split('|'),s=S.sort[k];S.sort[k]=[c,s[0]===c&&s[1]==='desc'?'asc':'desc'];S.page[k]=1;return render(true)}
 if(el=t.closest('button[data-pg]')){const [k,d]=el.dataset.pg.split('|');S.page[k]=Math.max(1,S.page[k]+Number(d));return render(true)}
 if(el=t.closest('button[data-clear]')){const k=el.dataset.clear;S.f[k]=k==='alerts'?{status:''}:{};S.q='';$('gq').value='';resetPages();return render(true)}
 if(el=t.closest('[data-q]')){S.q=el.dataset.q;$('gq').value=S.q;resetPages();if(!['alerts','flows','assets'].includes(S.tab))S.tab='assets';return render(true)}
 if(el=t.closest('[data-asset]')){if(t.closest('input,a,button'))return;const [s,id]=el.dataset.asset.split('|');return openAsset(s,id)}
 if(el=t.closest('[data-site]')){S.site=el.dataset.site;$('siteSel').value=S.site;if(S.tab==='sites')S.tab='dashboard';return render()}
 if(el=t.closest('button[data-bulk]')){const st=el.dataset.bulk;let note='';if(st!=='new')note=prompt('Note (optional)','')||'';
  const items=[...S.sel].map(k=>{const [s,u]=k.split('|');return {site:Number(s),uid:u}});
  await api('/api/alerts/status',null,{items:items,status:st,note:note});S.sel.clear();return render(true)}
 if(el=t.closest('button[data-act]')){const a=el.dataset.act;
  if(a==='addsite'){const n=$('newsite').value.trim();if(!n)return;try{const r=await api('/api/sites/add',null,{name:n});tokenModal(n,r.token)}catch(x){alert(x.message)}await refreshSites();return render(true)}
  if(a==='rotate'){if(!confirm('Issue a new token? The current sensor stops working until reconfigured.'))return;const r=await api('/api/sites/rotate',null,{id:Number(el.dataset.id)});const s=S.sites.find(x=>String(x.id)===el.dataset.id);return tokenModal(s?s.name:'site',r.token)}
  if(a==='delsite'){if(!confirm('Delete site "'+el.dataset.name+'" and ALL its assets, flows and alerts?'))return;await api('/api/sites/delete',null,{id:Number(el.dataset.id)});S.site='';await refreshSites();return render()}}
});
main.addEventListener('change',e=>{
 const t=e.target;
 if(t.dataset.f){const [k,n]=t.dataset.f.split('.');S.f[k][n]=t.type==='checkbox'?t.checked:t.value;S.page[k]=1;return render(true)}
 if(t.dataset.sel!==undefined){t.checked?S.sel.add(t.dataset.sel):S.sel.delete(t.dataset.sel);return render(true)}
 if(t.dataset.selall){document.querySelectorAll('input[data-sel]').forEach(i=>{if(t.checked)S.sel.add(i.dataset.sel);else S.sel.delete(i.dataset.sel)});return render(true)}});
function showModal(h){$('modal').innerHTML='<div class="overlay"><div class="box">'+h+'<div style="text-align:right;margin-top:10px"><button id="mc">Close</button></div></div></div>';$('mc').onclick=()=>$('modal').innerHTML=''}
function tokenModal(name,tok){
 const url=location.origin;
 showModal('<h3>Sensor token for '+esc(name)+'</h3><p>Shown once. Copy it now.</p><pre>'+esc(tok)+'</pre><p>On the sensor appliance:</p><pre>sudo ./install_sensor.sh --site "'+esc(name)+'" --central '+esc(url)+' --token '+esc(tok)+' --cafile cert.pem</pre><p>When it connects, this console shows the sensor\'s web address (Sites &amp; sensors &rarr; Open sensor page). Sign in there with <b>your console username and password</b>; pick the capture port on its Setup page.</p><p class="mut">Or without the installer:<br><code>OTSENSE_TOKEN='+esc(tok)+' python3 otsense.py sensor --site "'+esc(name)+'" --central '+esc(url)+' -i eth1</code></p>')}
function changePw(){
 showModal('<h3>Change password</h3><input id="po" type="password" placeholder="Current password"><input id="pn" type="password" placeholder="New password (min 10 characters)"><div id="pe" style="color:var(--bad)"></div><button class="pri" id="ps">Change</button>');
 $('ps').onclick=async()=>{try{await api('/api/password',null,{old:$('po').value,new:$('pn').value});$('modal').innerHTML=''}catch(e){$('pe').textContent=e.message}}}
$('drawer').addEventListener('click',e=>{
 const q=e.target.closest('[data-q]');if(q){S.q=q.dataset.q;$('gq').value=S.q;resetPages();$('drawer').classList.remove('open');if(!['alerts','flows','assets'].includes(S.tab))S.tab='assets';render(true)}
 if(e.target.id==='dclose')$('drawer').classList.remove('open')});
async function openAsset(site,id){
 const d=await api('/api/asset',{site:site,id:id}),a=d.asset;
 const kv=[['Site',d.site],['IP',a.ip],['MAC',a.mac],['Vendor',a.vendor],['Device type',a.device_type+(a.subtype?' - '+a.subtype:'')],['Model',a.model],['Firmware',a.firmware],['Serial',a.serial],['Hostnames',(a.hostnames||[]).join(', ')],['OS (guess)',a.os_guess],['Zone / VLAN',a.zone+((a.vlans||[]).length?' / VLAN '+a.vlans.join(','):'')],['Purdue (guess)',a.purdue_guess],['First / last seen',a.first_seen+' / '+a.last_seen],['Traffic',a.tx_packets+' pkts sent, '+a.rx_packets+' received ('+fb(a.tx_bytes+a.rx_bytes)+')'],['Listening ports',(a.listening_ports||[]).join(', ')],['Peers',a.peer_count+': '+(a.peers||[]).slice(0,10).join(', ')],['Flags',(a.flags||[]).join(', ')]];
 Object.keys(a.properties||{}).forEach(k=>kv.push([k,a.properties[k]]));Object.keys(a.tags||{}).forEach(k=>kv.push([k,a.tags[k].join('; ')]));
 let h='<button id="dclose" style="float:right">Close</button><h3>'+esc(a.ip||a.mac)+'</h3><span class="mut">'+esc(a.device_type)+'</span> '+(a.risk?'<span class="badge" style="background:#5a2226">risk '+a.risk+'</span>':'')+
 '<div class="kv">'+kv.filter(x=>x[1]).map(x=>'<div>'+esc(x[0])+'</div><div>'+esc(x[1])+'</div>').join('')+'</div>';
 if(d.other_sites.length)h+='<div class="warn">Same MAC also seen at: '+d.other_sites.map(o=>esc(o.site)+' ('+esc(o.ip||'-')+', '+esc(o.last_seen)+')').join('; ')+'</div>';
 h+='<h2>Serves</h2>'+badges(Object.keys(a.serves||{}),a.ot_protocols)+'<h2 style="margin-top:12px">Initiates</h2>'+badges(Object.keys(a.uses||{}),a.ot_protocols);
 if(d.alerts.length)h+='<h2 style="margin-top:14px">Alerts ('+d.alerts.length+')</h2><table>'+d.alerts.map(x=>'<tr><td>'+sevb(x.severity)+'</td><td>'+esc(x.title)+'<br><span class="mut">'+esc(x.src)+' &rarr; '+esc(x.dst)+' &middot; '+esc(x.last_seen)+'</span></td><td><span class="st '+x.status+'">'+x.status+'</span></td></tr>').join('')+'</table>';
 if(d.flows.length)h+='<h2 style="margin-top:14px">Communications ('+d.flows.length+')</h2><table>'+d.flows.map(x=>'<tr><td><span class="lnk" data-q="ip:'+esc(x.client)+'">'+esc(x.client)+'</span> &rarr; <span class="lnk" data-q="ip:'+esc(x.server)+'">'+esc(x.server)+'</span></td><td>'+esc(x.proto)+(x.ot?' <span class="badge ot">OT</span>':'')+'</td><td>'+x.packets+' pkts</td></tr>').join('')+'</table>';
 $('drawer').innerHTML=h;$('drawer').classList.add('open')}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('drawer').classList.remove('open');$('modal').innerHTML=''}});
setInterval(()=>{if($('login').style.display==='none'&&S.me&&(S.tab==='dashboard'||S.tab==='sites')&&!$('modal').innerHTML)render(true)},20000);
boot();
</script></body></html>'''


# ----------------------------------------------------------------------------------------------
# HTTP server
# ----------------------------------------------------------------------------------------------

APP = None


class HttpErr(Exception):
    def __init__(self, code, msg):
        Exception.__init__(self, msg)
        self.code, self.msg = code, msg


def gunzip_limited(data, limit):
    d = zlib.decompressobj(16 + zlib.MAX_WBITS)
    out = d.decompress(data, limit + 1)
    if len(out) > limit or d.unconsumed_tail:
        raise HttpErr(413, "payload too large")
    return out


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 128
    ctx = None

    def get_request(self):
        s, addr = self.socket.accept()
        if self.ctx:
            s = self.ctx.wrap_socket(s, server_side=True, do_handshake_on_connect=False)
        return s, addr

    def handle_error(self, request, client_address):
        e = sys.exc_info()[1]
        if isinstance(e, (ssl.SSLError, ConnectionError, socket.timeout, TimeoutError, BrokenPipeError, OSError)):
            return
        traceback.print_exc()


class Handler(BaseHTTPRequestHandler):
    server_version = "OTSenseCentral"
    protocol_version = "HTTP/1.1"
    timeout = 60

    def setup(self):
        if isinstance(self.request, ssl.SSLSocket):
            self.request.settimeout(20)
            self.request.do_handshake()
        BaseHTTPRequestHandler.setup(self)

    def log_message(self, *a):
        pass

    # ---- plumbing
    def _send(self, code, body, ctype, headers=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; "
                                                    "style-src 'self' 'unsafe-inline'; img-src 'self' data:")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def j(self, obj, code=200, headers=None):
        self._send(code, json.dumps(obj).encode("utf-8"), "application/json", headers)

    def err(self, code, msg):
        self.j({"error": msg}, code)

    def user(self):
        m = re.search(r"(?:^|;\s*)otsc=([^;]+)", self.headers.get("Cookie", ""))
        return APP.read_cookie(m.group(1)) if m else None

    def read_body(self, limit):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise HttpErr(400, "bad Content-Length")
        if n < 0 or n > limit:
            raise HttpErr(413, "body too large")
        return self.rfile.read(n)

    def json_body(self):
        try:
            d = json.loads(self.read_body(1024 * 1024) or b"{}")
        except ValueError:
            raise HttpErr(400, "invalid JSON")
        if not isinstance(d, dict):
            raise HttpErr(400, "JSON object expected")
        return d

    # ---- GET
    def do_GET(self):
        u = urlparse(self.path)
        path, p = u.path, {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if path in ("/", "/index.html"):
                return self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
            if path == "/health":
                return self.j({"ok": True, "version": VERSION})
            me = self.user()
            if path == "/api/me":
                return self.j(me or {"anon": True})
            if not me:
                return self.err(401, "login required")
            if path == "/api/sites":
                return self.j(APP.sites())
            if path == "/api/overview":
                return self.j(APP.overview(p))
            if path == "/api/facets":
                return self.j(APP.facets(p))
            if path == "/api/counts":
                return self.j(APP.counts(p))
            if path in ("/api/assets", "/api/alerts", "/api/flows"):
                kind = path.split("/")[-1]
                d = APP.list(kind, p)
                if kind == "flows":
                    for r in d["rows"]:
                        try:
                            r["funcs"] = json.loads(r["funcs"] or "{}")
                        except ValueError:
                            r["funcs"] = {}
                return self.j(d)
            if path == "/api/asset":
                d = APP.asset_detail(int(p.get("site", 0)), p.get("id", ""))
                return self.j(d) if d else self.err(404, "asset not found")
            if path == "/api/map":
                return self.j(APP.topo(int(p.get("site", 0))))
            if path == "/api/export":
                kind = p.get("kind")
                if kind not in ("assets", "alerts", "flows"):
                    return self.err(400, "kind must be assets, alerts or flows")
                body = APP.export(kind, p).encode("utf-8")
                return self._send(200, body, "text/csv; charset=utf-8",
                                  {"Content-Disposition": 'attachment; filename="otsense_%s.csv"' % kind})
            if path == "/api/audit":
                if me["role"] != "admin":
                    return self.err(403, "admin only")
                return self.j([{"t": iso(r["ts"]), "who": r["who"], "action": r["action"], "detail": r["detail"]}
                               for r in APP.db.q("SELECT * FROM audit ORDER BY ts DESC LIMIT 60")])
            return self.err(404, "not found")
        except HttpErr as e:
            return self.err(e.code, e.msg)
        except (ValueError, TypeError) as e:
            return self.err(400, "bad request: %s" % e)
        except Exception:
            traceback.print_exc()
            return self.err(500, "internal error")

    # ---- POST
    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/ingest":
                return self._ingest()
            if path == "/api/sensor-auth":
                return self._sensor_auth()
            o = self.headers.get("Origin")
            if o and urlparse(o).netloc != self.headers.get("Host"):
                return self.err(403, "cross-origin request refused")
            if path == "/api/login":
                return self._login()
            me = self.user()
            if not me:
                return self.err(401, "login required")
            b = self.json_body()
            if path == "/api/logout":
                return self.j({"ok": True}, headers={"Set-Cookie": "otsc=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict"})
            if path == "/api/password":
                u = APP.db.one("SELECT pw FROM users WHERE name=?", (me["user"],))
                if not check_pw(str(b.get("old", "")), u["pw"]):
                    return self.err(400, "current password is wrong")
                if len(str(b.get("new", ""))) < 10:
                    return self.err(400, "new password must be at least 10 characters")
                APP.db.x("UPDATE users SET pw=? WHERE name=?", (hash_pw(b["new"]), me["user"]))
                APP.audit(me["user"], "password.change")
                return self.j({"ok": True})
            if path == "/api/alerts/status":
                if me["role"] not in ("admin", "analyst"):
                    return self.err(403, "your role cannot change alerts")
                st = b.get("status")
                if st not in ("new", "ack", "closed"):
                    return self.err(400, "bad status")
                items = b.get("items") or []
                note = str(b.get("note") or "")[:300]
                n = 0
                with APP.db.lock:
                    APP.db.c.execute("BEGIN")
                    for it in items[:5000]:
                        cur = APP.db.c.execute(
                            "UPDATE alerts SET status=?, note=CASE WHEN ?<>'' THEN ? ELSE note END, handled_by=?, handled_at=? "
                            "WHERE site_id=? AND uid=?", (st, note, note, me["user"], time.time(), int(it["site"]), str(it["uid"])))
                        n += cur.rowcount
                    APP.db.c.execute("COMMIT")
                APP.audit(me["user"], "alerts." + st, "%d alert(s) %s" % (n, note))
                return self.j({"ok": True, "updated": n})
            if path.startswith("/api/sites/"):
                if me["role"] != "admin":
                    return self.err(403, "admin only")
                if path == "/api/sites/add":
                    try:
                        return self.j({"ok": True, "token": APP.add_site(str(b.get("name", "")), me["user"])})
                    except ValueError as e:
                        return self.err(400, str(e))
                sid = int(b.get("id", 0))
                s = APP.db.one("SELECT name FROM sites WHERE id=?", (sid,))
                if not s:
                    return self.err(404, "no such site")
                if path == "/api/sites/rotate":
                    tok = APP.new_token()
                    APP.db.x("UPDATE sites SET token_hash=? WHERE id=?", (sha(tok), sid))
                    APP.audit(me["user"], "site.token", s["name"])
                    return self.j({"ok": True, "token": tok})
                if path == "/api/sites/delete":
                    with APP.db.lock:
                        APP.db.c.execute("BEGIN")
                        for t in ("assets", "flows", "alerts"):
                            APP.db.c.execute("DELETE FROM %s WHERE site_id=?" % t, (sid,))
                        APP.db.c.execute("DELETE FROM sites WHERE id=?", (sid,))
                        APP.db.c.execute("COMMIT")
                    APP.audit(me["user"], "site.delete", s["name"])
                    return self.j({"ok": True})
            return self.err(404, "not found")
        except HttpErr as e:
            return self.err(e.code, e.msg)
        except (ValueError, TypeError, KeyError) as e:
            return self.err(400, "bad request: %s" % e)
        except Exception:
            traceback.print_exc()
            return self.err(500, "internal error")

    def _login(self):
        ip, now = self.client_address[0], time.time()
        cnt, first = APP.fails.get(ip, (0, now))
        if now - first > 300:
            cnt, first = 0, now
        if cnt >= 10:
            return self.err(429, "too many failed logins - wait a few minutes")
        b = self.json_body()
        u = APP.db.one("SELECT * FROM users WHERE name=?", (str(b.get("user", "")),))
        if not u or not check_pw(str(b.get("password", "")), u["pw"]):
            APP.fails[ip] = (cnt + 1, first)
            APP.audit(str(b.get("user", ""))[:40], "login.fail", ip)
            time.sleep(0.8)
            return self.err(401, "wrong username or password")
        APP.fails.pop(ip, None)
        APP.audit(u["name"], "login", ip)
        ck = "otsc=%s; Path=/; Max-Age=%d; HttpOnly; SameSite=Strict%s" % (APP.cookie(u["name"], u["role"]), 12 * 3600, "; Secure" if APP.tls else "")
        return self.j({"ok": True, "user": u["name"], "role": u["role"]}, headers={"Set-Cookie": ck})

    def _sensor_auth(self):
        """A sensor asks: is this console user/password valid? Authenticated by the site token, so only enrolled sensors can ask."""
        auth = self.headers.get("Authorization", "")
        site = APP.site_by_token(auth[7:].strip()) if auth.lower().startswith("bearer ") else None
        if not site:
            time.sleep(0.5)
            return self.err(401, "invalid site token")
        ip, now = self.client_address[0], time.time()
        key = "s:" + ip
        cnt, first = APP.fails.get(key, (0, now))
        if now - first > 300:
            cnt, first = 0, now
        if cnt >= 20:
            return self.err(429, "too many failed logins - wait a few minutes")
        b = self.json_body()
        name = str(b.get("user", ""))[:60]
        u = APP.db.one("SELECT * FROM users WHERE name=?", (name,))
        if not u or not check_pw(str(b.get("password", "")), u["pw"]):
            APP.fails[key] = (cnt + 1, first)
            APP.audit(name[:40], "sensor.login.fail", "%s via %s" % (site["name"], ip))
            time.sleep(0.8)
            return self.err(401, "wrong username or password")
        APP.fails.pop(key, None)
        APP.audit(u["name"], "sensor.login", "%s via %s" % (site["name"], ip))
        return self.j({"ok": True, "user": u["name"], "role": u["role"], "site": site["name"]})

    def _ingest(self):
        auth = self.headers.get("Authorization", "")
        site = APP.site_by_token(auth[7:].strip()) if auth.lower().startswith("bearer ") else None
        if not site:
            time.sleep(0.5)
            return self.err(401, "invalid site token")
        raw = self.read_body(MAX_BODY)
        if self.headers.get("Content-Encoding", "").lower() == "gzip":
            raw = gunzip_limited(raw, MAX_JSON)
        try:
            body = json.loads(raw)
        except ValueError:
            return self.err(400, "invalid JSON")
        if not isinstance(body, dict):
            return self.err(400, "JSON object expected")
        n = APP.ingest(site, body)
        return self.j({"ok": True, "site": site["name"], "accepted": n})


# ----------------------------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------------------------


def make_selfcert(out, cn, sans):
    os.makedirs(out, exist_ok=True)
    names = ["localhost", "127.0.0.1"] + list(sans)
    san = ",".join(("IP:" + n if re.match(r"^[0-9.]+$", n) or ":" in n else "DNS:" + n) for n in dict.fromkeys(names))
    crt, key = os.path.join(out, "cert.pem"), os.path.join(out, "key.pem")
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", key, "-out", crt, "-days", "1825",
                    "-subj", "/CN=" + cn, "-addext", "subjectAltName=" + san], check=True, capture_output=True)
    os.chmod(key, 0o600)
    return crt, key, san


def main(argv=None):
    ap = argparse.ArgumentParser(prog="otsense_central", description="OTSense Central - multi-site database + console")
    ap.add_argument("--db", default=os.environ.get("OTSENSE_DB", "otsense_central.db"), help="SQLite database file")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("serve", help="run the central server + web console")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=8443)
    p.add_argument("--cert", help="TLS certificate (PEM). Strongly recommended")
    p.add_argument("--key", help="TLS private key (PEM)")
    p.add_argument("--admin-password", default=os.environ.get("OTSENSE_ADMIN_PASSWORD"), help="password for the first 'admin' user")
    p.add_argument("--retention-days", type=int, default=90, help="delete flows and closed alerts older than this (0 = keep)")
    p = sub.add_parser("add-site", help="create a site and print its sensor token")
    p.add_argument("name")
    sub.add_parser("list-sites")
    p = sub.add_parser("user", help="manage console users")
    us = p.add_subparsers(dest="ucmd")
    q = us.add_parser("add")
    q.add_argument("name")
    q.add_argument("--role", choices=ROLES, default="viewer")
    q.add_argument("--password")
    us.add_parser("list")
    q = us.add_parser("del")
    q.add_argument("name")
    q = us.add_parser("passwd")
    q.add_argument("name")
    q.add_argument("--password")
    p = sub.add_parser("selfcert", help="create a self-signed TLS certificate (lab / small deployments)")
    p.add_argument("--out", default="certs")
    p.add_argument("--cn", default="otsense-central")
    p.add_argument("--san", action="append", default=[], help="extra DNS name or IP in the certificate (repeatable)")
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--db" in argv:  # allow --db anywhere on the command line
        i = argv.index("--db")
        argv = argv[i:i + 2] + argv[:i] + argv[i + 2:]
    a = ap.parse_args(argv)

    if a.cmd == "selfcert":
        try:
            crt, key, san = make_selfcert(a.out, a.cn, a.san)
        except (OSError, subprocess.CalledProcessError) as e:
            print("openssl failed: %s" % e, file=sys.stderr)
            return 2
        print("Created %s and %s\nCertificate names: %s\nCopy cert.pem to each sensor and pass --cafile cert.pem (the sensor connects "
              "using one of these names/IPs)." % (crt, key, san))
        return 0

    global APP
    APP = App(a.db, getattr(a, "retention_days", 90))
    if a.cmd == "add-site":
        try:
            tok = APP.add_site(a.name)
        except ValueError as e:
            print(e, file=sys.stderr)
            return 1
        print("Site '%s' created.\nSensor token (shown once): %s" % (a.name, tok))
        return 0
    if a.cmd == "list-sites":
        for s in APP.sites():
            print("%-30s %-8s assets=%-5d new_alerts=%-4d last_seen=%s" % (s["name"], s["status"], s["assets"], s["new_alerts"], iso(s["last_seen"])))
        return 0
    if a.cmd == "user":
        if a.ucmd == "list":
            for u in APP.db.q("SELECT name, role FROM users ORDER BY name"):
                print("%-20s %s" % (u["name"], u["role"]))
            return 0
        if a.ucmd == "del":
            APP.db.x("DELETE FROM users WHERE name=?", (a.name,))
            return 0
        if a.ucmd in ("add", "passwd"):
            pw = a.password or getpass.getpass("Password for %s: " % a.name)
            if len(pw) < 10:
                print("password must be at least 10 characters", file=sys.stderr)
                return 1
            if a.ucmd == "add":
                APP.add_user(a.name, pw, a.role)
            else:
                APP.db.x("UPDATE users SET pw=? WHERE name=?", (hash_pw(pw), a.name))
            print("ok")
            return 0
        ap.parse_args(["user", "-h"])
    if a.cmd == "serve":
        if not APP.db.one("SELECT 1 x FROM users LIMIT 1"):
            pw = a.admin_password or secrets.token_urlsafe(12)
            APP.add_user("admin", pw, "admin")
            print("=" * 60 + "\nFirst run: created console user 'admin'\n  password: %s\nChange it after logging in "
                  "(top right -> password).\n" % pw + "=" * 60)
        srv = Server((a.host, a.port), Handler)
        scheme = "http"
        if a.cert and a.key:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.minimum_version = ssl.TLSVersion.TLSv1_2
            ctx.load_cert_chain(a.cert, a.key)
            srv.ctx, APP.tls, scheme = ctx, True, "https"
        else:
            print("WARNING: running WITHOUT TLS - passwords and sensor tokens cross the network in clear text.\n"
                  "         Create a cert with:  python3 otsense_central.py selfcert --san <this-server-ip>")

        def janitor():
            while True:
                try:
                    APP.purge()
                except Exception:
                    traceback.print_exc()
                time.sleep(3600)

        threading.Thread(target=janitor, daemon=True).start()
        print("OTSense Central %s listening on %s://%s:%d   db=%s   retention=%s" % (
            VERSION, scheme, a.host, a.port, a.db, ("%dd" % a.retention_days) if a.retention_days else "off"), flush=True)
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            pass
        srv.server_close()
        return 0
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
