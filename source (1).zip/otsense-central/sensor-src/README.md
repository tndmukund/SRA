# OTSense 1.3 - passive OT/IT asset discovery, DPI and detection (sensor + central console)

```
 Site A                      Site B                       Central (one server / VM)
 SPAN/TAP --> [sensor]       SPAN/TAP --> [sensor]        +---------------------------------+
              capture NIC (no IP)                         |  OTSense Central                |
              mgmt NIC --- HTTPS push (token) ----------> |  SQLite DB + web console        |
                                                          |  search / filter / alerts / map |
 Analyst browser ---------------- HTTPS ----------------> +---------------------------------+
```

Sensors only listen (passive) and push outbound. Nothing is sent to the PLCs.

## 1. Try it in 5 minutes (no hardware, no pcap needed)

```bash
python3 otsense_central.py selfcert --san 127.0.0.1 --out certs
python3 otsense_central.py serve --cert certs/cert.pem --key certs/key.pem      # prints admin password
python3 otsense_central.py add-site "Plant-Pune"                                # prints a token
python3 otsense.py sample sample_ot.pcap                                        # synthetic OT traffic + attacks
OTSENSE_TOKEN=<token> python3 otsense.py sensor --site Plant-Pune \
    --central https://127.0.0.1:8443 --cafile certs/cert.pem --pcap sample_ot.pcap
```
Open https://127.0.0.1:8443 and sign in as `admin`.

## 2. Production

**Central** (one Linux server/VM, Python 3.8+, openssl):
`sudo ./deploy/install_central.sh --name <ip-or-dns>` - creates the service, TLS cert, DB and admin login.

**Each site** (any Linux box/VM/Raspberry Pi with 2 network ports; `apt install python3 openssl iproute2 ethtool`):
1. Plug the **management port** into the normal network and the **capture port** into the switch's SPAN/mirror port (or a TAP). The capture port needs no IP address. VMware: set that port group's promiscuous mode to Accept.
2. In the central console: *Sites & sensors* -> create site -> copy the token.
3. `sudo ./deploy/install_sensor.sh` - installs the sensor and its web page, prints the web address and a one-time setup password.
4. Open `https://<sensor-ip>:8080` (accept the self-signed certificate warning), sign in with the setup password (leave username empty) and use the **Setup** page:
   - give one port the **SPAN / capture** role and one the **Management** role (see 2a), then press **Test the SPAN port** - green means mirrored traffic from other devices is arriving, amber means only broadcast/own traffic (the SPAN is probably not configured), red means no packets or no link;
   - enter the central address and the site token (paste central's `cert.pem` if it is self-signed) and press **Test connection**;
   - press **Save & start**.
   The **Status**, **Live traffic**, **Devices found** and **Help** tabs then show what the sensor sees. No command line or config file is needed after step 3.

**Logins are managed by central.** Once the sensor has joined central, the sensor page asks for a *central console* username and password (checked live against central; admin = can change settings, analyst/viewer = read-only). Add or remove people only in the console (`user add ...`). Central's *Sites & sensors* page shows each sensor's web address with an **Open sensor page** link, so nobody has to look up the IP. If central is unreachable, people who signed in before can still sign in (cached on the sensor), and the one-time setup password works as a fallback. Every sensor login is in central's audit log.

The SPAN/mirror itself is configured on the switch (the sensor page only verifies it). Example Cisco: `monitor session 1 source vlan 10` / `monitor session 1 destination interface Gi1/0/24`.

Optional one-line install with the settings pre-filled:
`sudo ./deploy/install_sensor.sh --site "Plant-Pune" --central https://<central>:8443 --token <token> --iface <span-nic> --mgmt-iface <mgmt-nic> --cafile cert.pem`
Add `--ui-cert web.crt --ui-key web.key` to install your own HTTPS certificate for the sensor page at the same time (key passphrase, if any: environment variable `OTSENSE_UI_KEY_PASS`), and `--restrict-ui` to answer the page only on the management port.

### 2a. Network ports and the HTTPS certificate (new in 1.3)

**Ports.** *Setup -> Network ports* lists every network port on the box (physical NICs, USB adapters, Wi-Fi; tick *show virtual* for bridges, VLANs and VM adapters) with link, speed, addresses, driver and live packets/s. A port you plug in later appears by itself. Give a port a role in its drop-down, then **Save & start**:

- **SPAN / capture** - receives the mirrored traffic; put no IP on it. One per sensor (the analyser is single-threaded).
- **Management** - the port you open this page on and that reaches central. Its address is what central shows under *Open sensor page*. Tick *Only answer this web page on the management port* to refuse the page on every other port (localhost still works). If the management port has no IP, the restriction is not applied, so you cannot lock yourself out; if you choose a management port other than the one you are connected on, the sensor warns you before saving.

*Use suggested roles* picks the default-route port as management and the first port with a link and no IP as SPAN. The sensor does **not** change the operating system's IP settings: give the management port its address (DHCP or static) with netplan / NetworkManager / dhcpcd as usual.

**Certificate.** The page starts with a self-signed certificate. Open *HTTPS certificate*, choose your **certificate** (`.crt`/`.pem`, with the intermediate certificates in the same file if you have them) and **private key** (`.key`/`.pem`), or one **.pfx/.p12** file, add the passphrase if there is one, and press **Upload & apply**. The sensor checks that the key matches, that the certificate is not expired and warns if it is self-signed, lacks intermediates, expires within 30 days or does not list the address you are browsing to. The page switches to the new certificate immediately, no restart; press *Reload this page* to see it. *Go back to the built-in self-signed certificate* undoes it. To renew, upload the new files the same way.

- The key must come from the same request as the certificate; DER/binary certificates must be converted first: `openssl x509 -inform der -in cert.cer -out cert.pem`.
- Use a certificate that lists the sensor's IP address or DNS name in its names (SAN), otherwise browsers warn even though it is CA-signed.
- Stored in `/var/lib/otsense/custom-cert.pem` and `custom-key.pem` (mode 600, key stored unencrypted because the service cannot ask for a passphrase at boot). If an uploaded certificate cannot be loaded at start-up, the sensor falls back to the self-signed one so the page stays reachable.
- A private key is never accepted over plain http (only possible when `openssl` is missing).

**Raspberry Pi**: Pi 4 or 5 (64-bit Raspberry Pi OS or Ubuntu), the built-in port as management plus a USB 3 gigabit adapter as capture port. Keep the clock right (NTP). Suitable for small sites; a Pi cannot keep up with sustained high-rate gigabit mirrors.

| Port | Direction | Purpose |
|---|---|---|
| TCP 8443 | sensor -> central | HTTPS push (only port needed; sensors are outbound-only) |
| TCP 8443 | analyst browser -> central | console |
| TCP 8080 | admin browser -> sensor | sensor setup page (management network only; password protected, HTTPS) |
| capture NIC | SPAN/TAP -> sensor | mirrored traffic, no IP |

If central is unreachable the sensor keeps collecting and catches up when it returns.

## 3. Console

- **Search box** (all sites at once): free text, or `vendor:siemens proto:modbus type:plc ip:10.1.2. risk:50 -os:windows site:pune "exact phrase"`. Alerts: `kind:OT_STOP sev:critical mitre:T0816`. Flows: `port:502 func:"Write Single Register"`.
- Filters per tab, sortable columns, paging, **CSV export** of any filtered view.
- Alerts: acknowledge / close / reopen with a note (roles: admin, analyst, viewer). Closed alerts reopen if they recur.
- Asset drawer: model, firmware, serial, protocols, peers, alerts, communications, and the same MAC at other sites.
- Network map per site, sensor health (online/offline), audit log.
- Users: `python3 otsense_central.py user add alice --role analyst`.

## 3a. Activity log (new in 1.2)

Besides inventory, flows and alerts, every sensor now sends an **activity log**: each packet-level event it decodes, such as `Modbus/TCP Write Single Register 10.0.0.5 -> 10.0.0.13`, `S7comm Write Var`, DNS queries (with the name), TLS SNI, HTTP host, ARP who-has, ICMP echo, new TCP connections and SYN attempts. In the console open the **Activity** tab: every line is a plain-English sentence (for example "raspberrypi (192.168.10.99) changed a value on Siemens PLC (192.168.10.11) using S7comm") with the technical details in grey underneath; newest first, per site and sensor, with time window, category chips (stop / program / control / write / discover / session / read / response / info), "OT only", live refresh, search (`proto:modbus func:write cat:stop ip:10.0.0.5 port:502 sensor:pi-01 -proto:dns`), CSV export. Clicking a row opens the device; the device drawer also lists its recent activity.

- Identical events (same source, destination, protocol, port, function) are merged inside one push window into one row with a packet count, so a PLC polled 50 times a second is one row, not 50. This is a log of *what happened*, not a pcap; keep using the sensor page "download pcap" for raw packets.
- Sensors keep up to 100,000 unsent activity rows while central is unreachable and send them on recovery. A retried push never creates duplicates.
- **Node central** (`central.js`) keeps the log in `data/activities.ndjson`. Environment variables: `ACT_RETENTION_DAYS` (default 14) and `ACT_MAX_PER_SITE` (default 50000 rows per site, oldest dropped first).
- Update the sensor (`otsense.py`) and `central.js` + `public/index.html` together. A 1.2 sensor works with an old central (the activity data is ignored); an old sensor works with the new central (the Activity tab stays empty for it).
- The Python central (`otsense_central.py`) does not store the activity log yet; use the Node central for this feature.

## 4. Single laptop / VM (no central)

```bash
python3 otsense.py pcap capture.pcap -o out        # report.html + CSV + JSON
sudo python3 otsense.py live -i eth0 -t 300 -o out  # live capture (Linux: no dependencies)
python3 otsense.py web --port 8080                  # dashboard with pcap upload + live capture
python3 otsense.py nmap 192.168.10.0/24             # optional: ARP-ping discovery only (safe)
```
Windows/macOS live capture needs `pip install scapy` + Npcap/libpcap.

## 5. What it understands

Modbus/TCP, S7comm (+S7CommPlus detection), DNP3, EtherNet/IP + CIP, BACnet/IP, OPC UA, IEC 60870-5-104, IEC 61850 GOOSE/SV/MMS, PROFINET DCP/RT, LLDP, plus DNS, mDNS, DHCP, HTTP, TLS (SNI), SSH, Telnet, FTP, and port-based labels for OMRON FINS, MELSEC, CODESYS, Niagara Fox, HART-IP and others.
Extracts MAC, vendor (OUI), IP, hostname, model, firmware, serial, OS guess, listening ports, peers, Purdue-level guess.
Detects: stop / program download / control / write commands, unauthorized discovery, port scans, ARP sweeps and spoofing, rogue DHCP, OT devices talking to the internet, clear-text protocols, and (with `--baseline`) new devices and new OT flows.

## 6. Limits - read before relying on it

- Validated on a synthetic OT pcap, real loopback Modbus traffic and fuzzed input - **not yet on real plant captures**. Run it against real pcaps (Wireshark sample captures, your own SPAN) and expect parser gaps.
- Not Armis/Claroty parity: no vulnerability/CVE matching, no threat-intel feeds, no cloud, no ERSPAN/GRE/VXLAN decapsulation, no decryption, no HA. Rules are simple and role "who may write" is not yet policy-driven.
- Central uses SQLite: fine for tens of thousands of assets and dozens of sites; move to PostgreSQL beyond that.
- Sensor holds its inventory in memory (lost on restart, rebuilt from live traffic). Throughput measured about 75k small packets/s per sensor (single thread).
- The sensor setup page was tested end to end in a browser, and the "mirrored traffic" detection on a real (virtual) network port pair. It has **not** been tested on a real switch SPAN, on Raspberry Pi hardware, or on a live systemd host (installers were verified in a staging directory and with `systemd-analyze verify`).
- Central-managed sensor logins were tested end to end (wrong password, roles, central outage, cached logins). A removed user stays signed in for up to 12 hours and can use the cached login while central is unreachable.
- The sensor page is HTTPS (self-signed until you upload a certificate); keep it on the management network behind a firewall.
- 1.3 additions (port roles, certificate upload) were tested against a live HTTPS sensor and in a browser: wrong key, expired certificate, encrypted key, `.pfx`, intermediates in the wrong order, hot switch-over, fallback, plain-http refusal, and the installer options in a staging root. The management-port restriction was tested with a simulated second network card. They have **not** been tested on a real multi-NIC machine, a Raspberry Pi, or with a certificate from your own CA.
- Only monitor networks you own or are authorised to monitor.
