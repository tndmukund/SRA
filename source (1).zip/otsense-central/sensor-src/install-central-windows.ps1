# OTSense CENTRAL on Windows (needs Docker Desktop). Right-click this file > Run with PowerShell, or double-click install-central-windows.bat
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Write-Host "Docker Desktop is required. Opening the download page..." ; Start-Process "https://www.docker.com/products/docker-desktop/"
  Read-Host "Install Docker Desktop, start it, then run this again. Press Enter"; exit 1 }
$ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notmatch '^(127|169)' -and $_.PrefixOrigin -ne 'WellKnown' } | Select-Object -First 1).IPAddress
$name = Read-Host "Address of this server that sensors/browsers will use [$ip]"; if (-not $name) { $name = $ip }
if (Test-Path otsense-image.tar.gz) { docker load -i otsense-image.tar.gz | Out-Null } else { docker build -q -t otsense:1.3 . | Out-Null }
docker rm -f otsense-central 2>$null | Out-Null
docker run -d --name otsense-central --restart unless-stopped -p 8443:8443 -e OTSENSE_NAME="$name" -v otsense-central:/data otsense:1.3 central | Out-Null
Start-Sleep 6
Remove-Item -Recurse -Force otsense-pki -ErrorAction SilentlyContinue
docker cp otsense-central:/data/pki ./otsense-pki | Out-Null
Copy-Item otsense-pki\ca.crt otsense-ca.crt -Force
certutil -addstore -f Root otsense-ca.crt | Out-Null     # trust the CA on this PC -> no browser warning (needs Administrator; skipped otherwise)
Write-Host ""; docker logs otsense-central 2>&1 | Select-String -Context 0,3 "first start"
Write-Host "`nOpen: https://${name}:8443"
Write-Host "Other PCs: double-click otsense-ca.crt > Install Certificate > Local Machine > Trusted Root Certification Authorities."
Write-Host "Sensors (Linux): copy the folder otsense-pki to each sensor box (keep it private). Do NOT share it otherwise."
Start-Process "https://${name}:8443"; Read-Host "Press Enter to close"
