#!/usr/bin/env bash
# For YOU (the sender), once, on any machine with Docker + internet:
# builds the image and saves it as otsense-image.tar.gz in this folder. Zip the folder and send it;
# the receiver then needs NO internet and NO Python: just  sudo ./install.sh central|sensor
set -euo pipefail; cd "$(dirname "$0")"
docker build -t otsense:1.3 . && docker save otsense:1.3 | gzip > otsense-image.tar.gz
ls -lh otsense-image.tar.gz
