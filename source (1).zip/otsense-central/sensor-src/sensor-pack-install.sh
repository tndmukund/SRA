#!/usr/bin/env bash
# OTSense SENSOR - ONE command, everything already filled in:     sudo ./install.sh
set -euo pipefail
cd "$(dirname "$0")"
[ "$(id -u)" -eq 0 ] || { echo "Please run:  sudo ./install.sh"; exit 1; }
# shellcheck disable=SC1091
. ./sensor.conf
if ! command -v docker >/dev/null; then
  echo "Installing Docker (one time, needs internet)..."; curl -fsSL https://get.docker.com | sh; systemctl enable --now docker 2>/dev/null || true
fi
echo "Loading OTSense..."; docker load -i otsense-image.tar.gz >/dev/null
# keep the settings files in a permanent place
P=/opt/otsense-sensor; mkdir -p "$P"; cp ca.crt "$P/ca.crt"
[ -f ui.crt ] && [ -f ui.key ] && { cp ui.crt ui.key "$P/"; chmod 600 "$P/ui.key"; }
# pick the network ports: management = the one with the default route; capture = first real port with no IP address
MGMT="$(ip -o -4 route show default 2>/dev/null | awk '{print $5; exit}')"; CAP=""
for n in $(ls /sys/class/net); do
  case "$n" in lo|docker*|veth*|br-*|virbr*|tun*|tap*|ifb*|bond*|wl*) continue;; esac
  [ -e "/sys/class/net/$n/device" ] || continue
  [ "$n" = "$MGMT" ] && continue
  ip -o -4 addr show dev "$n" 2>/dev/null | grep -q . && continue
  CAP="$n"; break
done
echo "Management port: ${MGMT:-not found}    Capture (SPAN) port: ${CAP:-not found}"
docker rm -f otsense-sensor >/dev/null 2>&1 || true
docker run -d --name otsense-sensor --restart unless-stopped --network host --cap-add NET_RAW --cap-add NET_ADMIN \
  -v otsense-sensor:/data -v "$P":/pack:ro \
  -e OTSENSE_SITE="$SITE" -e OTSENSE_CENTRAL="$CENTRAL" -e OTSENSE_TOKEN="$TOKEN" -e OTSENSE_IFACE="$CAP" -e OTSENSE_MGMT="$MGMT" \
  otsense:1.3 sensor >/dev/null
sleep 8
IP="${SENSOR_IP:-$(hostname -I | awk '{print $1}')}"
echo
docker logs otsense-sensor 2>&1 | grep -iE "password|Cannot|error" || true
echo
echo "DONE. Site '$SITE' will now appear in the central console (Sites & sensors) within a minute."
echo "Sensor page (optional): http://$IP"
[ -z "$CAP" ] && echo "NOTE: no free capture port was found. Plug the mirror/SPAN cable into the 2nd network port, then run this command again."
exit 0
