#!/bin/sh
# Container entrypoint: central | sensor | cli | ccli.  State lives in /data (Docker volume).
# HTTPS always. Certificates: (1) your own (mounted at /certs/cert.pem + key.pem), else
# (2) signed by a small private CA (/pki/ca.crt + ca.key, created on central) -> trust ca.crt once per PC = no warning,
# else (3) self-signed (browser warning).
set -e
cd /opt/otsense
mode="${1:-help}"; [ $# -gt 0 ] && shift

# issue_cert <ca_dir> <out_prefix> <comma-separated names/IPs>
issue_cert() {
  ca="$1"; out="$2"; names="$3"; i=0; san=""
  for n in $(echo "$names" | tr ',' ' '); do
    i=$((i+1))
    if echo "$n" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$|:'; then san="$san,IP:$n"; else san="$san,DNS:$n"; fi
  done
  san="${san#,}"; cn="$(echo "$names" | cut -d, -f1)"
  printf "subjectAltName=%s\nextendedKeyUsage=serverAuth\nkeyUsage=digitalSignature,keyEncipherment\nbasicConstraints=CA:FALSE\n" "$san" > "$out.ext"
  openssl req -new -newkey rsa:2048 -nodes -keyout "$out.key" -subj "/CN=$cn" -out "$out.csr" 2>/dev/null
  openssl x509 -req -in "$out.csr" -CA "$ca/ca.crt" -CAkey "$ca/ca.key" -CAcreateserial -days 800 -sha256 -extfile "$out.ext" -out "$out.crt" 2>/dev/null
  cat "$out.crt" > "$out.pem"; chmod 600 "$out.key"; rm -f "$out.csr" "$out.ext"
}
make_ca() {
  mkdir -p "$1"
  if [ ! -f "$1/ca.crt" ]; then
    openssl req -x509 -newkey rsa:4096 -nodes -keyout "$1/ca.key" -out "$1/ca.crt" -days 3650 -sha256 \
      -subj "/CN=OTSense Local CA" -addext "basicConstraints=critical,CA:TRUE" -addext "keyUsage=critical,keyCertSign,cRLSign" 2>/dev/null
    chmod 600 "$1/ca.key"
  fi
}
needs_new() { # cert file, names -> true if missing, expiring within 30 days, or names changed
  [ ! -f "$1.crt" ] && return 0
  openssl x509 -in "$1.crt" -noout -checkend 2592000 >/dev/null 2>&1 || return 0
  [ "$(cat "$1.names" 2>/dev/null)" = "$2" ] || return 0
  return 1
}

case "$mode" in
central)
  PORT="${OTSENSE_PORT:-8443}"; D=/data; NAMES="localhost,127.0.0.1,${OTSENSE_NAME:-}"
  NAMES="$(echo "$NAMES" | sed 's/,,*/,/g; s/,$//')"
  mkdir -p "$D/certs"
  if [ -f /certs/cert.pem ] && [ -f /certs/key.pem ]; then
    CERT=/certs/cert.pem; KEY=/certs/key.pem; echo "Using your own certificate from /certs"
  else
    make_ca "$D/pki"
    if needs_new "$D/certs/server" "$NAMES"; then issue_cert "$D/pki" "$D/certs/server" "$NAMES"; echo "$NAMES" > "$D/certs/server.names"; fi
    CERT="$D/certs/server.pem"; KEY="$D/certs/server.key"
    cp "$D/pki/ca.crt" "$D/certs/cert.pem"   # what sensors use to verify central (the CA)
  fi
  if ! python3 otsense_central.py --db "$D/otsense.db" user list 2>/dev/null | grep -q '^admin '; then
    PW="${OTSENSE_ADMIN_PASSWORD:-$(python3 -c 'import secrets;print(secrets.token_urlsafe(12))')}"
    python3 otsense_central.py --db "$D/otsense.db" user add admin --role admin --password="$PW" >/dev/null
    echo "=================================================="
    echo " OTSense Central first start"
    echo " Login: admin / $PW   (shown once - change it in the console)"
    echo "=================================================="
  fi
  exec python3 otsense_central.py --db "$D/otsense.db" serve --host 0.0.0.0 --port "$PORT" \
       --cert "$CERT" --key "$KEY" --retention-days "${OTSENSE_RETENTION_DAYS:-90}"
  ;;
sensor)
  D=/data; EXTRA=""
  if [ -f /certs/cert.pem ] && [ -f /certs/key.pem ]; then
    EXTRA="--ui-cert /certs/cert.pem --ui-key /certs/key.pem"; echo "Using your own web page certificate from /certs"
  elif [ -f /pack/ui.crt ] && [ -f /pack/ui.key ]; then
    EXTRA="--ui-cert /pack/ui.crt --ui-key /pack/ui.key"; echo "Web page certificate from the sensor pack"
  elif [ -f /pki/ca.crt ] && [ -f /pki/ca.key ] && [ -n "${OTSENSE_NAME:-}" ]; then
    NAMES="localhost,127.0.0.1,$OTSENSE_NAME"
    mkdir -p "$D/ui"
    if needs_new "$D/ui/sensor" "$NAMES"; then issue_cert /pki "$D/ui/sensor" "$NAMES"; echo "$NAMES" > "$D/ui/sensor.names"; fi
    EXTRA="--ui-cert $D/ui/sensor.pem --ui-key $D/ui/sensor.key"; echo "Web page certificate issued by your OTSense CA for $OTSENSE_NAME"
  fi
  # First start of a ready-made sensor pack: join central automatically (settings can be changed later on the web page)
  if [ ! -f "$D/sensor.json" ] && [ -n "${OTSENSE_CENTRAL:-}" ]; then
    # shellcheck disable=SC2086
    python3 otsense.py appliance --state-dir "$D" --configure-only --site "${OTSENSE_SITE:-sensor}" \
      --central "$OTSENSE_CENTRAL" --token "$OTSENSE_TOKEN" --cafile /pack/ca.crt \
      ${OTSENSE_IFACE:+--iface "$OTSENSE_IFACE"} ${OTSENSE_MGMT:+--mgmt-iface "$OTSENSE_MGMT"} $EXTRA
  fi
  # shellcheck disable=SC2086
  # the web page answers on port 80 (http) or 443 (https, once a certificate is added); OTSENSE_UI_PORT forces one port
  if [ "${OTSENSE_NETAPPLY:-1}" = 1 ] && command -v ip >/dev/null 2>&1; then
    python3 otsense.py netapply --state-dir "$D" --loop >/tmp/netapply.log 2>&1 &
  fi
  exec python3 otsense.py appliance --state-dir "$D" ${OTSENSE_UI_PORT:+--ui-port "$OTSENSE_UI_PORT"} $EXTRA "$@"
  ;;
issue) issue_cert /data/pki "$1" "$2" ;;
cli)  exec python3 otsense.py "$@" ;;
ccli) exec python3 otsense_central.py --db /data/otsense.db "$@" ;;
*) echo "usage: central | sensor | cli <otsense.py args> | ccli <otsense_central.py args>"; exit 0 ;;
esac
