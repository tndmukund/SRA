The base ISO is saved here automatically (otsense-sensor.iso) after you press 'Build base ISO' on the Sites tab.
