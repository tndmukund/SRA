#!/bin/bash
# OT Sense sensor - started at every boot by otsense-sensor.service (runs as root, inside the live ISO system).
# Reads the settings stamped into the ISO by central, sets the network ports, then runs the sensor (same otsense.py as the container).
# Test:  DRY_RUN=1 NICS="eth0 eth1" SLOT=./slot.bin ./run-sensor.sh
set -u
DRY="${DRY_RUN:-0}"; SLOT="${SLOT:-/run/live/medium/otsense/slot.bin}"; D="${D:-/opt/otsense}"; STATE="${STATE:-/var/lib/otsense}"; CA="${CA:-/opt/otsense/ca.crt}"
run() { if [ "$DRY" = 1 ]; then echo "+ $*"; else "$@"; fi; }
log() { echo "[otsense] $*"; }
mkdir -p "$STATE"
eval "$(python3 "$D/slot-read.py" "$SLOT" "$CA")"
if [ "${CONFIGURED:-0}" != 1 ]; then
  log "This ISO was not stamped by central (download it from central: Sites > Build a sensor). Starting in manual mode: open the web page and use Setup."
  # network helper: lets the web page change the management IP (with automatic roll-back); there is no systemd path unit in the live image
  [ "$DRY" = 1 ] || python3 "$D/otsense.py" netapply --state-dir "$STATE" --loop >/var/log/otsense-netapply.log 2>&1 &
  run exec python3 "$D/otsense.py" appliance --state-dir "$STATE"
  exit 0
fi
[ "${HAVE_CA:-0}" = 1 ] || run cp /etc/ssl/certs/ca-certificates.crt "$CA"
[ -n "${CONSOLE_PASSWORD:-}" ] && [ "$DRY" != 1 ] && echo "user:$CONSOLE_PASSWORD" | chpasswd

# network ports: 1st physical port (sorted by name) = management, every other physical port = capture (SPAN, no IP). Roles can be changed on the web page.
if [ -n "${NICS:-}" ]; then LIST="$NICS"; else LIST=""
  for d in /sys/class/net/*; do n="$(basename "$d")"
    case "$n" in lo|docker*|veth*|br-*|virbr*|tun*|tap*|ifb*|bond*|wl*) continue;; esac
    [ -e "$d/device" ] && LIST="$LIST $n"; done; LIST="$(echo "$LIST" | tr ' ' '\n' | sort | tr '\n' ' ')"; fi
set -- $LIST; MGMT="${1:-}"; shift 2>/dev/null || true; CAP="$(echo "$*" | tr ' ' ',')"
log "site=$SITE management=${MGMT:-none} capture=${CAP:-none}"
if [ -n "$MGMT" ]; then
  IF="auto $MGMT\n"
  if [ "$MODE" = static ]; then
    IF="${IF}iface $MGMT inet static\n  address $IP_CIDR\n  gateway $GATEWAY\n"
    if [ "$DRY" = 1 ]; then echo "(resolv.conf: $DNS)"; else : > /etc/resolv.conf; for x in $(echo "$DNS" | tr ',' ' '); do echo "nameserver $x" >> /etc/resolv.conf; done; fi
  else IF="${IF}iface $MGMT inet dhcp\n"; fi
  if [ "$DRY" = 1 ]; then printf "$IF"; else
    printf "$IF" > /etc/network/interfaces.d/otsense; ip addr flush dev "$MGMT" 2>/dev/null; ifup "$MGMT" 2>&1 || log "ifup $MGMT failed"; fi
fi
for c in $(echo "$CAP" | tr ',' ' '); do run ip addr flush dev "$c"; run ip link set "$c" up promisc on; done

# wait (max 60 s) for an address, then show the web page address on the console
IP=""; for i in $(seq 1 30); do IP="$(ip -o -4 addr show dev "${MGMT:-lo}" 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1)"; [ -n "$IP" ] && break; [ "$DRY" = 1 ] && break; sleep 2; done
if [ "$DRY" != 1 ]; then printf '\n  OT Sense sensor - site %s\n  Web page: http://%s  (no port number; HTTPS once you add a certificate)\n  Console login (troubleshooting): user / %s\n\n' "$SITE" "${IP:-<no address yet>}" "${CONSOLE_PASSWORD:-}" > /etc/issue; fi

run python3 "$D/otsense.py" appliance --state-dir "$STATE" --configure-only --site "$SITE" --central "$CENTRAL" --token "$TOKEN" --cafile "$CA" \
  ${CAP:+--iface "$CAP"} ${MGMT:+--mgmt-iface "$MGMT"}
[ "$DRY" = 1 ] || python3 "$D/otsense.py" netapply --state-dir "$STATE" --loop >/var/log/otsense-netapply.log 2>&1 &
run exec python3 "$D/otsense.py" appliance --state-dir "$STATE"
