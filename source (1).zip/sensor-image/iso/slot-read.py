#!/usr/bin/env python3
"""Reads the config slot central stamped into the ISO. usage: slot-read.py <slot.bin> <ca-out-path>
Prints shell lines (CONFIGURED=1 + settings) for run-sensor.sh to eval."""
import json, shlex, struct, sys
MAGIC = b"OTSENSE_SLOT_V1\n"
def out(k, v): print("%s=%s" % (k, shlex.quote(str(v))))
try:
    d = open(sys.argv[1], "rb").read(65536)
    if d[:16] != MAGIC:
        raise ValueError("bad magic")
    n = struct.unpack(">I", d[16:20])[0]
    if n == 0:
        raise ValueError("not stamped")
    c = json.loads(d[20:20 + n].decode())
    for k in ("site", "central", "token", "mode", "ip_cidr", "gateway", "dns", "console_password"):
        out(k.upper(), c.get(k, ""))
    if c.get("ca_pem"):
        open(sys.argv[2], "w").write(c["ca_pem"].strip() + "\n")
        out("HAVE_CA", 1)
    out("CONFIGURED", 1)
except Exception as e:
    sys.stderr.write("slot not usable: %s\n" % e)
    out("CONFIGURED", 0)
