#!/usr/bin/env bash
# OT Sense sensor - first-boot setup. Started once by cloud-init from the seed that central generated.
# Reads /etc/otsense/sensor.conf, sets up the two network ports, starts the sensor container.
# Test without changing anything:  DRY_RUN=1 NICS="ens160 ens192" CONF=./sensor.conf ./firstboot.sh
set -uo pipefail
DRY="${DRY_RUN:-0}"; CONF="${CONF:-/etc/otsense/sensor.conf}"
[ "$DRY" = 1 ] || { exec >>/var/log/otsense-firstboot.log 2>&1; [ -f /var/lib/otsense-firstboot.done ] && exit 0; }
run() { if [ "$DRY" = 1 ]; then echo "+ $*"; else "$@"; fi; }
echo "=== OT Sense first boot $(date -u +%FT%TZ)"
# shellcheck disable=SC1090
. "$CONF" || { echo "no sensor.conf - seed missing"; exit 1; }

# 1. network ports: 1st physical port = management, 2nd = capture (SPAN, no IP)
if [ -n "${NICS:-}" ]; then LIST="$NICS"; else
  LIST=""; for d in /sys/class/net/*; do n="$(basename "$d")"
    case "$n" in lo|docker*|veth*|br-*|virbr*|tun*|tap*|ifb*|bond*|wl*) continue;; esac
    [ -e "$d/device" ] && LIST="$LIST $n"; done; LIST="$(echo "$LIST" | tr ' ' '\n' | sort | tr '\n' ' ')"; fi
set -- $LIST; MGMT="${1:-}"; CAP="${2:-}"
echo "ports: management=${MGMT:-none} capture=${CAP:-none}"
[ -n "$MGMT" ] || { echo "no network port found"; exit 1; }
Y="network:\n  version: 2\n  ethernets:\n"
if [ "$MGMT_MODE" = static ]; then
  DNSL="$(echo "$DNS" | sed 's/,/, /g')"
  Y="$Y    $MGMT:\n      dhcp4: false\n      addresses: [$IP_CIDR]\n      routes:\n        - {to: default, via: $GATEWAY}\n      nameservers: {addresses: [$DNSL]}\n"
else Y="$Y    $MGMT:\n      dhcp4: true\n"; fi
[ -n "$CAP" ] && Y="$Y    $CAP:\n      dhcp4: false\n      dhcp6: false\n      accept-ra: false\n      link-local: []\n"
if [ "$DRY" = 1 ]; then printf "$Y"; else
  rm -f /etc/netplan/50-cloud-init.yaml; printf "$Y" > /etc/netplan/60-otsense.yaml; chmod 600 /etc/netplan/60-otsense.yaml
  netplan apply; sleep 5; fi

# 2. CA of central (own CA if the seed carried one, otherwise the normal public CA list)
run mkdir -p /opt/otsense-sensor
if [ -s /etc/otsense/ca.crt ]; then run cp /etc/otsense/ca.crt /opt/otsense-sensor/ca.crt
else run cp /etc/ssl/certs/ca-certificates.crt /opt/otsense-sensor/ca.crt; fi

# 3. container engine + sensor image (VM images already contain both; Raspberry Pi installs them here, needs internet once)
if ! command -v docker >/dev/null; then run apt-get update -qq; run apt-get install -y -qq docker.io; run systemctl enable --now docker; fi
if [ -z "$(docker images -q otsense:1.3 2>/dev/null)" ] || [ "$DRY" = 1 ]; then
  if [ -f /opt/otsense/otsense-image.tar.gz ]; then run docker load -i /opt/otsense/otsense-image.tar.gz
  else run docker build -q -t otsense:1.3 /opt/otsense/src; fi
fi

# 4. start the sensor (joins central by itself, token comes from the seed)
run docker rm -f otsense-sensor
run docker run -d --name otsense-sensor --restart unless-stopped --network host --cap-add NET_RAW --cap-add NET_ADMIN \
  -v otsense-sensor:/data -v /opt/otsense-sensor:/pack:ro \
  -e OTSENSE_SITE="$SITE" -e OTSENSE_CENTRAL="$CENTRAL" -e OTSENSE_TOKEN="$TOKEN" -e OTSENSE_IFACE="$CAP" -e OTSENSE_MGMT="$MGMT" otsense:1.3 sensor
[ "$DRY" = 1 ] || { touch /var/lib/otsense-firstboot.done; systemctl restart otsense-banner 2>/dev/null || true; }
echo "=== done"
