#!/usr/bin/env bash
# Builds a sensor image INSIDE a throw-away Docker container, so the host only needs Docker (installed automatically if missing).
# usage (run as root, internet needed):   ./docker-build.sh <target> /path/to/otsense-docker
#   target = iso-amd64   -> images/otsense-sensor.iso          (VMware, Hyper-V, VirtualBox, Proxmox, PC/laptop USB)
#            rpi-arm64   -> images/otsense-sensor-rpi.img.xz   (Raspberry Pi 4/5)
# Central runs this for you from the Sites tab. OUT_DIR overrides the output folder.
set -euo pipefail
TARGET="${1:-iso-amd64}"; SRC="$(readlink -f "${2:-}")"; HERE="$(cd "$(dirname "$0")" && pwd)"; OUT="$(readlink -m "${OUT_DIR:-$HERE/images}")"
[ -f "$SRC/otsense.py" ] || { echo "sensor source not found: $SRC (needs otsense.py)"; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo "run as root"; exit 1; }
case "$TARGET" in iso-amd64) SCRIPT=build-iso.sh;; rpi-arm64) SCRIPT=build-rpi-image.sh;; *) echo "unknown target $TARGET"; exit 1;; esac
if ! command -v docker >/dev/null 2>&1; then
  echo "[docker] not installed - installing from the Internet (get.docker.com)..."
  command -v curl >/dev/null 2>&1 || { apt-get update -qq && apt-get install -y -qq curl ca-certificates; }
  curl -fsSL https://get.docker.com | sh
fi
systemctl start docker 2>/dev/null || service docker start 2>/dev/null || true
docker info >/dev/null 2>&1 || { echo "[docker] daemon is not running"; exit 1; }
mkdir -p "$OUT"
echo "[docker] pulling debian:12 and building $TARGET (10-30 min, ~500 MB download)..."
docker pull debian:12
# --privileged: live-build needs chroot/mount inside the container. The container is deleted afterwards (--rm).
docker run --rm --privileged -v "$HERE":/img:ro -v "$SRC":/src:ro -v "$OUT":/out -e OUT_DIR=/out -e DEBIAN_FRONTEND=noninteractive \
  debian:12 bash -c "apt-get update -qq && apt-get install -y -qq bash coreutils && cp -r /img /work && cd /work && rm -rf work-iso work images && bash $SCRIPT /src"
ls -lh "$OUT"
