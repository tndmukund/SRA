#!/bin/sh
# Writes the sensor web address on the login screen of the console (VM console / monitor), refreshed at each boot.
IP="$(ip -o -4 route get 1.1.1.1 2>/dev/null | sed -n 's/.* src \([0-9.]*\).*/\1/p')"
[ -z "$IP" ] && IP="$(hostname -I | awk '{print $1}')"
mkdir -p /etc/issue.d
printf '\n  OT Sense sensor\n  Web page: http://%s   (setup password: docker logs otsense-sensor | grep -i password)\n\n' "${IP:-<waiting for network>}" > /etc/issue.d/99-otsense.issue
