# One reusable sensor ISO, stamped by central

## Idea
`otsense-sensor.iso` is built **once**. It contains no token or password, only an empty 64 KB config slot.
When you press **Build** in central, central streams that same file to you and writes the site name, token, central address and IP into the slot. The sensor reads the slot at every boot. Nothing to type on site.

## One-time: let central build the ISO (automatic)
Central must run on a **Linux server as root with internet** (a Plesk/shared host cannot build it; build once elsewhere and copy the file into `images/`).
1. Keep the folders side by side: `otsense-central/` (with `sensor-src/` = your otsense-docker folder, already included) and `sensor-image/`.
2. `cd otsense-central && sudo node central.js`
3. Console -> **Sites** -> **Build base ISO** (10-30 min, progress shown). The file is saved in `otsense-central/images/otsense-sensor.iso` and reused for every sensor from then on. **Rebuild** only when you ship a new sensor version.
Manual alternative: `sudo ./build-iso.sh /path/to/otsense-docker` and copy `images/otsense-sensor.iso` to central's `images` folder.

## Every new sensor
Central -> **Sites** -> **Build a ready-to-install sensor** -> site name, platform, central address, DHCP or fixed IP -> **Build** -> download the ISO (and the .ps1 for Windows).
Sensor needs **two network ports**: 1 = normal network, 2 = mirror/SPAN port (no IP).

| Platform | What to do |
|---|---|
| VMware ESXi / Workstation | New VM (Linux 64-bit, 2 vCPU, 4 GB, no disk), CD/DVD = the ISO, 2 NICs (capture port group: Promiscuous = Accept), Secure Boot off, power on |
| Hyper-V | Run the downloaded `.ps1` as Administrator next to the ISO (creates the VM) |
| VirtualBox / Proxmox / KVM | Same as VMware (promiscuous mode "Allow all" on the capture NIC) |
| Laptop / PC | Write ISO to USB (Rufus in DD mode or balenaEtcher), boot it, Secure Boot off. Keep the USB in. USB gigabit adapter = capture port |
| Raspberry Pi 4/5 | ARM, so a different image: `build-rpi-image.sh`, copy the seed zip to the boot partition |
| Linux with Docker | `install-sensor.sh` |
| Android | test only (replays a sample capture) |

The sensor runs from the ISO (live system): every boot re-reads the stamped settings, so keep the ISO/USB attached. Collected data is kept by central.
The web address is shown on the VM/PC console login screen. Troubleshooting login: user `user`, password shown once in central at build time.

## Not unmodified / honest limits
- A phone cannot capture mirrored traffic (iOS never, Android only rooted). Windows itself cannot be the sensor OS; it runs the ISO as a Hyper-V VM.
- The ISO is x86-64. Raspberry Pi/ARM needs its own image.
- Scripts were tested here only in parts: stamping/download (byte-checked), slot reader and run script (dry run). `build-iso.sh` itself was not run.

## v1.6: build from the console in Docker, pick the image type, active device count
- **Sites tab -> Sensor image builder**: pick the image in the drop-down (x86-64 ISO, or Raspberry Pi 4/5), pick "Build in Docker container", press Build. Central runs `sensor-image/docker-build.sh`: it installs Docker from the Internet if missing (needs root + internet), pulls `debian:12`, builds inside a throw-away container and saves the file in `otsense-central/images/`. Everything stays on the central server.
- The x86 ISO is stamped per site as before. The Raspberry Pi image is not stamped (use the Download link, then follow the Pi steps above).
- **Active mode (device count)**: the sensor ARP-scans its own management subnet (max /22) every 60 s and reports how many devices answered. Central shows "N devices connected now" + the list (IP, MAC, vendor) on the Sites tab, and each device also appears in Assets (flag `active-scan`). Turn off with `OTSENSE_ACTIVE=0`, change the interval with `OTSENSE_ACTIVE_EVERY=120`.
- Testing on a mobile hotspot: the sensor's management NIC must really be on the hotspot network (laptop Wi-Fi bridged to the VM, or a Linux PC/USB boot on the hotspot). Some phones isolate clients, in which case only the phone/gateway answers. Active scan counts devices that answer ARP; sleeping phones may miss a scan, so watch the number over a few minutes.
- Not run here: Docker build, the ISO boot, and the ARP scan (this sandbox has no Docker, no `ip`, no raw network). Run once, read the log in the console, and boot the ISO in a test VM first.

## v1.8: phone test (Android, Termux)
Sites -> Build a ready-to-install sensor -> platform "Android phone / tablet" -> Build -> download `otsense-phone-<site>.zip` (script + sensor + sample capture, all in one).
1. Install **Termux** (from F-Droid) on the phone, run `termux-setup-storage`, unzip the file (e.g. `cd ~/storage/downloads && unzip otsense-phone-*.zip`).
2. `bash termux-sensor.sh` - it first tests the connection to central, then replays the sample capture and counts devices on the Wi-Fi/hotspot network the phone is on.
Without root a phone cannot capture real traffic or send ARP; the count uses short TCP probes (an estimate, devices that silently drop packets are missed). On a Linux machine with root the sensor uses a real ARP scan.
