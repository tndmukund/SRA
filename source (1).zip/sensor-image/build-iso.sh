#!/usr/bin/env bash
# Builds the ONE reusable sensor ISO (x86-64: VMware, Hyper-V, VirtualBox, Proxmox/KVM, laptops/PCs from USB).
# Run once, on Debian 12 or Ubuntu 22.04/24.04 with internet, as root:   sudo ./build-iso.sh /path/to/otsense-docker
# Result: ./images/otsense-sensor.iso  -> copy it into the "images" folder next to central.js. No tokens or passwords inside:
# central stamps site name, token and IP into a reserved 64 KB slot of this same file at every download.
# Inside: Debian 12 live system + python3 running the same otsense.py as your container (no Docker inside, so it is light: 2 vCPU / 2-4 GB RAM).
# NOTE: written without a build machine to test on. Run it once and read any error; boot the result in a test VM before using it.
set -euo pipefail
SRC="${1:-}"; [ -f "$SRC/otsense.py" ] || { echo "usage: sudo $0 /path/to/otsense-docker   (folder containing otsense.py)"; exit 1; }
SRC="$(readlink -f "$SRC")"; HERE="$(cd "$(dirname "$0")" && pwd)"; OUT="${OUT_DIR:-$HERE/images}"; W="$HERE/work-iso"
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }
apt-get update -qq; apt-get install -y -qq live-build debootstrap xorriso squashfs-tools python3 curl
rm -rf "$W"; mkdir -p "$W" "$OUT"; cd "$W"
lb config --distribution bookworm --architectures amd64 --archive-areas main --binary-images iso-hybrid \
  --bootloaders "syslinux,grub-efi" --debian-installer none --apt-indices false --apt-recommends false \
  --iso-volume OTSENSE --iso-application "OT Sense sensor" --memtest none --bootappend-live "boot=live components quiet"
cat > config/package-lists/otsense.list.chroot <<'EOL'
python3
openssl
iproute2
ethtool
tcpdump
ifupdown
isc-dhcp-client
ca-certificates
open-vm-tools
less
nano
EOL
mkdir -p config/includes.chroot/opt/otsense config/includes.chroot/etc/systemd/system config/includes.binary/otsense config/hooks/live
cp "$SRC/otsense.py" "$SRC/otsense_central.py" config/includes.chroot/opt/otsense/ 2>/dev/null || cp "$SRC/otsense.py" config/includes.chroot/opt/otsense/
cp "$HERE/iso/run-sensor.sh" "$HERE/iso/slot-read.py" config/includes.chroot/opt/otsense/
cp "$HERE/iso/otsense-sensor.service" config/includes.chroot/etc/systemd/system/
printf '#!/bin/sh\nchmod +x /opt/otsense/*.sh /opt/otsense/*.py\nsystemctl enable otsense-sensor.service\nsystemctl enable guacd.service\nsystemctl disable ssh 2>/dev/null || true\n' > config/hooks/live/0100-otsense.hook.chroot
cat > config/hooks/live/0050-guacd.hook.chroot <<'EOHOOK'
#!/bin/sh
# Debian 12 has no guacd package: build Apache Guacamole's guacd (RDP only) from the official source, keep only the runtime libraries.
set -e
export DEBIAN_FRONTEND=noninteractive
V=1.5.5
BUILD="build-essential wget ca-certificates libcairo2-dev libjpeg62-turbo-dev libpng-dev libtool-bin uuid-dev libossp-uuid-dev libfreerdp-dev libwinpr2-dev libpango1.0-dev libssl-dev libwebp-dev"
apt-get update -qq
apt-get install -y -qq --no-install-recommends $BUILD
cd /tmp
U=https://archive.apache.org/dist/guacamole/$V/source/guacamole-server-$V.tar.gz
wget -q "$U" -O gs.tgz
wget -q "$U.sha256" -O gs.sha
[ "$(cut -d' ' -f1 gs.sha)" = "$(sha256sum gs.tgz | cut -d' ' -f1)" ] || { echo "guacamole source checksum mismatch"; exit 1; }
tar xzf gs.tgz
cd guacamole-server-$V
./configure --prefix=/usr --without-ssh --without-telnet --without-vnc --without-kubernetes --disable-guacenc --disable-guaclog
make -j2
make install
ldconfig
[ -x /usr/sbin/guacd ] || { echo "guacd was not built"; exit 1; }
ls /usr/lib/libguac-client-rdp.so* >/dev/null 2>&1 || { echo "guacd RDP plugin was not built (FreeRDP headers missing?)"; exit 1; }
# keep the runtime libraries, remove compilers and headers
LIBS=$(ldd /usr/sbin/guacd /usr/lib/libguac*.so* 2>/dev/null | awk '/=>/ {print $3}' | sort -u)
PK=""
for l in $LIBS; do
  [ -e "$l" ] || continue
  p=$(dpkg-query -S "$l" 2>/dev/null | head -1 | cut -d: -f1)
  [ -n "$p" ] || p=$(dpkg-query -S "$(readlink -f "$l")" 2>/dev/null | head -1 | cut -d: -f1)
  [ -n "$p" ] && PK="$PK $p"
done
[ -z "$PK" ] || apt-mark manual $PK >/dev/null
apt-get purge -y -qq $BUILD || true
apt-get autoremove -y -qq --purge || true
ldconfig
/usr/sbin/guacd -v
rm -rf /tmp/gs.tgz /tmp/gs.sha /tmp/guacamole-server-$V
EOHOOK
cat > config/includes.chroot/etc/systemd/system/guacd.service <<'EOSVC'
[Unit]
Description=Guacamole proxy daemon (browser remote desktop, local only)
After=network.target
[Service]
ExecStart=/usr/sbin/guacd -f -b 127.0.0.1 -l 4822
User=nobody
Restart=always
[Install]
WantedBy=multi-user.target
EOSVC
# the empty config slot: 16-byte marker + zeros, stored as a plain file in the ISO (NOT inside the compressed system) so central can overwrite it in place
python3 -c "open('config/includes.binary/otsense/slot.bin','wb').write(b'OTSENSE_SLOT_V1\n'+bytes(65536-16))"
lb build 2>&1 | tail -n 40
ISO="$(ls -1 live-image-amd64.hybrid.iso *.iso 2>/dev/null | head -1)"; [ -f "$ISO" ] || { echo "ISO was not produced - see messages above"; exit 1; }
cp "$ISO" "$OUT/otsense-sensor.iso.part"
# self-check: exactly one slot marker must exist in the finished ISO (central refuses the file otherwise)
N="$(python3 - "$OUT/otsense-sensor.iso.part" <<'PY'
import sys
M=b"OTSENSE_SLOT_V1\n"; n=0; tail=b""
with open(sys.argv[1],"rb") as f:
    while True:
        c=f.read(8<<20)
        if not c: break
        b=tail+c; n+=b.count(M); tail=b[-15:]
print(n)
PY
)"
[ "$N" = 1 ] || { rm -f "$OUT/otsense-sensor.iso.part"; echo "SELF-CHECK FAILED: found $N config slots (expected 1)"; exit 1; }
mv -f "$OUT/otsense-sensor.iso.part" "$OUT/otsense-sensor.iso"; ls -lh "$OUT/otsense-sensor.iso"; echo "OK. Copy it to <central>/images/otsense-sensor.iso (or set IMAGE_DIR). Reuse it for every site."
